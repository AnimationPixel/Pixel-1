import subprocess,re
out=[];seen=set()
for l in subprocess.check_output(['nm','-n','pxkernel.elf']).decode().splitlines():
    p=l.split()
    if len(p)==3 and p[1] in 'tTwW' and re.match(r'^[A-Za-z_]\w*$',p[2]) and p[2] not in seen:
        seen.add(p[2]);out.append('{0x%s,"%s"}'%(p[0],p[2]))
open('symtab.h','w').write('static const struct{u32 a;const char*n;}SYM[]={'+','.join(out)+'};static const int NSYM=%d;\n'%len(out));print(len(out),'simbolos')
