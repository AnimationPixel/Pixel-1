/* emulador minimo de PC x86 (modo real + protegido plano + x87) para depurar el arranque de PixelKernel */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <math.h>
typedef uint8_t u8;typedef uint16_t u16;typedef uint32_t u32;typedef int32_t s32;typedef int16_t s16;typedef int8_t s8;typedef uint64_t u64;
#define RAMSZ (96u<<20)
#define FBBASE 0xFD000000u
#define FBSZ (8u<<20)
static u8*RAM,*FBM;static u8 dummy[16];
static u8*mp(u32 a){if(a<RAMSZ)return RAM+a;if(a>=FBBASE&&a<FBBASE+FBSZ)return FBM+(a-FBBASE);return dummy;}
static u64 fbw,x87n;static u8 r8(u32 a){return *mp(a);}
static u16 r16(u32 a){return r8(a)|(r8(a+1)<<8);}
static u32 r32(u32 a){return r16(a)|((u32)r16(a+2)<<16);}
static void w8(u32 a,u8 v){if(a>=FBBASE)fbw++;*mp(a)=v;}
static void w16(u32 a,u16 v){w8(a,v);w8(a+1,v>>8);}
static void w32(u32 a,u32 v){w16(a,v);w16(a+2,v>>16);}
enum{EAX,ECX,EDX,EBX,ESP,EBP,ESI,EDI};enum{ES,CS,SS,DS,FS,GS};
static u32 R[8],eip,efl=2,cr0,sel[6],sbase[6];static int pm;
static u32 gdtr_base,gdtr_lim,idtr_base,idtr_lim;
#define CF 1u
#define PF 4u
#define ZF 0x40u
#define SF 0x80u
#define DF 0x400u
#define OFL 0x800u
static u64 icount;static int halted;
static double st[8];static int top;static u16 fcw=0x37F,fsw;
static void die(const char*m){fprintf(stderr,"EMU: %s en EIP=%08x CS:%04x (insn %llu)\n bytes:",m,eip,sel[CS],(unsigned long long)icount);for(int i=0;i<12;i++)fprintf(stderr," %02x",r8(sbase[CS]+eip+i));fprintf(stderr,"\n");exit(3);}
/* ---- dispositivos ---- */
static u64 kthr[16];static int kcode[16],nk,kq[16],kqn;
static u32 hist[1<<16],xhist[1<<16];

static u32 pit_latch;static int pit_hi;static int cmos_idx;static u32 isoN;static u8*ISO;static u32 vbe_mode;static u32 events;
static u32 pit_now(void){return 65535-(u32)((icount/12)%65536);}
static u8 in8(u16 p){switch(p){case 0x40:{u8 v=pit_hi?(pit_latch>>8):pit_latch;pit_hi^=1;return v;}case 0x64:return kqn?1:0;case 0x60:{if(kqn){u8 v=kq[0];for(int i=1;i<kqn;i++)kq[i-1]=kq[i];kqn--;return v;}return 0;}case 0x61:return 0;case 0x92:return 2;case 0x71:{if(cmos_idx==4)return 0x21;if(cmos_idx==2)return 0x07;if(cmos_idx==0x0B)return 2;return 0;}case 0x3DA:return (icount>>10)&8;default:return 0;}}
static u32 spk_writes,pic_mask,irqs_taken;static u64 next_irq=3000000;
static void out8(u16 p,u8 v){switch(p){case 0x43:if((v>>6)==0&&((v>>4)&3)==0){pit_latch=pit_now();pit_hi=0;}break;case 0x61:spk_writes++;break;case 0x70:cmos_idx=v&0x7F;break;case 0x21:pic_mask=v;break;default:break;}}
/* ---- registros ---- */
static u32 getr(int r,int sz){if(sz==1)return r<4?(R[r]&0xFF):((R[r-4]>>8)&0xFF);if(sz==2)return R[r]&0xFFFF;return R[r];}
static void setr(int r,int sz,u32 v){if(sz==1){if(r<4)R[r]=(R[r]&~0xFFu)|(v&0xFF);else R[r-4]=(R[r-4]&~0xFF00u)|((v&0xFF)<<8);}else if(sz==2)R[r]=(R[r]&~0xFFFFu)|(v&0xFFFF);else R[r]=v;}
static u32 MASK(int sz){return sz==1?0xFF:sz==2?0xFFFF:0xFFFFFFFFu;}
static u32 SIGN(int sz){return sz==1?0x80:sz==2?0x8000:0x80000000u;}
static void szp(u32 r,int sz){r&=MASK(sz);efl&=~(ZF|SF|PF);if(!r)efl|=ZF;if(r&SIGN(sz))efl|=SF;u8 b=r&0xFF;int p=0;while(b){p^=b&1;b>>=1;}if(!p)efl|=PF;}
static u32 alu(int op,u32 a,u32 b,int sz){u64 r;u32 m=MASK(sz),sg=SIGN(sz);a&=m;b&=m;int c=(efl&CF)?1:0;
 switch(op){case 0:case 2:{u64 cc=op==2?c:0;r=(u64)a+b+cc;efl&=~(CF|OFL);if(r>m)efl|=CF;if(((a^r)&(b^r))&sg)efl|=OFL;break;}
  case 3:case 5:case 7:{u64 cc=op==3?c:0;r=(u64)a-b-cc;efl&=~(CF|OFL);if((u64)a<(u64)b+cc)efl|=CF;if(((a^b)&(a^r))&sg)efl|=OFL;break;}
  case 1:r=a|b;efl&=~(CF|OFL);break;case 4:r=a&b;efl&=~(CF|OFL);break;default:r=a^b;efl&=~(CF|OFL);break;}
 szp((u32)r,sz);return (u32)r&m;}
static int cond(int c){int z=!!(efl&ZF),s=!!(efl&SF),o=!!(efl&OFL),cf=!!(efl&CF),p=!!(efl&PF),r;switch(c>>1){case 0:r=o;break;case 1:r=cf;break;case 2:r=z;break;case 3:r=cf|z;break;case 4:r=s;break;case 5:r=p;break;case 6:r=s!=o;break;default:r=z|(s!=o);}return (c&1)?!r:r;}
/* ---- decodificacion ---- */
static int opsz,adsz,segov,rep;static u32 ea;static int easeg,mod,reg,rm;
static u32 fetch_base(void){return sbase[CS]+eip;}
static u8 f8(void){u8 v=r8(fetch_base());eip++;return v;}
static u16 f16(void){u16 v=f8();v|=f8()<<8;return v;}
static u32 f32(void){u32 v=f16();v|=(u32)f16()<<16;return v;}
static u32 fimm(int sz){return sz==1?f8():sz==2?f16():f32();}
static void modrm(void){u8 m=f8();mod=m>>6;reg=(m>>3)&7;rm=m&7;if(mod==3)return;easeg=DS;
 if(adsz==2){u32 d=0,v=0;switch(rm){case 0:v=R[EBX]+R[ESI];break;case 1:v=R[EBX]+R[EDI];break;case 2:v=R[EBP]+R[ESI];easeg=SS;break;case 3:v=R[EBP]+R[EDI];easeg=SS;break;case 4:v=R[ESI];break;case 5:v=R[EDI];break;case 6:v=R[EBP];easeg=SS;break;default:v=R[EBX];}
  if(mod==0&&rm==6){d=f16();v=0;easeg=DS;}else if(mod==1)d=(u32)(s32)(s8)f8();else if(mod==2)d=f16();ea=(v+d)&0xFFFF;}
 else{u32 v=0,d=0;if(rm==4){u8 sb=f8();int sc=sb>>6,ix=(sb>>3)&7,bs=sb&7;v=(ix==4?0:R[ix]<<sc);if(bs==5&&mod==0){d=f32();}else{v+=R[bs];if(bs==4||bs==5)easeg=SS;}}
  else if(rm==5&&mod==0){d=f32();}else{v=R[rm];if(rm==5)easeg=SS;}
  if(mod==1)d=(u32)(s32)(s8)f8();else if(mod==2)d=f32();ea=v+d;}
 if(segov>=0)easeg=segov;}
static u32 rd_m(int sz){u32 a=sbase[easeg]+ea;return sz==1?r8(a):sz==2?r16(a):r32(a);}
static void wr_m(int sz,u32 v){u32 a=sbase[easeg]+ea;if(sz==1)w8(a,v);else if(sz==2)w16(a,v);else w32(a,v);}
static u32 rd_rm(int sz){return mod==3?getr(rm,sz):rd_m(sz);}
static void wr_rm(int sz,u32 v){if(mod==3)setr(rm,sz,v);else wr_m(sz,v);}
static void push(u32 v,int sz){int ss=pm?4:2;(void)ss;if(sz==4){R[ESP]=pm?R[ESP]-4:((R[ESP]-4)&0xFFFF);}else R[ESP]=pm?R[ESP]-2:((R[ESP]-2)&0xFFFF);
 u32 a=sbase[SS]+(pm?R[ESP]:(R[ESP]&0xFFFF));if(sz==4)w32(a,v);else w16(a,v);}
static u32 pop(int sz){u32 a=sbase[SS]+(pm?R[ESP]:(R[ESP]&0xFFFF));u32 v=sz==4?r32(a):r16(a);R[ESP]=pm?R[ESP]+sz:((R[ESP]+sz)&0xFFFF);return v;}
static void setseg(int s,u16 v){sel[s]=v;sbase[s]=pm?0:((u32)v<<4);}
/* ---- BIOS simulada ---- */
static u32 vmode_w(u32 m){return m==0x118?1024:m==0x115?800:m==0x112?640:0;}
static u32 vmode_h(u32 m){return m==0x118?768:m==0x115?600:m==0x112?480:0;}
static void bios_int(int n){u32 ah=(R[EAX]>>8)&0xFF,al=R[EAX]&0xFF;u32 es=sbase[ES];
 if(n==0x10){if(ah==0x0E){putchar(al);R[EAX]=R[EAX];return;}
  if(ah==0x4F){u32 di=R[EDI]&0xFFFF;if(al==0){u32 b=es+di;memcpy(mp(b),"VESA",4);w16(b+4,0x200);w16(b+14,di+0x100);w16(b+16,sel[ES]);w16(b+0x100,0x112);w16(b+0x102,0x115);w16(b+0x104,0x118);w16(b+0x106,0xFFFF);R[EAX]=0x4F;efl&=~CF;return;}
   if(al==1){u32 m=R[ECX]&0xFFFF,b=es+di;if(!vmode_w(m)){R[EAX]=0x14F;return;}memset(mp(b),0,256);w16(b,0x9B);w16(b+16,vmode_w(m)*4);w16(b+18,vmode_w(m));w16(b+20,vmode_h(m));w8(b+25,32);w8(b+27,6);w32(b+40,FBBASE);R[EAX]=0x4F;return;}
   if(al==2){vbe_mode=R[EBX]&0x1FFF;R[EAX]=0x4F;events|=1;return;}}
  R[EAX]=(R[EAX]&~0xFFFFu)|0x100;return;}
 if(n==0x13&&ah==0x42){u32 d=sbase[DS]+(R[ESI]&0xFFFF);u32 cnt=r16(d+2),off=r16(d+4),seg=r16(d+6),lba=r32(d+8);if((u64)(lba+cnt)*2048>isoN){R[EAX]=(R[EAX]&0xFF)|0x0100;efl|=CF;return;}memcpy(mp(((u32)seg<<4)+off),ISO+(u64)lba*2048,cnt*2048);R[EAX]&=0xFF;efl&=~CF;events|=2;return;}
 if(n==0x15){if(ah==0x24){R[EAX]&=0xFF;efl&=~CF;return;}
  if(ah==0x87){u32 g=es+(R[ESI]&0xFFFF);u32 sb=r16(g+0x12)|(r8(g+0x14)<<16)|((u32)r8(g+0x17)<<24),db=r16(g+0x1A)|(r8(g+0x1C)<<16)|((u32)r8(g+0x1F)<<24);u32 cnt=(R[ECX]&0xFFFF)*2;for(u32 i=0;i<cnt;i++)w8(db+i,r8(sb+i));R[EAX]&=0xFF;efl&=~CF;events|=4;return;}
  if(ah==0x88){R[EAX]=(R[EAX]&~0xFFFFu)|0xFC00;efl&=~CF;return;}}
 fprintf(stderr,"EMU: int %02x ah=%02x no soportada\n",n,ah);efl|=CF;}
static void bios_int2(int n){bios_int(n);if(n==0x15||n==0x13||n==0x10)efl|=0x200;}
/* ---- x87 ---- */
static double fget(int i){return st[(top+i)&7];}
static void fset(int i,double v){st[(top+i)&7]=v;}
static void fpush(double v){top=(top-1)&7;st[top]=v;}
static double fpop(void){double v=st[top];top=(top+1)&7;return v;}
static void fcmp(double a,double b){fsw&=~0x4500;if(isnan(a)||isnan(b))fsw|=0x4500;else if(a>b);else if(a<b)fsw|=0x100;else fsw|=0x4000;}
static double rnd_mode(double v){int rc=(fcw>>10)&3;if(rc==0)return nearbyint(v);if(rc==1)return floor(v);if(rc==2)return ceil(v);return trunc(v);}
static void farith(int op,double a,double b,double*r){switch(op){case 0:*r=a+b;break;case 1:*r=a*b;break;case 4:*r=a-b;break;case 5:*r=b-a;break;case 6:*r=a/b;break;case 7:*r=b/a;break;}}
static void x87(u8 op){x87n++;if(eip<0x100000)xhist[eip>>4]++;modrm();int sub=reg;
 if(mod!=3){u32 a=sbase[easeg]+ea;
  switch(op){
  case 0xD8:{float f;u32 v=r32(a);memcpy(&f,&v,4);double s=fget(0);if(sub==2||sub==3){fcmp(s,f);if(sub==3)fpop();}else{double r;farith(sub,s,f,&r);fset(0,r);}break;}
  case 0xD9:switch(sub){case 0:{u32 v=r32(a);float f;memcpy(&f,&v,4);fpush(f);break;}case 2:case 3:{float f=(float)fget(0);u32 v;memcpy(&v,&f,4);w32(a,v);if(sub==3)fpop();break;}case 5:fcw=r16(a);break;case 7:w16(a,fcw);break;default:die("x87 d9 mem");}break;
  case 0xDB:switch(sub){case 0:fpush((s32)r32(a));break;case 2:case 3:{double v=rnd_mode(fget(0));w32(a,(u32)(s32)v);if(sub==3)fpop();break;}default:die("x87 db mem");}break;
  case 0xDC:{u64 v=r32(a)|((u64)r32(a+4)<<32);double f;memcpy(&f,&v,8);double s=fget(0);if(sub==2||sub==3){fcmp(s,f);if(sub==3)fpop();}else{double r;farith(sub,s,f,&r);fset(0,r);}break;}
  case 0xDD:switch(sub){case 0:{u64 v=r32(a)|((u64)r32(a+4)<<32);double f;memcpy(&f,&v,8);fpush(f);break;}case 2:case 3:{double f=fget(0);u64 v;memcpy(&v,&f,8);w32(a,(u32)v);w32(a+4,v>>32);if(sub==3)fpop();break;}default:die("x87 dd mem");}break;
  case 0xDF:switch(sub){case 5:{u64 v=r32(a)|((u64)r32(a+4)<<32);fpush((double)(int64_t)v);break;}case 7:{double v=rnd_mode(fget(0));int64_t iv=(int64_t)v;w32(a,(u32)iv);w32(a+4,(u32)((u64)iv>>32));fpop();break;}case 0:fpush((s16)r16(a));break;case 2:case 3:{double v=rnd_mode(fget(0));w16(a,(u16)(s16)v);if(sub==3)fpop();break;}default:die("x87 df mem");}break;
  default:die("x87 mem op");}
  return;}
 int i=rm;
 switch(op){
 case 0xD8:{double s=fget(0),t=fget(i);if(sub==2||sub==3){fcmp(s,t);if(sub==3)fpop();}else{double r;farith(sub,s,t,&r);fset(0,r);}break;}
 case 0xD9:switch(sub){case 0:fpush(fget(i));break;case 1:{double a=fget(0),b=fget(i);fset(0,b);fset(i,a);break;}case 4:{double v=fget(0);if(i==0)fset(0,-v);else if(i==1)fset(0,fabs(v));else if(i==4){fsw&=~0x4500;if(v==0)fsw|=0x4000;else if(v<0)fsw|=0x100;}else die("x87 d9 e4+");break;}
  case 5:if(i==0)fpush(1.0);else if(i==6)fpush(0.0);else die("x87 d9 e8");break;
  case 7:if(i==2)fset(0,sqrt(fget(0)));else die("x87 d9 f8");break;default:die("x87 d9");}break;
 case 0xDA:if(sub==5&&i==1){fcmp(fget(0),fget(1));fpop();fpop();}else die("x87 da");break;
 case 0xDB:if(sub==4&&i==3){fcw=0x37F;fsw=0;top=0;}else die("x87 db reg");break;
 case 0xDC:{double s=fget(i),t=fget(0),r;int o=sub;if(o==4)o=5;else if(o==5)o=4;else if(o==6)o=7;else if(o==7)o=6;farith(o,t,s,&r);/* st(i)=st(i) op st(0) con orden invertido */ 
   {double a=fget(i),b=fget(0);switch(sub){case 0:r=a+b;break;case 1:r=a*b;break;case 4:r=b-a;break;case 5:r=a-b;break;case 6:r=b/a;break;default:r=a/b;}}fset(i,r);break;}
 case 0xDD:if(sub==3){fset(i,fget(0));fpop();}else if(sub==2){fset(i,fget(0));}else if(sub==4){fcmp(fget(0),fget(i));}else if(sub==5){fcmp(fget(0),fget(i));fpop();}else die("x87 dd reg");break;
 case 0xDE:{if(sub==3&&i==1){fcmp(fget(0),fget(1));fpop();fpop();break;}double a=fget(i),b=fget(0),r;switch(sub){case 0:r=a+b;break;case 1:r=a*b;break;case 4:r=b-a;break;case 5:r=a-b;break;case 6:r=b/a;break;case 7:r=a/b;break;default:die("x87 de");r=0;}fset(i,r);fpop();break;}
 case 0xDF:if(sub==4&&i==0){R[EAX]=(R[EAX]&~0xFFFFu)|fsw;}else die("x87 df reg");break;
 case 0xDB+100:break;
 default:die("x87");}
}
/* ---- cpu ---- */
static void shiftop(int op,int sz){int cnt;u32 v;(void)v;(void)cnt;}
static void step(void){
 u32 start=eip;opsz=pm?4:2;adsz=pm?4:2;segov=-1;rep=0;u8 b;
 for(;;){b=f8();if(b==0x66)opsz=pm?2:4;else if(b==0x67)adsz=pm?2:4;else if(b==0xF3||b==0xF2)rep=b;else if(b==0x26)segov=ES;else if(b==0x2E)segov=CS;else if(b==0x36)segov=SS;else if(b==0x3E)segov=DS;else if(b==0x64)segov=FS;else if(b==0x65)segov=GS;else break;}
 int sz=opsz;
 if(b<0x40&&(b&7)<6){int op=(b>>3)&7,f=b&7;
  if(f<4){int s=(f&1)?sz:1;modrm();if(f<2){u32 r=alu(op,rd_rm(s),getr(reg,s),s);if(op!=7)wr_rm(s,r);}else{u32 r=alu(op,getr(reg,s),rd_rm(s),s);if(op!=7)setr(reg,s,r);}}
  else{int s=f==4?1:sz;u32 im=fimm(s);u32 r=alu(op,getr(EAX,s),im,s);if(op!=7)setr(EAX,s,r);}
  return;}
 if(b>=0x40&&b<=0x4F){int r=b&7,s=sz;u32 cf=efl&CF;u32 v=getr(r,s);v=(b<0x48)?alu(0,v,1,s):alu(5,v,1,s);efl=(efl&~CF)|cf;setr(r,s,v);return;}
 if(b>=0x50&&b<=0x57){push(getr(b&7,sz),sz);return;}
 if(b>=0x58&&b<=0x5F){setr(b&7,sz,pop(sz));return;}
 if(b>=0x70&&b<=0x7F){s8 d=(s8)f8();if(cond(b&15))eip+=d;return;}
 if(b>=0xB0&&b<=0xB7){setr(b&7,1,f8());return;}
 if(b>=0xB8&&b<=0xBF){setr(b&7,sz,fimm(sz));return;}
 if(b>=0x91&&b<=0x97){u32 t=getr(0,sz);setr(0,sz,getr(b&7,sz));setr(b&7,sz,t);return;}
 if(b>=0xD8&&b<=0xDF){x87(b);return;}
 switch(b){
 case 0x0F:{u8 c=f8();
  if(c==0x01){modrm();u32 a=sbase[easeg]+ea;if(reg==2){gdtr_lim=r16(a);gdtr_base=r32(a+2);}else if(reg==3){idtr_lim=r16(a);idtr_base=r32(a+2);}else die("0f01");return;}
  if(c==0x20){modrm();R[rm]=cr0;return;}
  if(c==0x22){modrm();cr0=R[rm];return;}
  if(c>=0x80&&c<=0x8F){s32 d=sz==2?(s16)f16():(s32)f32();if(cond(c&15))eip+=d;return;}
  if(c>=0x90&&c<=0x9F){modrm();wr_rm(1,cond(c&15));return;}
  if(c==0x31){R[EAX]=(u32)icount;R[EDX]=(u32)(icount>>32);return;}
  if(c==0xA0){push(sel[FS],sz);return;}if(c==0xA1){setseg(FS,pop(sz));return;}if(c==0xA8){push(sel[GS],sz);return;}if(c==0xA9){setseg(GS,pop(sz));return;}
  if(c==0xAF){modrm();s32 a=(sz==2?(s16)getr(reg,2):(s32)getr(reg,4)),bb=(sz==2?(s16)rd_rm(2):(s32)rd_rm(4));long long r=(long long)a*bb;setr(reg,sz,(u32)r);efl&=~(CF|OFL);if(r!=(sz==2?(long long)(s16)r:(long long)(s32)r))efl|=CF|OFL;return;}
  if(c==0xB6||c==0xB7||c==0xBE||c==0xBF){modrm();int ss=(c&1)?2:1;u32 v=rd_rm(ss);if(c>=0xBE)v=ss==1?(u32)(s32)(s8)v:(u32)(s32)(s16)v;setr(reg,sz,v);return;}
  if(c==0xA4||c==0xA5||c==0xAC||c==0xAD){modrm();u32 cnt=(c&1)?R[ECX]&0xFF:f8();u32 d=rd_rm(sz),s=getr(reg,sz);cnt&=31;if(cnt){u64 x;if(c<0xA6){x=((u64)d<<32|s)<<cnt;d=(u32)(x>>32);}else{x=(((u64)s<<32)|d)>>cnt;d=(u32)x;}wr_rm(sz,d);szp(d,sz);}return;}
  die("0f xx no soportado");}
 case 0x68:push(fimm(sz),sz);return;
 case 0x6A:push((u32)(s32)(s8)f8(),sz);return;
 case 0x69:case 0x6B:{modrm();s32 a=sz==2?(s16)rd_rm(2):(s32)rd_rm(4);s32 im=b==0x6B?(s8)f8():(sz==2?(s16)f16():(s32)f32());long long r=(long long)a*im;setr(reg,sz,(u32)r);efl&=~(CF|OFL);if(r!=(long long)(s32)r&&sz==4)efl|=CF|OFL;return;}
 case 0x80:case 0x81:case 0x83:{int s=b==0x80?1:sz;modrm();u32 im=b==0x81?fimm(s):(b==0x83?(u32)(s32)(s8)f8():f8());u32 v=alu(reg,rd_rm(s),im,s);if(reg!=7)wr_rm(s,v);return;}
 case 0x84:case 0x85:{int s=b==0x84?1:sz;modrm();alu(4,rd_rm(s),getr(reg,s),s);return;}
 case 0x86:case 0x87:{int s=b==0x86?1:sz;modrm();u32 t=rd_rm(s);wr_rm(s,getr(reg,s));setr(reg,s,t);return;}
 case 0x88:case 0x89:{int s=b==0x88?1:sz;modrm();wr_rm(s,getr(reg,s));return;}
 case 0x8A:case 0x8B:{int s=b==0x8A?1:sz;modrm();setr(reg,s,rd_rm(s));return;}
 case 0x8C:{modrm();wr_rm(mod==3?sz:2,sel[reg]);return;}
 case 0x8D:{modrm();setr(reg,sz,ea);return;}
 case 0x8E:{modrm();setseg(reg,rd_rm(2));return;}
 case 0x8F:{modrm();wr_rm(sz,pop(sz));return;}
 case 0x90:return;
 case 0x98:if(sz==2)setr(0,2,(u32)(s32)(s8)getr(0,1));else R[EAX]=(u32)(s32)(s16)R[EAX];return;
 case 0x99:if(sz==2)setr(EDX,2,(R[EAX]&0x8000)?0xFFFF:0);else R[EDX]=(R[EAX]&0x80000000u)?0xFFFFFFFFu:0;return;
 case 0x9E:{u32 a=(R[EAX]>>8)&0xFF;efl=(efl&~(CF|PF|ZF|SF))|(a&(CF|PF|ZF|SF));return;}
 case 0x9B:return;
 case 0x9C:push(efl,sz);return;
 case 0x9D:efl=pop(sz)|2;return;
 case 0xA0:case 0xA1:case 0xA2:case 0xA3:{int s=(b&1)?sz:1;u32 o=adsz==2?f16():f32();int sg=segov>=0?segov:DS;u32 a=sbase[sg]+o;if(b<0xA2)setr(0,s,s==1?r8(a):s==2?r16(a):r32(a));else{u32 v=getr(0,s);if(s==1)w8(a,v);else if(s==2)w16(a,v);else w32(a,v);}return;}
 case 0xA4:case 0xA5:{int s=b==0xA4?1:sz;int sg=segov>=0?segov:DS;u32 n=rep?(adsz==2?R[ECX]&0xFFFF:R[ECX]):1;while(n--){u32 si=adsz==2?R[ESI]&0xFFFF:R[ESI],di=adsz==2?R[EDI]&0xFFFF:R[EDI];u32 v=s==1?r8(sbase[sg]+si):s==2?r16(sbase[sg]+si):r32(sbase[sg]+si);u32 d=sbase[ES]+di;if(s==1)w8(d,v);else if(s==2)w16(d,v);else w32(d,v);int dd=(efl&DF)?-s:s;R[ESI]+=dd;R[EDI]+=dd;if(rep){if(adsz==2)setr(ECX,2,R[ECX]-1);else R[ECX]--;}}return;}
 case 0xA8:alu(4,getr(0,1),f8(),1);return;
 case 0xA9:alu(4,getr(0,sz),fimm(sz),sz);return;
 case 0xAA:case 0xAB:{int s=b==0xAA?1:sz;u32 n=rep?(adsz==2?R[ECX]&0xFFFF:R[ECX]):1;u32 v=getr(0,s);while(n--){u32 di=adsz==2?R[EDI]&0xFFFF:R[EDI];u32 d=sbase[ES]+di;if(s==1)w8(d,v);else if(s==2)w16(d,v);else w32(d,v);R[EDI]+=(efl&DF)?-s:s;if(rep){if(adsz==2)setr(ECX,2,R[ECX]-1);else R[ECX]--;}}return;}
 case 0xAC:case 0xAD:{int s=b==0xAC?1:sz;int sg=segov>=0?segov:DS;u32 n=rep?(adsz==2?R[ECX]&0xFFFF:R[ECX]):1;while(n--){u32 si=adsz==2?R[ESI]&0xFFFF:R[ESI];u32 a=sbase[sg]+si;setr(0,s,s==1?r8(a):s==2?r16(a):r32(a));R[ESI]+=(efl&DF)?-s:s;if(rep)R[ECX]--;}return;}
 case 0xC0:case 0xC1:case 0xD0:case 0xD1:case 0xD2:case 0xD3:{int s=(b&1)?sz:1;modrm();u32 cnt=b<0xD0?f8():(b<0xD2?1:R[ECX]&0xFF);cnt&=31;u32 v=rd_rm(s),m=MASK(s);if(cnt){u32 r=v;u32 cf=0;switch(reg){case 4:case 6:cf=(cnt<=(u32)(s*8))?((v>>((s*8)-cnt))&1):0;r=(v<<cnt)&m;break;case 5:cf=(v>>(cnt-1))&1;r=v>>cnt;break;case 7:{s32 sv=s==1?(s8)v:s==2?(s16)v:(s32)v;cf=(sv>>(cnt-1))&1;r=(u32)(sv>>cnt)&m;break;}case 0:{u32 bits=s*8,c=cnt%bits;r=((v<<c)|(v>>(bits-c)))&m;if(!c)r=v;cf=r&1;break;}case 1:{u32 bits=s*8,c=cnt%bits;r=((v>>c)|(v<<(bits-c)))&m;if(!c)r=v;cf=!!(r&SIGN(s));break;}default:die("rcl/rcr");}
   wr_rm(s,r);efl&=~(CF|OFL);if(cf)efl|=CF;if(reg>=4)szp(r,s);}return;}
 case 0xC2:{u16 n=f16();eip=pop(sz);R[ESP]+=n;return;}
 case 0xC3:eip=pop(sz);return;
 case 0xC6:case 0xC7:{int s=b==0xC6?1:sz;modrm();wr_rm(s,fimm(s));return;}
 case 0xC9:R[ESP]=R[EBP];R[EBP]=pop(sz);return;
 case 0xCF:{eip=pop(4);u32 c=pop(4);efl=pop(4);setseg(CS,c);return;}
 case 0xCD:{u8 n=f8();if(pm)die("int en modo protegido");bios_int2(n);return;}
 case 0xE4:setr(0,1,in8(f8()));return;case 0xE6:out8(f8(),getr(0,1));return;
 case 0xE5:{u8 p=f8();setr(0,sz,in8(p));return;}case 0xE7:{out8(f8(),getr(0,1));return;}
 case 0xEC:setr(0,1,in8(R[EDX]&0xFFFF));return;case 0xEE:out8(R[EDX]&0xFFFF,getr(0,1));return;
 case 0xED:setr(0,sz,in8(R[EDX]&0xFFFF));return;case 0xEF:out8(R[EDX]&0xFFFF,getr(0,1));return;
 case 0xE8:{s32 d=sz==2?(s16)f16():(s32)f32();push(eip,sz);eip+=d;if(pm&&0)(void)0;return;}
 case 0xE9:{s32 d=sz==2?(s16)f16():(s32)f32();eip+=d;return;}
 case 0xEA:{u32 o=sz==2?f16():f32();u16 s=f16();if(!pm&&(cr0&1)){pm=1;events|=8;}setseg(CS,s);eip=o;if(pm)for(int i=0;i<6;i++)sbase[i]=0;return;}
 case 0xEB:{s8 d=(s8)f8();eip+=d;return;}
 case 0xF4:halted=1;return;
 case 0xF6:case 0xF7:{int s=b==0xF6?1:sz;modrm();switch(reg){
   case 0:case 1:alu(4,rd_rm(s),fimm(s),s);return;case 2:wr_rm(s,~rd_rm(s));return;case 3:{u32 v=rd_rm(s);u32 r=alu(5,0,v,s);wr_rm(s,r);return;}
   case 4:{u64 r=(u64)getr(0,s)*rd_rm(s);if(s==1)setr(0,2,r);else if(s==2){setr(0,2,r);setr(EDX,2,r>>16);}else{R[EAX]=(u32)r;R[EDX]=r>>32;}efl&=~(CF|OFL);if(r>>(s*8))efl|=CF|OFL;return;}
   case 5:{int64_t x;int64_t a=s==1?(s8)getr(0,1):s==2?(s16)getr(0,2):(s32)getr(0,4),c=s==1?(s8)rd_rm(1):s==2?(s16)rd_rm(2):(s32)rd_rm(4);x=a*c;if(s==1)setr(0,2,x);else if(s==2){setr(0,2,x);setr(EDX,2,x>>16);}else{R[EAX]=(u32)x;R[EDX]=x>>32;}return;}
   case 6:{u32 d=rd_rm(s);if(!d)die("division por cero (#DE)");if(s==4){u64 n=((u64)R[EDX]<<32)|R[EAX];R[EAX]=n/d;R[EDX]=n%d;}else if(s==2){u32 n=((R[EDX]&0xFFFF)<<16)|(R[EAX]&0xFFFF);setr(0,2,n/d);setr(EDX,2,n%d);}else{u32 n=R[EAX]&0xFFFF;setr(0,1,n/d);setr(4,1,n%d);}return;}
   default:{int64_t d=s==4?(s32)rd_rm(4):s==2?(s16)rd_rm(2):(s8)rd_rm(1);if(!d)die("division por cero (#DE)");if(s==4){int64_t n=(int64_t)(((u64)R[EDX]<<32)|R[EAX]);R[EAX]=(u32)(n/d);R[EDX]=(u32)(n%d);}else if(s==2){int32_t n=(int32_t)(((R[EDX]&0xFFFF)<<16)|(R[EAX]&0xFFFF));setr(0,2,n/d);setr(EDX,2,n%d);}else{int16_t n=(int16_t)(R[EAX]&0xFFFF);setr(0,1,n/d);setr(4,1,n%d);}return;}}}
 case 0xFA:efl&=~0x200;return;case 0xFB:efl|=0x200;return;case 0xFC:efl&=~DF;return;case 0xFD:efl|=DF;return;
 case 0xFE:case 0xFF:{int s=b==0xFE?1:sz;modrm();switch(reg){case 0:case 1:{u32 cf=efl&CF;u32 v=alu(reg==0?0:5,rd_rm(s),1,s);efl=(efl&~CF)|cf;wr_rm(s,v);return;}
   case 2:{u32 t=rd_rm(sz);push(eip,sz);eip=t;return;}case 4:eip=rd_rm(sz);return;case 6:push(rd_rm(sz),sz);return;default:die("ff /x");}}
 default:die("opcode no soportado");}
 (void)start;
}
static void deliver(int vec){u32 g=idtr_base+vec*8;u32 off=r16(g)|((u32)r16(g+6)<<16);u16 sl=r16(g+2);push(efl,4);push(sel[CS],4);push(eip,4);efl&=~0x200;setseg(CS,sl);eip=off;irqs_taken++;}
int main(int argc,char**argv){
 if(argc<2){fprintf(stderr,"uso: emu iso [instrucciones(millones)] [volcados]\n");return 1;}
 RAM=calloc(RAMSZ,1);FBM=calloc(FBSZ,1);FILE*f=fopen(argv[1],"rb");if(!f)return 1;fseek(f,0,SEEK_END);isoN=ftell(f);fseek(f,0,SEEK_SET);ISO=malloc(isoN);fread(ISO,1,isoN,f);fclose(f);
 u64 maxm=argc>2?atoll(argv[2]):2000;int ndump=argc>3?atoi(argv[3]):4;
 /* arranque El Torito sin emulacion */
 u32 cat=r32(0)*0+(*(u32*)(ISO+17*2048+71));u8*e=ISO+cat*2048+32;u32 cnt=e[6]|(e[7]<<8),lba=*(u32*)(e+8);memcpy(RAM+0x7C00,ISO+(u64)lba*2048,cnt*512);
 pm=0;for(int i=0;i<6;i++){sel[i]=0;sbase[i]=0;}R[EDX]=0xE0;R[ESP]=0x7C00;eip=0x7C00;efl=2;
 printf("EMU: arranque desde LBA %u, %u sectores de 512 B\n",lba,cnt);
 for(int i=4;i+0<argc;i++){unsigned long long t;int c;if(sscanf(argv[i],"%llu:%x",&t,&c)==2){kthr[nk]=t*1000000ull;kcode[nk]=c;nk++;}}
 u64 lim=maxm*1000000ull,next=lim/ndump;int dn=0;u32 lastev=0;
 static int ki;u64 hres=getenv("HRESET")?atoll(getenv("HRESET"))*1000000ull:0;while(icount<lim&&!halted){if(pm&&(efl&0x200)&&!(pic_mask&1)&&icount>=next_irq){deliver(8);next_irq=icount+2000000;}step();icount++;if(icount==hres)memset(hist,0,sizeof hist);if(ki<nk&&icount>=kthr[ki]){if(kqn<15){kq[kqn++]=kcode[ki];}ki++;}if((icount%997)==0&&eip<0x100000)hist[eip>>4]++;
  if(events!=lastev){if((events&8)&&!(lastev&8))printf("EMU: modo protegido alcanzado (insn %llu)\n",(unsigned long long)icount);if((events&2)&&!(lastev&2))printf("EMU: lectura del CD correcta\n");if((events&4)&&!(lastev&4))printf("EMU: copia a memoria extendida correcta\n");if((events&1)&&!(lastev&1))printf("EMU: modo de video fijado: 0x%x\n",vbe_mode);lastev=events;}
  if(icount>=next&&dn<ndump){char n[32];sprintf(n,"emu_fb%d.ppm",dn++);FILE*o=fopen(n,"wb");fprintf(o,"P6\n1024 768\n255\n");for(int i=0;i<1024*768;i++){u32 c=*(u32*)(FBM+i*4);fputc(c>>16,o);fputc(c>>8,o);fputc(c,o);}fclose(o);printf("EMU: volcado %s (insn %llu, eip %08x)\n",n,(unsigned long long)icount,eip);next+=lim/ndump;}
 }
 printf("EMU: bytes escritos al framebuffer=%llu (=%.1f pantallas), instrucciones x87=%llu (%.0f%% del total)\n",(unsigned long long)fbw,fbw/(1024.0*768*4),(unsigned long long)x87n,100.0*x87n/icount);{FILE*o=fopen("hist.txt","w");for(u32 i=0;i<(1<<16);i++)if(hist[i])fprintf(o,"%x %u\n",i<<4,hist[i]);fclose(o);}
 {FILE*o=fopen("xhist.txt","w");for(u32 i=0;i<(1<<16);i++)if(xhist[i])fprintf(o,"%x %u\n",i<<4,xhist[i]);fclose(o);}
 {FILE*o=fopen("emu_final.ppm","wb");fprintf(o,"P6\n1024 768\n255\n");for(int i=0;i<1024*768;i++){u32 c=*(u32*)(FBM+i*4);fputc(c>>16,o);fputc(c>>8,o);fputc(c,o);}fclose(o);}
 printf("EMU: interrupciones entregadas en modo protegido: %u\n",irqs_taken);printf("EMU: fin: insn=%llu halted=%d eip=%08x altavoz=%u\n",(unsigned long long)icount,halted,eip,spk_writes);
 return 0;}
