/* PixelKernel 1.0 - nucleo de PixelOS 2.0 (consola Pixel 1). Modo protegido 32 bits, VBE 32 bpp */
#include "kapi.h"
typedef unsigned long long u64;
typedef struct{u32 off;u8 w,h;s8 bx,by;u16 adv;}GLY;
static u32*DST;
#ifdef TEST32
static u32 BBm[1024*768],BGm[1024*768];static u32*const BB=BBm,*const BG=BGm;static int W=1024,H=768;static u8 keys[128];
static u8 ISOMEM[2*1024*1024]__attribute__((aligned(16)));static u8 GAMEMEM[1024*1024]__attribute__((aligned(4096)));
static u32 iso_ok,iso_sectors;
#define MEM_ISO ISOMEM
#define MEM_GAMES GAMEMEM
static void plat_init(void){DST=BB;}
static void poll_keys(void){}
static float pit_dt(void){return 1.0f/60;}
static void time_init(void){}
static float time_dt(void){return 1.0f/60;}
static void spk(int hz){(void)hz;}static void spk_off(void){}
static void rtc_hm(int*h,int*m){*h=21;*m=7;}
#else
struct FBI{u32 addr;u16 pitch,xres,yres;}__attribute__((packed));
extern struct FBI fbi;extern u32 iso_ok,iso_sectors;
static u32*const BB=(u32*)0x400000;static u32*const BG=(u32*)0x700000;
#define MEM_ISO ((u8*)0xA00000)
#define MEM_GAMES ((u8*)0xD00000)
static int W,H;static u8 keys[128];
static inline void outb(u16 p,u8 v){__asm__ volatile("outb %0,%1"::"a"(v),"Nd"(p));}
static inline u8 inb(u16 p){u8 v;__asm__ volatile("inb %1,%0":"=a"(v):"Nd"(p));return v;}
static u32 pit_last;
static void plat_init(void){DST=BB;W=fbi.xres;H=fbi.yres;outb(0x43,0x34);outb(0x40,0);outb(0x40,0);}
static void poll_keys(void){for(int n=0;n<24;n++){u8 s=inb(0x64);if(s==0xFF||!(s&1))break;u8 c=inb(0x60);if(s&0x20||c==0xE0||c==0xE1)continue;keys[c&0x7F]=(c&0x80)?0:1;}}
static float pit_dt(void){outb(0x43,0);u32 lo=inb(0x40),hi=inb(0x40),cur=(hi<<8)|lo,d=(pit_last-cur)&0xFFFF;pit_last=cur;return d/1193182.0f;}
static inline u64 rdtsc_(void){u32 lo,hi;__asm__ volatile("rdtsc":"=a"(lo),"=d"(hi));return ((u64)hi<<32)|lo;}
static float tsc_inv;static u64 tsc_last;
static void time_init(void){pit_dt();u64 t0=rdtsc_();float acc=0;do{acc+=pit_dt();}while(acc<0.03f);u64 t1=rdtsc_();tsc_last=t1;tsc_inv=(t1>t0+1000)?acc/(float)(t1-t0):0;}
static float time_dt(void){if(tsc_inv>0){u64 t=rdtsc_();float d=(float)(t-tsc_last)*tsc_inv;tsc_last=t;return d;}return pit_dt();}
static void spk(int hz){if(hz<20)hz=20;u32 d=1193182u/hz;outb(0x43,0xB6);outb(0x42,d&255);outb(0x42,d>>8);outb(0x61,inb(0x61)|3);}
static void spk_off(void){outb(0x61,inb(0x61)&0xFC);}
static int cmos(int r){outb(0x70,r);return inb(0x71);}
static void rtc_hm(int*h,int*m){int hh=cmos(4),mm=cmos(2),b=cmos(0x0B);if(!(b&4)){hh=(hh&15)+(hh>>4)*10;mm=(mm&15)+(mm>>4)*10;}*h=hh;*m=mm;}
#endif
#include "font.h"

/* ---- matematicas ---- */
static float fabs_(float x){return x<0?-x:x;}
static float sqrt_(float x){return x>0?__builtin_sqrtf(x):0;}
static float fmin_(float a,float b){return a<b?a:b;}
static float fmax_(float a,float b){return a>b?a:b;}
static float clamp(float x,float a,float b){return x<a?a:x>b?b:x;}
static int ifl(float f){int i=(int)f;return i-(f<(float)i);}
static int ice(float f){int i=(int)f;return i+(f>(float)i);}
static float fmod_(float x,float m){return x-m*(float)ifl(x/m);}
static float fsin(float x){x-=6.2831853f*(float)ifl(x*0.15915494f+0.5f);float x2=x*x;return x*(1.0f+x2*(-0.16666667f+x2*(0.008333333f+x2*(-0.000198413f+x2*(2.7557e-6f+x2*-2.505e-8f)))));}
static float fcos(float x){return fsin(x+1.5707963f);}
static float fatan2(float y,float x){float ax=fabs_(x),ay=fabs_(y);if(ax==0&&ay==0)return 0;float a=ax>ay?ay/ax:ax/ay,s=a*a,r=((-0.0464964749f*s+0.15931422f)*s-0.327622764f)*s*a+a;if(ay>ax)r=1.57079637f-r;if(x<0)r=3.14159274f-r;return y<0?-r:r;}
static float smooth(float t){t=clamp(t,0,1);return t*t*(3-2*t);}
static float easeo(float t){t=clamp(t,0,1);t=1-t;return 1-t*t*t;}
static u32 seed=12345;
static float rnd(void){seed=seed*1103515245u+12345u;return ((seed>>8)&0xFFFF)/65536.0f;}
static int rndi(int n){return (int)(rnd()*n)%n;}
typedef struct{float x,v;}Sp;
static void spr(Sp*s,float t,float k,float dt){int n=(int)(dt*240)+1;float h=dt/n;while(n--){float a=k*k*(t-s->x)-2*k*s->v;s->v+=a*h;s->x+=s->v*h;}}

/* ---- color ---- */
static u32 lerpc(u32 a,u32 b,float t){int k=(int)(clamp(t,0,1)*256);u32 rb=(((a&0xFF00FF)*(256-k)+(b&0xFF00FF)*k)>>8)&0xFF00FF,g=(((a&0xFF00)*(256-k)+(b&0xFF00)*k)>>8)&0xFF00;return rb|g;}
static float SC=1,OX=0,OY=0,SX=1,GA=1;static int CX0,CY0,CX1,CY1;
#define TX(x) (((x)*SX+OX)*SC)
#define TY(y) (((y)*SX+OY)*SC)
#define TL(l) ((l)*SX*SC)
static void clipall(void){CX0=0;CY0=0;CX1=W;CY1=H;}
static void clipset(float x,float y,float w,float h){CX0=ifl(TX(x));CY0=ifl(TY(y));CX1=ice(TX(x+w));CY1=ice(TY(y+h));if(CX0<0)CX0=0;if(CY0<0)CY0=0;if(CX1>W)CX1=W;if(CY1>H)CY1=H;}
static inline void bl(int x,int y,u32 c,int a){
 if(x<CX0||x>=CX1||y<CY0||y>=CY1||a<=0)return;u32*p=DST+y*W+x;if(a>=255){*p=c;return;}u32 d=*p;
 *p=((((d&0xFF00FF)*(256-a)+(c&0xFF00FF)*a)>>8)&0xFF00FF)|((((d&0xFF00)*(256-a)+(c&0xFF00)*a)>>8)&0xFF00);}
static void span(int y,int x0,int x1,u32 c,int a){if(y<CY0||y>=CY1||a<=0)return;if(x0<CX0)x0=CX0;if(x1>CX1)x1=CX1;if(x1<=x0)return;u32*p=DST+y*W+x0;int n=x1-x0;
 if(a>=255){__asm__ volatile("cld;rep stosl":"+D"(p),"+c"(n):"a"(c):"memory");return;}u32 rb=(c&0xFF00FF)*a,g=(c&0xFF00)*a;int ia=256-a;
 while(n--){u32 d=*p;*p++=((((d&0xFF00FF)*ia+rb)>>8)&0xFF00FF)|((((d&0xFF00)*ia+g)>>8)&0xFF00);}}
static void dimall(u32 c,float al){al*=GA;int a=(int)(al*255);for(int y=CY0;y<CY1;y++)span(y,CX0,CX1,c,a);}

/* ---- formas con bordes suaves (version rapida: filas + enteros) ---- */
static float sdrr(float dx,float dy,float hw,float hh,float r){float qx=fabs_(dx)-hw+r,qy=fabs_(dy)-hh+r,ax=qx>0?qx:0,ay=qy>0?qy:0,m=qx>qy?qx:qy;return sqrt_(ax*ax+ay*ay)+(m<0?m:0)-r;}
static void rrect_(float x,float y,float w,float h,float r,u32 c1,u32 c2,float al){
 float X0=TX(x),Y0=TY(y),X1=TX(x+w),Y1=TY(y+h),R=TL(r),cx=(X0+X1)*.5f,cy=(Y0+Y1)*.5f,hw=(X1-X0)*.5f,hh=(Y1-Y0)*.5f;if(R>hw)R=hw;if(R>hh)R=hh;if(hw<=0||hh<=0)return;
 int ys=ifl(Y0),ye=ice(Y1);if(ys<CY0)ys=CY0;if(ye>CY1)ye=CY1;
 for(int py=ys;py<ye;py++){float fy=py+.5f,dy=fy-cy,vc=clamp(fmin_(fy-Y0,Y1-fy)+.5f,0,1);u32 col=c1==c2?c1:lerpc(c1,c2,(fy-Y0)/(Y1-Y0));
  int a=ice(X0),b=ifl(X1);
  if(fabs_(dy)<=hh-R){span(py,a,b,col,(int)(vc*al*255));
   if(a>b)bl(b,py,col,(int)(clamp(X1-X0,0,1)*vc*al*255));else{bl(a-1,py,col,(int)(clamp(a-X0,0,1)*vc*al*255));bl(b,py,col,(int)(clamp(X1-b,0,1)*vc*al*255));}}
  else if(R<1.5f){span(py,a,b,col,(int)(vc*al*255));bl(a-1,py,col,(int)(clamp(a-X0,0,1)*vc*al*255));bl(b,py,col,(int)(clamp(X1-b,0,1)*vc*al*255));}
  else{float dyc=fy<cy?(Y0+R-fy):(fy-(Y1-R));if(dyc<0)dyc=0;float hwc=R*R-dyc*dyc;hwc=hwc>0?sqrt_(hwc):0;float xl=X0+R-hwc,xr=X1-R+hwc;int ia=ice(xl),ib=ifl(xr);
   span(py,ia,ib,col,(int)(vc*al*255));if(ia>ib){bl(ib,py,col,(int)(clamp(xr-xl,0,1)*vc*al*255));}else{bl(ia-1,py,col,(int)(clamp(ia-xl,0,1)*vc*al*255));bl(ib,py,col,(int)(clamp(xr-ib,0,1)*vc*al*255));}}}}
static void rrect(float x,float y,float w,float h,float r,u32 c1,u32 c2,float al){rrect_(x,y,w,h,r,c1,c2,al*GA);}
static void rect(float x,float y,float w,float h,u32 c,float al){rrect_(x,y,w,h,0,c,c,al*GA);}
static void srect(float x,float y,float w,float h,float r,float width,u32 c,float al){al*=GA;
 float X0=TX(x),Y0=TY(y),X1=TX(x+w),Y1=TY(y+h),R=TL(r),cx=(X0+X1)*.5f,cy=(Y0+Y1)*.5f,hw=(X1-X0)*.5f,hh=(Y1-Y0)*.5f,t=TL(width)*.5f;if(R>hw)R=hw;if(R>hh)R=hh;
 int ys=ifl(Y0-t-1),ye=ice(Y1+t+1);if(ys<CY0)ys=CY0;if(ye>CY1)ye=CY1;
 for(int py=ys;py<ye;py++){float fy=py+.5f,dy=fy-cy;
  if(fabs_(dy)<=hh-R){for(int k=0;k<2;k++){float E=k?X1:X0;for(int px=ifl(E-t-1);px<ice(E+t+1);px++){float cov=clamp(.5f-(fabs_(px+.5f-E)-t),0,1);if(cov>0)bl(px,py,c,(int)(cov*al*255));}}}
  else{int xl=ice(X0+R)+1,xr=ifl(X1-R)-1;int px0=ifl(X0-t-1),px1=ice(X1+t+1);
   for(int px=px0;px<px1;px++){if(px>=xl&&px<=xr){px=xr;float E=fy<cy?Y0:Y1;float cov=clamp(.5f-(fabs_(fy-E)-t),0,1);if(cov>0)span(py,xl,xr+1,c,(int)(cov*al*255));continue;}
    float d=fabs_(sdrr(px+.5f-cx,dy,hw,hh,R)+t)-t,cov=clamp(.5f-d,0,1);if(cov>0)bl(px,py,c,(int)(cov*al*255));}}}}
static int qlow;
static void shadow(float x,float y,float w,float h,float r,float blur,u32 c,float al){if(qlow)return;al*=GA;
 for(int i=0;i<12;i++){float e=blur*(12-i)/12.0f;rrect_(x-e,y-e,w+2*e,h+2*e,r+e,c,c,al*.13f);}}
static void disc(float cx,float cy,float r,u32 c,float al){al*=GA;
 float X=TX(cx),Y=TY(cy),R=TL(r);if(R<=0)return;int ys=ifl(Y-R-1),ye=ice(Y+R+1);if(ys<CY0)ys=CY0;if(ye>CY1)ye=CY1;
 for(int py=ys;py<ye;py++){float dy=py+.5f-Y,ady=fabs_(dy);if(ady>=R+.5f)continue;
  if(R>=3&&ady<R-1){float hw=sqrt_(R*R-dy*dy),xl=X-hw,xr=X+hw;int a=ice(xl),b=ifl(xr);span(py,a,b,c,(int)(al*255));
   bl(a-1,py,c,(int)(clamp(a-xl,0,1)*al*255));bl(b,py,c,(int)(clamp(xr-b,0,1)*al*255));continue;}
  for(int px=ifl(X-R-1);px<ice(X+R+1);px++){float dx=px+.5f-X,cov=clamp(R+.5f-sqrt_(dx*dx+dy*dy),0,1);if(cov>0)bl(px,py,c,(int)(cov*al*255));}}}
static void ring(float cx,float cy,float r,float w,u32 c,float al){al*=GA;
 float X=TX(cx),Y=TY(cy),R=TL(r),t=TL(w)*.5f,ro=R+t+1,ri=R-t-1;int ys=ifl(Y-ro),ye=ice(Y+ro);if(ys<CY0)ys=CY0;if(ye>CY1)ye=CY1;
 for(int py=ys;py<ye;py++){float dy=py+.5f-Y,ady=fabs_(dy);if(ady>=ro)continue;float ho=sqrt_(ro*ro-dy*dy),hi=(ri>0&&ady<ri)?sqrt_(ri*ri-dy*dy):0;
  for(int k=0;k<2;k++){int a=k?ice(X+hi):ifl(X-ho),b=k?ice(X+ho):ice(X-hi);if(hi==0){a=ifl(X-ho);b=ice(X+ho);if(k)break;}
   for(int px=a;px<b;px++){float dx=px+.5f-X,d=fabs_(sqrt_(dx*dx+dy*dy)-R)-t,cov=clamp(.5f-d,0,1);if(cov>0)bl(px,py,c,(int)(cov*al*255));}}}}
static void arc(float cx,float cy,float r,float w,float frac,u32 c,float al){al*=GA;
 float X=TX(cx),Y=TY(cy),R=TL(r),t=TL(w)*.5f,a1=frac*6.2831853f,ro=R+t+1;
 for(int py=ifl(Y-ro);py<ice(Y+ro);py++){if(py<CY0||py>=CY1)continue;float dy=py+.5f-Y;if(fabs_(dy)>=ro)continue;float ho=sqrt_(ro*ro-dy*dy);
  for(int px=ifl(X-ho);px<ice(X+ho);px++){float dx=px+.5f-X,d=fabs_(sqrt_(dx*dx+dy*dy)-R)-t,cov=clamp(.5f-d,0,1);if(cov<=0)continue;
   float an=fatan2(dx,-dy);if(an<0)an+=6.2831853f;if(an<=a1)bl(px,py,c,(int)(cov*al*255));}}}
static u8 GLUT[257];static int glut_ok;
static void glut_init(void){for(int i=0;i<=256;i++){float t=1-sqrt_((float)i/256.0f);GLUT[i]=(u8)(t*t*255);}glut_ok=1;}
static void glow(float cx,float cy,float r,u32 c,float al){al*=GA;if(!glut_ok)glut_init();
 float X=TX(cx),Y=TY(cy),R=TL(r);if(R<1)return;int ix=(int)X,iy=(int)Y,Ri=(int)R,R2=Ri*Ri,inv=(256<<16)/R2,a256=(int)(al*256);
 for(int py=iy-Ri;py<=iy+Ri;py++){if(py<CY0||py>=CY1)continue;int dy=py-iy,dy2=dy*dy;if(dy2>=R2)continue;int hw=(int)sqrt_((float)(R2-dy2)),x0=ix-hw,x1=ix+hw;if(x0<CX0)x0=CX0;if(x1>=CX1)x1=CX1-1;
  u32*p=DST+py*W+x0;for(int px=x0;px<=x1;px++,p++){int dx=px-ix,d2=dx*dx+dy2,idx=(d2*inv)>>16;if(idx>255)continue;int a=(GLUT[idx]*a256)>>8;if(a<=0)continue;u32 d=*p;*p=((((d&0xFF00FF)*(256-a)+(c&0xFF00FF)*a)>>8)&0xFF00FF)|((((d&0xFF00)*(256-a)+(c&0xFF00)*a)>>8)&0xFF00);}}}
static void seg(float x0,float y0,float x1,float y1,float w,u32 c,float al){al*=GA;
 float ax=TX(x0),ay=TY(y0),bx=TX(x1),by=TY(y1),t=TL(w)*.5f,vx=bx-ax,vy=by-ay,L2=vx*vx+vy*vy,L=sqrt_(L2);
 float mnx=fmin_(ax,bx)-t-1,mxx=fmax_(ax,bx)+t+1;int ys=ifl(fmin_(ay,by)-t-1),ye=ice(fmax_(ay,by)+t+1);if(ys<CY0)ys=CY0;if(ye>CY1)ye=CY1;
 for(int py=ys;py<ye;py++){float fy=py+.5f,dy=fy-ay,xa=mnx,xb=mxx;
  if(fabs_(vy)>.2f*L&&L>0){float xc=ax+dy*vx/vy,hw=(t+1)*L/fabs_(vy)+t+1;xa=fmax_(xa,xc-hw);xb=fmin_(xb,xc+hw);}
  for(int px=ifl(xa);px<ice(xb);px++){float dx=px+.5f-ax,u=L2>0?clamp((dx*vx+dy*vy)/L2,0,1):0,ex=dx-u*vx,ey=dy-u*vy,cov=clamp(t+.5f-sqrt_(ex*ex+ey*ey),0,1);if(cov>0)bl(px,py,c,(int)(cov*al*255));}}}
static void poly(const float*p,int n,u32 c1,u32 c2,float al){al*=GA; /* convexo: por filas, bordes con cobertura exacta */
 float xs[8],ys[8],nx[8],ny[8],cc[8],mnx=1e9f,mny=1e9f,mxx=-1e9f,mxy=-1e9f,area=0;
 for(int i=0;i<n;i++){xs[i]=TX(p[i*2]);ys[i]=TY(p[i*2+1]);mnx=fmin_(mnx,xs[i]);mxx=fmax_(mxx,xs[i]);mny=fmin_(mny,ys[i]);mxy=fmax_(mxy,ys[i]);}
 for(int i=0;i<n;i++){int j=(i+1)%n;area+=xs[i]*ys[j]-xs[j]*ys[i];}float sg=area>0?1:-1;
 for(int i=0;i<n;i++){int j=(i+1)%n;float ex=xs[j]-xs[i],ey=ys[j]-ys[i],l=sqrt_(ex*ex+ey*ey)+1e-6f;nx[i]=sg*ey/l;ny[i]=-sg*ex/l;cc[i]=nx[i]*xs[i]+ny[i]*ys[i];}
 int ys0=ifl(mny-1),ye0=ice(mxy+1);if(ys0<CY0)ys0=CY0;if(ye0>CY1)ye0=CY1;
 for(int py=ys0;py<ye0;py++){float fy=py+.5f;u32 col=c1==c2?c1:lerpc(c1,c2,(fy-mny)/(mxy-mny+1e-3f));
  float xl=1e9f,xr=-1e9f;int hits=0;
  for(int i=0;i<n;i++){int j=(i+1)%n;float ya=ys[i],yb=ys[j];if((ya<=fy&&yb>fy)||(yb<=fy&&ya>fy)){float x=xs[i]+(fy-ya)*(xs[j]-xs[i])/(yb-ya);if(x<xl)xl=x;if(x>xr)xr=x;hits++;}}
  int a,b;int full=0;
  if(hits<2||fy-mny<1.5f||mxy-fy<1.5f||xr-xl<4){a=ifl(hits<2?mnx-1:xl-2);b=ice(hits<2?mxx+1:xr+2);}
  else{a=ifl(xl-1.5f);b=ice(xr+1.5f);full=1;}
  int fa=full?ice(xl+1.5f):b,fb=full?ifl(xr-1.5f):b;
  for(int px=a;px<b;px++){if(full&&px>=fa&&px<fb){px=fb-1;span(py,fa,fb,col,(int)(al*255));continue;}
   float d=-1e9f;for(int i=0;i<n;i++){float e=nx[i]*(px+.5f)+ny[i]*fy-cc[i];if(e>d)d=e;}float cov=clamp(.5f-d,0,1);if(cov>0)bl(px,py,col,(int)(cov*al*255));}}}
static void tri(float x,float y,float hw,float h,u32 c,float al){float p[6]={x,y,x+hw,y+h,x-hw,y+h};poly(p,3,c,c,al);}
static void heart(float cx,float cy,float s,u32 c,float al){disc(cx-s*.3f,cy-s*.2f,s*.34f,c,al);disc(cx+s*.3f,cy-s*.2f,s*.34f,c,al);float p[6]={cx-s*.62f,cy-s*.05f,cx+s*.62f,cy-s*.05f,cx,cy+s*.62f};poly(p,3,c,c,al);}

/* ---- texto SDF (Outfit) ---- */
static int cpidx(u32 cp){int lo=0,hi=NGLY-1;while(lo<=hi){int m=(lo+hi)/2;if(CPT[m]==cp)return m;if(CPT[m]<cp)lo=m+1;else hi=m-1;}return -1;}
static u32 nextcp(const char**s){const u8*p=(const u8*)*s;u32 c=*p++;if(c>=0xC0&&c<0xE0){c=((c&31)<<6)|(*p++&63);}else if(c>=0xE0){c=((c&15)<<12)|((p[0]&63)<<6)|(p[1]&63);p+=2;}*s=(const char*)p;return c;}
static float textw(const char*s,float size,int bold,float sp){const GLY*g=bold?GL1:GL0;float k=size/SDF_EM,w=0;int n=0;while(*s){int i=cpidx(nextcp(&s));if(i<0)i=cpidx('?');w+=g[i].adv/16.0f*k+sp;n++;}return w-(n?sp:0);}
static void glyph(const GLY*g,const u8*d,float ox,float oy,float k,u32 c,float al){
 if(!g->w)return;float x0=ox+g->bx*k,y0=oy-g->by*k,x1=x0+g->w*k,y1=y0+g->h*k;
 int iy0=ifl(y0),iy1=ice(y1),ix0=ifl(x0),ix1=ice(x1);if(ix0<CX0)ix0=CX0;if(ix1>CX1)ix1=CX1;if(iy0<CY0)iy0=CY0;if(iy1>CY1)iy1=CY1;if(ix0>=ix1||iy0>=iy1)return;
 const u8*t=d+g->off;int w=g->w,h=g->h,inv=(int)(65536.0f/k),cs=(int)(2*SDF_SPREAD*k*256),a256=(int)(al*256);
 for(int py=iy0;py<iy1;py++){int sv=(int)(((py+.5f)-y0)*(float)inv)-32768,v0=sv>>16,fv=(sv>>8)&255,vv0=v0<0?0:v0>=h?h-1:v0,vv1=v0+1<0?0:v0+1>=h?h-1:v0+1;const u8*r0=t+vv0*w,*r1=t+vv1*w;
  int su=(int)(((ix0+.5f)-x0)*(float)inv)-32768;
  if(k<.7f){int vr=((sv+32768)>>16);vr=vr<0?0:vr>=h?h-1:vr;const u8*rr=t+vr*w;int su2=su+32768;for(int px=ix0;px<ix1;px++,su2+=inv){int ur=su2>>16;ur=ur<0?0:ur>=w?w-1:ur;int cov=128+(((rr[ur]-128)*cs)>>8);if(cov<=0)continue;if(cov>255)cov=255;bl(px,py,c,(cov*a256)>>8);}continue;}
  for(int px=ix0;px<ix1;px++,su+=inv){int u0=su>>16,fu=(su>>8)&255,uu0=u0<0?0:u0>=w?w-1:u0,uu1=u0+1<0?0:u0+1>=w?w-1:u0+1;
   int a=(r0[uu0]*(256-fu)+r0[uu1]*fu)>>8,b=(r1[uu0]*(256-fu)+r1[uu1]*fu)>>8,dd=(a*(256-fv)+b*fv)>>8,cov=128+(((dd-128)*cs)>>8);if(cov<=0)continue;if(cov>255)cov=255;bl(px,py,c,(cov*a256)>>8);}}}
/* align: 0 izquierda, 1 centro, 2 derecha. (x,y) = linea base */
static void text(const char*s,float x,float y,float size,u32 c,float al,int bold,int align,float sp){al*=GA;
 float k=TL(size/SDF_EM);float w=textw(s,size,bold,sp);float ox=TX(x)-(align==1?TL(w)*.5f:align==2?TL(w):0),oy=TY(y);const GLY*g=bold?GL1:GL0;const u8*d=bold?SDF1:SDF0;
 while(*s){int i=cpidx(nextcp(&s));if(i<0)i=cpidx('?');glyph(&g[i],d,ox,oy,k,c,al);ox+=g[i].adv/16.0f*k+TL(sp);}}
