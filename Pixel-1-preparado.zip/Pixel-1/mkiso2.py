#!/usr/bin/env python3
"""ISO9660 + El Torito: /PXKERNEL.SYS (nucleo, arrancable), /GAMES/*.PX|*.PIXEL, /README.TXT"""
import struct,sys,os
kern=open(sys.argv[1],'rb').read(); out=sys.argv[2]
games=sorted(f for f in os.listdir('out') if f.upper().endswith(('.PX','.PIXEL')))
S=2048
def b16(v): return struct.pack('<H',v)+struct.pack('>H',v)
def b32(v): return struct.pack('<I',v)+struct.pack('>I',v)
date7=bytes([126,10,9,12,0,0,0])
def drec(name,lba,size,flags):
    l=33+len(name);pad=l%2
    return bytes([l+pad,0])+b32(lba)+b32(size)+date7+bytes([flags,0,0])+b16(1)+bytes([len(name)])+name+(b'\0' if pad else b'')
readme=("PIXEL 1 - PixelOS 2.0 / PixelKernel 1.0\r\n\r\nNucleo propio para la consola Pixel 1 (VBE 32 bits, modo protegido).\r\n"
"Los juegos son archivos .px o .pixel en la carpeta GAMES de este CD: el nucleo los lee, los carga y los ejecuta.\r\n"
"Controles: flechas mover, Intro aceptar, Q/E pestanas, H centro de control, Esc atras, P pausa.\r\n").encode()
PATH_L,PATH_M,ROOT,GDIR,CAT,README,KERN=19,20,21,22,23,24,25
nxt=KERN+(len(kern)+S-1)//S
gl={}
for g in games:
    gl[g]=nxt;nxt+=(os.path.getsize('out/'+g)+S-1)//S
total=nxt
root=drec(b'\x00',ROOT,S,2)+drec(b'\x01',ROOT,S,2)+drec(b'GAMES',GDIR,S,2)+drec(b'PXKERNEL.SYS;1',KERN,len(kern),0)+drec(b'README.TXT;1',README,len(readme),0)
gd=drec(b'\x00',GDIR,S,2)+drec(b'\x01',ROOT,S,2)+b''.join(drec(g.encode()+b';1',gl[g],os.path.getsize('out/'+g),0) for g in games)
assert len(root)<=S and len(gd)<=S
def ptab(be):
    e=(lambda v:struct.pack('>I',v)) if be else (lambda v:struct.pack('<I',v)); h=(lambda v:struct.pack('>H',v)) if be else (lambda v:struct.pack('<H',v))
    t=bytes([1,0])+e(ROOT)+h(1)+b'\x00\x00'
    t+=bytes([5,0])+e(GDIR)+h(1)+b'GAMES'+b'\x00'
    return t,len(t)
pl,psz=ptab(False);pm,_=ptab(True)
def pad(s,n): return s.encode().ljust(n,b' ')
pvd=bytearray(S);pvd[0]=1;pvd[1:6]=b'CD001';pvd[6]=1;pvd[8:40]=pad('',32);pvd[40:72]=pad('PIXEL1_OS',32)
pvd[80:88]=b32(total);pvd[120:124]=b16(1);pvd[124:128]=b16(1);pvd[128:132]=b16(S);pvd[132:140]=b32(psz)
pvd[140:144]=struct.pack('<I',PATH_L);pvd[148:152]=struct.pack('>I',PATH_M);pvd[156:190]=drec(b'\x00',ROOT,S,2)[:34]
for off,n in((190,128),(318,128),(446,128),(574,128)): pvd[off:off+n]=pad('',n)
pvd[574:702]=pad('PIXELKERNEL 1.0',128)
for off in(702,739,776): pvd[off:off+37]=pad('',37)
dt=b'2026100912000000\x00';pvd[813:830]=dt;pvd[830:847]=dt;pvd[847:864]=b'0000000000000000\x00';pvd[864:881]=b'0000000000000000\x00';pvd[881]=1
brvd=bytearray(S);brvd[1:6]=b'CD001';brvd[6]=1;brvd[7:39]=b'EL TORITO SPECIFICATION'.ljust(32,b'\0');brvd[71:75]=struct.pack('<I',CAT)
term=bytearray(S);term[0]=255;term[1:6]=b'CD001';term[6]=1
val=bytearray(32);val[0]=1;val[4:13]=b'PIXELOS 2';val[30]=0x55;val[31]=0xAA
s=sum(struct.unpack('<16H',bytes(val)))&0xFFFF;val[28:30]=struct.pack('<H',(-s)&0xFFFF)
ent=bytearray(32);ent[0]=0x88;ent[6:8]=struct.pack('<H',(len(kern)+511)//512);ent[8:12]=struct.pack('<I',KERN)
buf=bytearray(S*16)
for blk in (pvd,brvd,term,pl.ljust(S,b'\0'),pm.ljust(S,b'\0'),root.ljust(S,b'\0'),gd.ljust(S,b'\0'),(bytes(val)+bytes(ent)).ljust(S,b'\0'),readme.ljust(S,b'\0')): buf+=bytes(blk)
buf+=kern+b'\0'*((-len(kern))%S)
for g in games:
    d=open('out/'+g,'rb').read();assert len(buf)//S==gl[g];buf+=d+b'\0'*((-len(d))%S)
open(out,'wb').write(buf);print('ISO',len(buf),'bytes',len(buf)//S,'sectores; nucleo',len(kern),'; juegos',games)
