#!/usr/bin/env python3
"""Empaqueta un juego como .px/.pixel: enlaza en base 0, extrae relocaciones y rellena la cabecera."""
import subprocess,struct,sys,re
obj,out=sys.argv[1],sys.argv[2]
elf=out+'.elf'
subprocess.check_call(['ld','-m','elf_i386','-z','noexecstack','-q','-T','px.ld','-o',elf,obj],stderr=subprocess.DEVNULL)
subprocess.check_call(['objcopy','-O','binary',elf,out+'.bin'])
img=bytearray(open(out+'.bin','rb').read()); img+=b'\0'*((-len(img))%4)
end=int([l for l in subprocess.check_output(['nm',elf]).decode().splitlines() if l.endswith('__px_end')][0].split()[0],16)
rel=[]
for l in subprocess.check_output(['readelf','-r','-W',elf]).decode().splitlines():
    m=re.match(r'\s*([0-9a-f]{8})\s+[0-9a-f]+\s+(R_386_\w+)',l)
    if not m: continue
    off,ty=int(m.group(1),16),m.group(2)
    if ty=='R_386_32': rel.append(off)
    elif ty=='R_386_PC32': pass
    else: sys.exit('relocacion no soportada: '+ty+' en '+hex(off))
assert img[:4]==b'PXG1',img[:4]
assert all(o+4<=len(img) for o in rel),'relocacion fuera de la imagen'
struct.pack_into('<IIIIII',img,4,1,len(img),(end+15)&~15,struct.unpack_from('<I',img,16)[0],len(rel),len(img))
open(out,'wb').write(bytes(img)+struct.pack('<%dI'%len(rel),*rel))
print(out,'imagen',len(img),'mem',end,'relocs',len(rel))
