import struct,sys,os
files=sorted(f for f in os.listdir('out') if f.upper().endswith(('.PX','.PIXEL')))
data=b'';ents=[];base=8+40*len(files)
for f in files:
    b=open('out/'+f,'rb').read(); ents.append((f.encode()[:31],base+len(data),len(b))); data+=b+b'\0'*((-len(b))%4)
out=b'PXFS'+struct.pack('<I',len(files))+b''.join(struct.pack('<32sII',n,o,s) for n,o,s in ents)+data
open('initrd.bin','wb').write(out);print('initrd',len(out),'bytes',files)
