# Snapshots del paquete original

`kernel.generated.original.c` conserva el archivo `kernel.c` que venía en el ZIP original. El flujo de `build.sh` vuelve a generar `kernel.c` concatenando `part1.c`, `kcore.c` y `part3.c`; por eso el snapshot se guarda separado para evitar confundirlo con el archivo de trabajo generado.
