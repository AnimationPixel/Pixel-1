/* PixelKernel 1.0 - nucleo de PixelOS 2.0 (consola Pixel 1). Modo protegido 32 bits, VBE 32 bpp */
#include "kapi.h"
typedef unsigned long long u64;
typedef struct{u32 off;u8 w,h;s8 bx,by;u16 adv;}GLY;
static u32*DST;
#ifdef TEST32
static u32 BBm[1024*768],BGm[1024*768];static u32*const BB=BBm,*const BG=BGm;static int W=1024,H=768;static u8 keys[128];
static u8 ISOMEM[2*1024*1024]__attribute__((aligned(16)));static u8 GAMEMEM[1024*1024]__attribute__((aligned(4096)));
static u32 iso_ok,iso_sectors;
#define MEM_ISO ISOMEM
#define MEM_GAMES GAMEMEM
static void plat_init(void){DST=BB;}
static void poll_keys(void){}
static float pit_dt(void){return 1.0f/60;}
static void time_init(void){}
static float time_dt(void){return 1.0f/60;}
static void spk(int hz){(void)hz;}static void spk_off(void){}
static void rtc_hm(int*h,int*m){*h=21;*m=7;}
#else
struct FBI{u32 addr;u16 pitch,xres,yres;}__attribute__((packed));
extern struct FBI fbi;extern u32 iso_ok,iso_sectors;
static u32*const BB=(u32*)0x400000;static u32*const BG=(u32*)0x700000;
#define MEM_ISO ((u8*)0xA00000)
#define MEM_GAMES ((u8*)0xD00000)
static int W,H;static u8 keys[128];
static inline void outb(u16 p,u8 v){__asm__ volatile("outb %0,%1"::"a"(v),"Nd"(p));}
static inline u8 inb(u16 p){u8 v;__asm__ volatile("inb %1,%0":"=a"(v):"Nd"(p));return v;}
static u32 pit_last;
static void plat_init(void){DST=BB;W=fbi.xres;H=fbi.yres;outb(0x43,0x34);outb(0x40,0);outb(0x40,0);}
static void poll_keys(void){for(int n=0;n<24;n++){u8 s=inb(0x64);if(s==0xFF||!(s&1))break;u8 c=inb(0x60);if(s&0x20||c==0xE0||c==0xE1)continue;keys[c&0x7F]=(c&0x80)?0:1;}}
static float pit_dt(void){outb(0x43,0);u32 lo=inb(0x40),hi=inb(0x40),cur=(hi<<8)|lo,d=(pit_last-cur)&0xFFFF;pit_last=cur;return d/1193182.0f;}
static inline u64 rdtsc_(void){u32 lo,hi;__asm__ volatile("rdtsc":"=a"(lo),"=d"(hi));return ((u64)hi<<32)|lo;}
static float tsc_inv;static u64 tsc_last;
static void time_init(void){pit_dt();u64 t0=rdtsc_();float acc=0;do{acc+=pit_dt();}while(acc<0.03f);u64 t1=rdtsc_();tsc_last=t1;tsc_inv=(t1>t0+1000)?acc/(float)(t1-t0):0;}
static float time_dt(void){if(tsc_inv>0){u64 t=rdtsc_();float d=(float)(t-tsc_last)*tsc_inv;tsc_last=t;return d;}return pit_dt();}
static void spk(int hz){if(hz<20)hz=20;u32 d=1193182u/hz;outb(0x43,0xB6);outb(0x42,d&255);outb(0x42,d>>8);outb(0x61,inb(0x61)|3);}
static void spk_off(void){outb(0x61,inb(0x61)&0xFC);}
static int cmos(int r){outb(0x70,r);return inb(0x71);}
static void rtc_hm(int*h,int*m){int hh=cmos(4),mm=cmos(2),b=cmos(0x0B);if(!(b&4)){hh=(hh&15)+(hh>>4)*10;mm=(mm&15)+(mm>>4)*10;}*h=hh;*m=mm;}
#endif
#include "font.h"

/* ---- matematicas ---- */
static float fabs_(float x){return x<0?-x:x;}
static float sqrt_(float x){return x>0?__builtin_sqrtf(x):0;}
static float fmin_(float a,float b){return a<b?a:b;}
static float fmax_(float a,float b){return a>b?a:b;}
static float clamp(float x,float a,float b){return x<a?a:x>b?b:x;}
static int ifl(float f){int i=(int)f;return i-(f<(float)i);}
static int ice(float f){int i=(int)f;return i+(f>(float)i);}
static float fmod_(float x,float m){return x-m*(float)ifl(x/m);}
static float fsin(float x){x-=6.2831853f*(float)ifl(x*0.15915494f+0.5f);float x2=x*x;return x*(1.0f+x2*(-0.16666667f+x2*(0.008333333f+x2*(-0.000198413f+x2*(2.7557e-6f+x2*-2.505e-8f)))));}
static float fcos(float x){return fsin(x+1.5707963f);}
static float fatan2(float y,float x){float ax=fabs_(x),ay=fabs_(y);if(ax==0&&ay==0)return 0;float a=ax>ay?ay/ax:ax/ay,s=a*a,r=((-0.0464964749f*s+0.15931422f)*s-0.327622764f)*s*a+a;if(ay>ax)r=1.57079637f-r;if(x<0)r=3.14159274f-r;return y<0?-r:r;}
static float smooth(float t){t=clamp(t,0,1);return t*t*(3-2*t);}
static float easeo(float t){t=clamp(t,0,1);t=1-t;return 1-t*t*t;}
static u32 seed=12345;
static float rnd(void){seed=seed*1103515245u+12345u;return ((seed>>8)&0xFFFF)/65536.0f;}
static int rndi(int n){return (int)(rnd()*n)%n;}
typedef struct{float x,v;}Sp;
static void spr(Sp*s,float t,float k,float dt){int n=(int)(dt*240)+1;float h=dt/n;while(n--){float a=k*k*(t-s->x)-2*k*s->v;s->v+=a*h;s->x+=s->v*h;}}

/* ---- color ---- */
static u32 lerpc(u32 a,u32 b,float t){int k=(int)(clamp(t,0,1)*256);u32 rb=(((a&0xFF00FF)*(256-k)+(b&0xFF00FF)*k)>>8)&0xFF00FF,g=(((a&0xFF00)*(256-k)+(b&0xFF00)*k)>>8)&0xFF00;return rb|g;}
static float SC=1,OX=0,OY=0,SX=1,GA=1;static int CX0,CY0,CX1,CY1;
#define TX(x) (((x)*SX+OX)*SC)
#define TY(y) (((y)*SX+OY)*SC)
#define TL(l) ((l)*SX*SC)
static void clipall(void){CX0=0;CY0=0;CX1=W;CY1=H;}
static void clipset(float x,float y,float w,float h){CX0=ifl(TX(x));CY0=ifl(TY(y));CX1=ice(TX(x+w));CY1=ice(TY(y+h));if(CX0<0)CX0=0;if(CY0<0)CY0=0;if(CX1>W)CX1=W;if(CY1>H)CY1=H;}
static inline void bl(int x,int y,u32 c,int a){
 if(x<CX0||x>=CX1||y<CY0||y>=CY1||a<=0)return;u32*p=DST+y*W+x;if(a>=255){*p=c;return;}u32 d=*p;
 *p=((((d&0xFF00FF)*(256-a)+(c&0xFF00FF)*a)>>8)&0xFF00FF)|((((d&0xFF00)*(256-a)+(c&0xFF00)*a)>>8)&0xFF00);}
static void span(int y,int x0,int x1,u32 c,int a){if(y<CY0||y>=CY1||a<=0)return;if(x0<CX0)x0=CX0;if(x1>CX1)x1=CX1;if(x1<=x0)return;u32*p=DST+y*W+x0;int n=x1-x0;
 if(a>=255){__asm__ volatile("cld;rep stosl":"+D"(p),"+c"(n):"a"(c):"memory");return;}u32 rb=(c&0xFF00FF)*a,g=(c&0xFF00)*a;int ia=256-a;
 while(n--){u32 d=*p;*p++=((((d&0xFF00FF)*ia+rb)>>8)&0xFF00FF)|((((d&0xFF00)*ia+g)>>8)&0xFF00);}}
static void dimall(u32 c,float al){al*=GA;int a=(int)(al*255);for(int y=CY0;y<CY1;y++)span(y,CX0,CX1,c,a);}

/* ---- formas con bordes suaves (version rapida: filas + enteros) ---- */
static float sdrr(float dx,float dy,float hw,float hh,float r){float qx=fabs_(dx)-hw+r,qy=fabs_(dy)-hh+r,ax=qx>0?qx:0,ay=qy>0?qy:0,m=qx>qy?qx:qy;return sqrt_(ax*ax+ay*ay)+(m<0?m:0)-r;}
static void rrect_(float x,float y,float w,float h,float r,u32 c1,u32 c2,float al){
 float X0=TX(x),Y0=TY(y),X1=TX(x+w),Y1=TY(y+h),R=TL(r),cx=(X0+X1)*.5f,cy=(Y0+Y1)*.5f,hw=(X1-X0)*.5f,hh=(Y1-Y0)*.5f;if(R>hw)R=hw;if(R>hh)R=hh;if(hw<=0||hh<=0)return;
 int ys=ifl(Y0),ye=ice(Y1);if(ys<CY0)ys=CY0;if(ye>CY1)ye=CY1;
 for(int py=ys;py<ye;py++){float fy=py+.5f,dy=fy-cy,vc=clamp(fmin_(fy-Y0,Y1-fy)+.5f,0,1);u32 col=c1==c2?c1:lerpc(c1,c2,(fy-Y0)/(Y1-Y0));
  int a=ice(X0),b=ifl(X1);
  if(fabs_(dy)<=hh-R){span(py,a,b,col,(int)(vc*al*255));
   if(a>b)bl(b,py,col,(int)(clamp(X1-X0,0,1)*vc*al*255));else{bl(a-1,py,col,(int)(clamp(a-X0,0,1)*vc*al*255));bl(b,py,col,(int)(clamp(X1-b,0,1)*vc*al*255));}}
  else if(R<1.5f){span(py,a,b,col,(int)(vc*al*255));bl(a-1,py,col,(int)(clamp(a-X0,0,1)*vc*al*255));bl(b,py,col,(int)(clamp(X1-b,0,1)*vc*al*255));}
  else{float dyc=fy<cy?(Y0+R-fy):(fy-(Y1-R));if(dyc<0)dyc=0;float hwc=R*R-dyc*dyc;hwc=hwc>0?sqrt_(hwc):0;float xl=X0+R-hwc,xr=X1-R+hwc;int ia=ice(xl),ib=ifl(xr);
   span(py,ia,ib,col,(int)(vc*al*255));if(ia>ib){bl(ib,py,col,(int)(clamp(xr-xl,0,1)*vc*al*255));}else{bl(ia-1,py,col,(int)(clamp(ia-xl,0,1)*vc*al*255));bl(ib,py,col,(int)(clamp(xr-ib,0,1)*vc*al*255));}}}}
static void rrect(float x,float y,float w,float h,float r,u32 c1,u32 c2,float al){rrect_(x,y,w,h,r,c1,c2,al*GA);}
static void rect(float x,float y,float w,float h,u32 c,float al){rrect_(x,y,w,h,0,c,c,al*GA);}
static void srect(float x,float y,float w,float h,float r,float width,u32 c,float al){al*=GA;
 float X0=TX(x),Y0=TY(y),X1=TX(x+w),Y1=TY(y+h),R=TL(r),cx=(X0+X1)*.5f,cy=(Y0+Y1)*.5f,hw=(X1-X0)*.5f,hh=(Y1-Y0)*.5f,t=TL(width)*.5f;if(R>hw)R=hw;if(R>hh)R=hh;
 int ys=ifl(Y0-t-1),ye=ice(Y1+t+1);if(ys<CY0)ys=CY0;if(ye>CY1)ye=CY1;
 for(int py=ys;py<ye;py++){float fy=py+.5f,dy=fy-cy;
  if(fabs_(dy)<=hh-R){for(int k=0;k<2;k++){float E=k?X1:X0;for(int px=ifl(E-t-1);px<ice(E+t+1);px++){float cov=clamp(.5f-(fabs_(px+.5f-E)-t),0,1);if(cov>0)bl(px,py,c,(int)(cov*al*255));}}}
  else{int xl=ice(X0+R)+1,xr=ifl(X1-R)-1;int px0=ifl(X0-t-1),px1=ice(X1+t+1);
   for(int px=px0;px<px1;px++){if(px>=xl&&px<=xr){px=xr;float E=fy<cy?Y0:Y1;float cov=clamp(.5f-(fabs_(fy-E)-t),0,1);if(cov>0)span(py,xl,xr+1,c,(int)(cov*al*255));continue;}
    float d=fabs_(sdrr(px+.5f-cx,dy,hw,hh,R)+t)-t,cov=clamp(.5f-d,0,1);if(cov>0)bl(px,py,c,(int)(cov*al*255));}}}}
static int qlow;
static void shadow(float x,float y,float w,float h,float r,float blur,u32 c,float al){if(qlow)return;al*=GA;
 for(int i=0;i<12;i++){float e=blur*(12-i)/12.0f;rrect_(x-e,y-e,w+2*e,h+2*e,r+e,c,c,al*.13f);}}
static void disc(float cx,float cy,float r,u32 c,float al){al*=GA;
 float X=TX(cx),Y=TY(cy),R=TL(r);if(R<=0)return;int ys=ifl(Y-R-1),ye=ice(Y+R+1);if(ys<CY0)ys=CY0;if(ye>CY1)ye=CY1;
 for(int py=ys;py<ye;py++){float dy=py+.5f-Y,ady=fabs_(dy);if(ady>=R+.5f)continue;
  if(R>=3&&ady<R-1){float hw=sqrt_(R*R-dy*dy),xl=X-hw,xr=X+hw;int a=ice(xl),b=ifl(xr);span(py,a,b,c,(int)(al*255));
   bl(a-1,py,c,(int)(clamp(a-xl,0,1)*al*255));bl(b,py,c,(int)(clamp(xr-b,0,1)*al*255));continue;}
  for(int px=ifl(X-R-1);px<ice(X+R+1);px++){float dx=px+.5f-X,cov=clamp(R+.5f-sqrt_(dx*dx+dy*dy),0,1);if(cov>0)bl(px,py,c,(int)(cov*al*255));}}}
static void ring(float cx,float cy,float r,float w,u32 c,float al){al*=GA;
 float X=TX(cx),Y=TY(cy),R=TL(r),t=TL(w)*.5f,ro=R+t+1,ri=R-t-1;int ys=ifl(Y-ro),ye=ice(Y+ro);if(ys<CY0)ys=CY0;if(ye>CY1)ye=CY1;
 for(int py=ys;py<ye;py++){float dy=py+.5f-Y,ady=fabs_(dy);if(ady>=ro)continue;float ho=sqrt_(ro*ro-dy*dy),hi=(ri>0&&ady<ri)?sqrt_(ri*ri-dy*dy):0;
  for(int k=0;k<2;k++){int a=k?ice(X+hi):ifl(X-ho),b=k?ice(X+ho):ice(X-hi);if(hi==0){a=ifl(X-ho);b=ice(X+ho);if(k)break;}
   for(int px=a;px<b;px++){float dx=px+.5f-X,d=fabs_(sqrt_(dx*dx+dy*dy)-R)-t,cov=clamp(.5f-d,0,1);if(cov>0)bl(px,py,c,(int)(cov*al*255));}}}}
static void arc(float cx,float cy,float r,float w,float frac,u32 c,float al){al*=GA;
 float X=TX(cx),Y=TY(cy),R=TL(r),t=TL(w)*.5f,a1=frac*6.2831853f,ro=R+t+1;
 for(int py=ifl(Y-ro);py<ice(Y+ro);py++){if(py<CY0||py>=CY1)continue;float dy=py+.5f-Y;if(fabs_(dy)>=ro)continue;float ho=sqrt_(ro*ro-dy*dy);
  for(int px=ifl(X-ho);px<ice(X+ho);px++){float dx=px+.5f-X,d=fabs_(sqrt_(dx*dx+dy*dy)-R)-t,cov=clamp(.5f-d,0,1);if(cov<=0)continue;
   float an=fatan2(dx,-dy);if(an<0)an+=6.2831853f;if(an<=a1)bl(px,py,c,(int)(cov*al*255));}}}
static u8 GLUT[257];static int glut_ok;
static void glut_init(void){for(int i=0;i<=256;i++){float t=1-sqrt_((float)i/256.0f);GLUT[i]=(u8)(t*t*255);}glut_ok=1;}
static void glow(float cx,float cy,float r,u32 c,float al){al*=GA;if(!glut_ok)glut_init();
 float X=TX(cx),Y=TY(cy),R=TL(r);if(R<1)return;int ix=(int)X,iy=(int)Y,Ri=(int)R,R2=Ri*Ri,inv=(256<<16)/R2,a256=(int)(al*256);
 for(int py=iy-Ri;py<=iy+Ri;py++){if(py<CY0||py>=CY1)continue;int dy=py-iy,dy2=dy*dy;if(dy2>=R2)continue;int hw=(int)sqrt_((float)(R2-dy2)),x0=ix-hw,x1=ix+hw;if(x0<CX0)x0=CX0;if(x1>=CX1)x1=CX1-1;
  u32*p=DST+py*W+x0;for(int px=x0;px<=x1;px++,p++){int dx=px-ix,d2=dx*dx+dy2,idx=(d2*inv)>>16;if(idx>255)continue;int a=(GLUT[idx]*a256)>>8;if(a<=0)continue;u32 d=*p;*p=((((d&0xFF00FF)*(256-a)+(c&0xFF00FF)*a)>>8)&0xFF00FF)|((((d&0xFF00)*(256-a)+(c&0xFF00)*a)>>8)&0xFF00);}}}
static void seg(float x0,float y0,float x1,float y1,float w,u32 c,float al){al*=GA;
 float ax=TX(x0),ay=TY(y0),bx=TX(x1),by=TY(y1),t=TL(w)*.5f,vx=bx-ax,vy=by-ay,L2=vx*vx+vy*vy,L=sqrt_(L2);
 float mnx=fmin_(ax,bx)-t-1,mxx=fmax_(ax,bx)+t+1;int ys=ifl(fmin_(ay,by)-t-1),ye=ice(fmax_(ay,by)+t+1);if(ys<CY0)ys=CY0;if(ye>CY1)ye=CY1;
 for(int py=ys;py<ye;py++){float fy=py+.5f,dy=fy-ay,xa=mnx,xb=mxx;
  if(fabs_(vy)>.2f*L&&L>0){float xc=ax+dy*vx/vy,hw=(t+1)*L/fabs_(vy)+t+1;xa=fmax_(xa,xc-hw);xb=fmin_(xb,xc+hw);}
  for(int px=ifl(xa);px<ice(xb);px++){float dx=px+.5f-ax,u=L2>0?clamp((dx*vx+dy*vy)/L2,0,1):0,ex=dx-u*vx,ey=dy-u*vy,cov=clamp(t+.5f-sqrt_(ex*ex+ey*ey),0,1);if(cov>0)bl(px,py,c,(int)(cov*al*255));}}}
static void poly(const float*p,int n,u32 c1,u32 c2,float al){al*=GA; /* convexo: por filas, bordes con cobertura exacta */
 float xs[8],ys[8],nx[8],ny[8],cc[8],mnx=1e9f,mny=1e9f,mxx=-1e9f,mxy=-1e9f,area=0;
 for(int i=0;i<n;i++){xs[i]=TX(p[i*2]);ys[i]=TY(p[i*2+1]);mnx=fmin_(mnx,xs[i]);mxx=fmax_(mxx,xs[i]);mny=fmin_(mny,ys[i]);mxy=fmax_(mxy,ys[i]);}
 for(int i=0;i<n;i++){int j=(i+1)%n;area+=xs[i]*ys[j]-xs[j]*ys[i];}float sg=area>0?1:-1;
 for(int i=0;i<n;i++){int j=(i+1)%n;float ex=xs[j]-xs[i],ey=ys[j]-ys[i],l=sqrt_(ex*ex+ey*ey)+1e-6f;nx[i]=sg*ey/l;ny[i]=-sg*ex/l;cc[i]=nx[i]*xs[i]+ny[i]*ys[i];}
 int ys0=ifl(mny-1),ye0=ice(mxy+1);if(ys0<CY0)ys0=CY0;if(ye0>CY1)ye0=CY1;
 for(int py=ys0;py<ye0;py++){float fy=py+.5f;u32 col=c1==c2?c1:lerpc(c1,c2,(fy-mny)/(mxy-mny+1e-3f));
  float xl=1e9f,xr=-1e9f;int hits=0;
  for(int i=0;i<n;i++){int j=(i+1)%n;float ya=ys[i],yb=ys[j];if((ya<=fy&&yb>fy)||(yb<=fy&&ya>fy)){float x=xs[i]+(fy-ya)*(xs[j]-xs[i])/(yb-ya);if(x<xl)xl=x;if(x>xr)xr=x;hits++;}}
  int a,b;int full=0;
  if(hits<2||fy-mny<1.5f||mxy-fy<1.5f||xr-xl<4){a=ifl(hits<2?mnx-1:xl-2);b=ice(hits<2?mxx+1:xr+2);}
  else{a=ifl(xl-1.5f);b=ice(xr+1.5f);full=1;}
  int fa=full?ice(xl+1.5f):b,fb=full?ifl(xr-1.5f):b;
  for(int px=a;px<b;px++){if(full&&px>=fa&&px<fb){px=fb-1;span(py,fa,fb,col,(int)(al*255));continue;}
   float d=-1e9f;for(int i=0;i<n;i++){float e=nx[i]*(px+.5f)+ny[i]*fy-cc[i];if(e>d)d=e;}float cov=clamp(.5f-d,0,1);if(cov>0)bl(px,py,col,(int)(cov*al*255));}}}
static void tri(float x,float y,float hw,float h,u32 c,float al){float p[6]={x,y,x+hw,y+h,x-hw,y+h};poly(p,3,c,c,al);}
static void heart(float cx,float cy,float s,u32 c,float al){disc(cx-s*.3f,cy-s*.2f,s*.34f,c,al);disc(cx+s*.3f,cy-s*.2f,s*.34f,c,al);float p[6]={cx-s*.62f,cy-s*.05f,cx+s*.62f,cy-s*.05f,cx,cy+s*.62f};poly(p,3,c,c,al);}

/* ---- texto SDF (Outfit) ---- */
static int cpidx(u32 cp){int lo=0,hi=NGLY-1;while(lo<=hi){int m=(lo+hi)/2;if(CPT[m]==cp)return m;if(CPT[m]<cp)lo=m+1;else hi=m-1;}return -1;}
static u32 nextcp(const char**s){const u8*p=(const u8*)*s;u32 c=*p++;if(c>=0xC0&&c<0xE0){c=((c&31)<<6)|(*p++&63);}else if(c>=0xE0){c=((c&15)<<12)|((p[0]&63)<<6)|(p[1]&63);p+=2;}*s=(const char*)p;return c;}
static float textw(const char*s,float size,int bold,float sp){const GLY*g=bold?GL1:GL0;float k=size/SDF_EM,w=0;int n=0;while(*s){int i=cpidx(nextcp(&s));if(i<0)i=cpidx('?');w+=g[i].adv/16.0f*k+sp;n++;}return w-(n?sp:0);}
static void glyph(const GLY*g,const u8*d,float ox,float oy,float k,u32 c,float al){
 if(!g->w)return;float x0=ox+g->bx*k,y0=oy-g->by*k,x1=x0+g->w*k,y1=y0+g->h*k;
 int iy0=ifl(y0),iy1=ice(y1),ix0=ifl(x0),ix1=ice(x1);if(ix0<CX0)ix0=CX0;if(ix1>CX1)ix1=CX1;if(iy0<CY0)iy0=CY0;if(iy1>CY1)iy1=CY1;if(ix0>=ix1||iy0>=iy1)return;
 const u8*t=d+g->off;int w=g->w,h=g->h,inv=(int)(65536.0f/k),cs=(int)(2*SDF_SPREAD*k*256),a256=(int)(al*256);
 for(int py=iy0;py<iy1;py++){int sv=(int)(((py+.5f)-y0)*(float)inv)-32768,v0=sv>>16,fv=(sv>>8)&255,vv0=v0<0?0:v0>=h?h-1:v0,vv1=v0+1<0?0:v0+1>=h?h-1:v0+1;const u8*r0=t+vv0*w,*r1=t+vv1*w;
  int su=(int)(((ix0+.5f)-x0)*(float)inv)-32768;
  if(k<.7f){int vr=((sv+32768)>>16);vr=vr<0?0:vr>=h?h-1:vr;const u8*rr=t+vr*w;int su2=su+32768;for(int px=ix0;px<ix1;px++,su2+=inv){int ur=su2>>16;ur=ur<0?0:ur>=w?w-1:ur;int cov=128+(((rr[ur]-128)*cs)>>8);if(cov<=0)continue;if(cov>255)cov=255;bl(px,py,c,(cov*a256)>>8);}continue;}
  for(int px=ix0;px<ix1;px++,su+=inv){int u0=su>>16,fu=(su>>8)&255,uu0=u0<0?0:u0>=w?w-1:u0,uu1=u0+1<0?0:u0+1>=w?w-1:u0+1;
   int a=(r0[uu0]*(256-fu)+r0[uu1]*fu)>>8,b=(r1[uu0]*(256-fu)+r1[uu1]*fu)>>8,dd=(a*(256-fv)+b*fv)>>8,cov=128+(((dd-128)*cs)>>8);if(cov<=0)continue;if(cov>255)cov=255;bl(px,py,c,(cov*a256)>>8);}}}
/* align: 0 izquierda, 1 centro, 2 derecha. (x,y) = linea base */
static void text(const char*s,float x,float y,float size,u32 c,float al,int bold,int align,float sp){al*=GA;
 float k=TL(size/SDF_EM);float w=textw(s,size,bold,sp);float ox=TX(x)-(align==1?TL(w)*.5f:align==2?TL(w):0),oy=TY(y);const GLY*g=bold?GL1:GL0;const u8*d=bold?SDF1:SDF0;
 while(*s){int i=cpidx(nextcp(&s));if(i<0)i=cpidx('?');glyph(&g[i],d,ox,oy,k,c,al);ox+=g[i].adv/16.0f*k+TL(sp);}}
/* ================= NUCLEO: servicios para juegos, archivos y cargador .px ================= */
void*memcpy(void*d,const void*s,u32 n){u8*a=d;const u8*b=s;while(n--)*a++=*b++;return d;}
void*memset(void*d,int c,u32 n){u8*a=d;while(n--)*a++=(u8)c;return d;}
static void zero(void*p,int n){u8*b=p;while(n--)*b++=0;}
static int kstrlen(const char*s){int n=0;while(s[n])n++;return n;}
static int kstrcmp(const char*a,const char*b){while(*a&&*a==*b){a++;b++;}return (u8)*a-(u8)*b;}
#include "symtab.h"
static const char*kstage="inicio",*kdetail;
static const char*ksym(u32 a,u32*off){int b=-1;for(int i=0;i<NSYM;i++)if(SYM[i].a<=a&&(b<0||SYM[i].a>SYM[b].a))b=i;if(b<0)return 0;*off=a-SYM[b].a;return SYM[b].n;}
static int over,win,score;static float shake,flash;
typedef struct{float x,y,vx,vy,l;u32 c;}PT;static PT pt[160];static int pti;
static void burst(float x,float y,u32 c,int n){while(n--){PT*p=&pt[pti++%160];float a=rnd()*6.283f,v=60+rnd()*260;p->x=x;p->y=y;p->vx=fcos(a)*v;p->vy=fsin(a)*v;p->l=.4f+rnd()*.5f;p->c=c;}}
typedef struct{char s[28];float x,y,l;u32 c;}FT;static FT ft[8];
static void ftext(const char*s,float x,float y,u32 c){for(int i=0;i<8;i++)if(ft[i].l<=0){int k=0;while(s[k]&&k<26){ft[i].s[k]=s[k];k++;}ft[i].s[k]=0;ft[i].x=x;ft[i].y=y;ft[i].l=1;ft[i].c=c;return;}}
static void tone(int hz,int ms);
static float k_tx(float x){return TX(x);}
static KAPI kapi;
static void kapi_init(void){
 kapi.ver=1;kapi.rrect=rrect;kapi.srect=srect;kapi.shadow=shadow;kapi.disc=disc;kapi.ring=ring;kapi.glow=glow;kapi.seg=seg;kapi.poly=poly;kapi.text=text;kapi.bl=bl;kapi.span=span;kapi.lerpc=lerpc;
 kapi.rnd=rnd;kapi.burst=burst;kapi.ftext=ftext;kapi.tone=tone;kapi.sc=&SC;kapi.ox=&OX;kapi.oy=&OY;kapi.sx=&SX;kapi.cx0=&CX0;kapi.cy0=&CY0;kapi.cx1=&CX1;kapi.cy1=&CY1;kapi.score=&score;kapi.over=&over;kapi.win=&win;kapi.bb=BB;kapi.pw=&W;}
/* ---- registro del arranque ---- */
static char klg[12][72];static int nklg;
static void klog(const char*a,const char*b){if(nklg>=12)return;int i=0;while(a&&*a&&i<68)klg[nklg][i++]=*a++;while(b&&*b&&i<70)klg[nklg][i++]=*b++;klg[nklg][i]=0;nklg++;}
static void klogn(const char*a,int v,const char*b){char t[16];int n=0,d[10],k=0;do{d[k++]=v%10;v/=10;}while(v);while(k)t[n++]='0'+d[--k];t[n]=0;char buf[72];int i=0;while(a&&*a&&i<50)buf[i++]=*a++;for(int j=0;t[j];j++)buf[i++]=t[j];while(b&&*b&&i<70)buf[i++]=*b++;buf[i]=0;klog(buf,0);}
/* ---- sistema de archivos: ISO9660 en memoria + initrd PXFS ---- */
typedef struct{char name[40];const u8*data;u32 size;int src;}KF;static KF kf[48];static int nkf;
static u32 le32(const u8*p){return p[0]|(p[1]<<8)|(p[2]<<16)|((u32)p[3]<<24);}
static int up(int c){return c>='a'&&c<='z'?c-32:c;}
static int ieq(const char*a,const char*b,int n){while(n--){if(up((u8)*a++)!=up((u8)*b++))return 0;}return 1;}
static int has_ext(const char*n,int l,const char*e){int el=0;while(e[el])el++;return l>el&&n[l-el-1]=='.'&&ieq(n+l-el,e,el);}
static int is_game_name(const char*n,int l){return has_ext(n,l,"PX")||has_ext(n,l,"PIXEL");}
static void kf_add(const char*nm,int nl,const u8*d,u32 sz,int src){
 if(nkf>=48||nl<=0||nl>38)return;for(int i=0;i<nkf;i++)if(kstrlen(kf[i].name)==nl&&ieq(kf[i].name,nm,nl))return;
 for(int i=0;i<nl;i++)kf[nkf].name[i]=up((u8)nm[i]);kf[nkf].name[nl]=0;kf[nkf].data=d;kf[nkf].size=sz;kf[nkf].src=src;nkf++;}
static int iso_scan(void){
 if(!iso_ok||iso_sectors<20)return 0;const u8*b=MEM_ISO,*pvd=b+16*2048;u32 lim=iso_sectors*2048;
 if(!(pvd[0]==1&&pvd[1]=='C'&&pvd[2]=='D'&&pvd[3]=='0'&&pvd[4]=='0'&&pvd[5]=='1'))return 0;
 u32 rl=le32(pvd+156+2),rs=le32(pvd+156+10),gl=0,gs=0;int cnt=0;
 if((u64)rl*2048+rs>lim)return 0;
 for(u32 off=0;off<rs;){const u8*r=b+rl*2048+off;if(!r[0]){off=(off/2048+1)*2048;continue;}if(r[32]==5&&(r[25]&2)&&ieq((const char*)r+33,"GAMES",5)){gl=le32(r+2);gs=le32(r+10);}off+=r[0];}
 if(!gl||(u64)gl*2048+gs>lim)return 0;
 for(u32 off=0;off<gs;){const u8*r=b+gl*2048+off;if(!r[0]){off=(off/2048+1)*2048;continue;}int nl=r[32];const char*nm=(const char*)r+33;
  if(!(r[25]&2)&&nl>2){int l=nl;for(int i=0;i<nl;i++)if(nm[i]==';'){l=i;break;}
   u32 fl=le32(r+2),fs=le32(r+10);if(is_game_name(nm,l)&&(u64)fl*2048+fs<=lim){kf_add(nm,l,b+fl*2048,fs,1);cnt++;}}
  off+=r[0];}
 return cnt;}
extern const u8 _binary_initrd_bin_start[],_binary_initrd_bin_end[];
static int initrd_scan(void){const u8*b=_binary_initrd_bin_start;u32 n=(u32)(_binary_initrd_bin_end-_binary_initrd_bin_start),cnt=0;
 if(n<8||b[0]!='P'||b[1]!='X'||b[2]!='F'||b[3]!='S')return 0;u32 c=le32(b+4);
 for(u32 i=0;i<c&&8+(i+1)*40<=n;i++){const u8*e=b+8+i*40;int l=0;while(l<32&&e[l])l++;u32 off=le32(e+32),sz=le32(e+36);if(off+sz<=n&&is_game_name((const char*)e,l)){kf_add((const char*)e,l,b+off,sz,2);cnt++;}}
 return cnt;}
/* ---- cargador de juegos .px / .pixel ---- */
typedef struct{const PXHead*h;PXGame*g;char file[40];}Game;static Game GM[16];static int NG;
static u8*pxmem;
static int px_load(const KF*f){
 const u8*d=f->data;u32 sz=f->size;if(NG>=16||sz<sizeof(PXHead))return -1;const PXHead*h=(const PXHead*)d;
 if(!(h->magic[0]=='P'&&h->magic[1]=='X'&&h->magic[2]=='G'&&h->magic[3]=='1')||h->version!=1)return -2;
 if(h->load_size<sizeof(PXHead)||h->load_size>sz||h->mem_size<h->load_size||h->mem_size>0x80000)return -3;
 if((u64)h->reloc_off+4*(u64)h->nreloc>sz||h->nreloc>20000)return -4;
 u8*base=(u8*)(((u32)pxmem+15)&~15u);u8*dst=base;
 for(u32 i=0;i<h->load_size;i++)dst[i]=d[i];for(u32 i=h->load_size;i<h->mem_size;i++)dst[i]=0;
 for(u32 i=0;i<h->nreloc;i++){u32 o=le32(d+h->reloc_off+4*i);if(o+4>h->load_size)return -5;*(u32*)(dst+o)+=(u32)base;}
 pxmem=base+h->mem_size;
 PXHead*lh=(PXHead*)base;PXGame*(*e)(KAPI*)=(PXGame*(*)(KAPI*))lh->entry;if(lh->entry<(u32)base||lh->entry>=(u32)base+h->load_size)return -6;
 GM[NG].h=lh;GM[NG].g=e(&kapi);{int i=0;while(f->name[i]&&i<39){GM[NG].file[i]=f->name[i];i++;}GM[NG].file[i]=0;}NG++;return 0;}
static void sys_boot(void){
 kapi_init();klog("PixelKernel 1.0  ·  arranque en modo protegido de 32 bits",0);
 {char b[48]="Pantalla VBE ";int n=13,v=W,d[6],k=0;do{d[k++]=v%10;v/=10;}while(v);while(k)b[n++]='0'+d[--k];b[n++]='x';v=H;do{d[k++]=v%10;v/=10;}while(v);while(k)b[n++]='0'+d[--k];const char*q=" · 32 bits";while(*q)b[n++]=*q++;b[n]=0;klog(b,0);}
 klog("Teclado PS/2, temporizador PIT y altavoz del PC",0);
 kstage="leyendo el CD (ISO9660)";int ni=iso_scan();kstage="leyendo el disco de arranque";int nr=initrd_scan();
 if(ni)klogn("Sistema de archivos ISO9660 (CD): ",ni," juegos en /GAMES");else klog("ISO9660: no se pudo leer el CD, se usa el disco de arranque",0);
 klogn("Disco de arranque (PXFS): ",nr," juegos incluidos");
 /* ordenar por nombre */
 for(int i=1;i<nkf;i++){KF t=kf[i];int j=i-1;while(j>=0&&kstrcmp(kf[j].name,t.name)>0){kf[j+1]=kf[j];j--;}kf[j+1]=t;}
 kstage="cargando juegos .px / .pixel";pxmem=MEM_GAMES;int bad=0;for(int i=0;i<nkf;i++){kdetail=kf[i].name;if(px_load(&kf[i])<0)bad++;}kdetail=0;
 klogn("Juegos cargados (.px / .pixel): ",NG,bad?" · con errores":"");klog("Sistema listo",0);}
/* ================= SISTEMA / INTERFAZ ================= */
#define EM 17.0f
enum{S_BOOT,S_HOME,S_LAUNCH,S_GAME};
static int state,tab,zn=1,sel,shsel,setsel,hubon,hsel,favs[16],cc,ccj,gid,hi[16],snd=1,theme,briN=10;
static float T,stime,infot,toastt,tonet,gtm;static char tbuf[64],clk[8]="21:07";static int clkh=-1;
static u8 now[128],prv[128];
static int hit(int k){return now[k]&&!prv[k];}
static void tone(int hz,int ms){if(!snd)return;spk(hz);tonet=ms/1000.0f;}
static void toast(const char*s){int i=0;while(s[i]&&i<62){tbuf[i]=s[i];i++;}tbuf[i]=0;toastt=2.3f;}
static const char*SHN[3]={"Pack Aurora","Coches clásicos","Pixel+"},*SHT[3]={"Expansión de Aurora Siege","Contenido para Neon Drift","Suscripción mensual"},*SHP[3]={"12,99 €","7,99 €","8,99 €"};
static const int SHGA[3]={1,0,4};
#define SHGI(i) (SHGA[i]%(NG?NG:1))
static const u32 ACC[3]={0x7fd6ff,0x6dffb8,0xffc66d};static const char*THN[3]={"Medianoche","Aurora","Ámbar"};
static const char*FXN[5]={"Amigos","Trofeos","Música","Capturas","Apagar"};
static const char*TNM[3]={"Juegos","Tienda","Ajustes"};
static Sp sscroll,stx,stw,svo[3],shub,scc,scs[16];static float sca[16];
static float bca[3],bcb[3];static int bgdirty=1;
#define R8(c) (float)(((c)>>16)&255)
#define G8(c) (float)(((c)>>8)&255)
#define B8(c) (float)((c)&255)
#ifdef TEST32
static int LRr[260*196],LRg[260*196],LRb[260*196];
#else
#define LRr ((int*)0xC00000)
#define LRg ((int*)0xC40000)
#define LRb ((int*)0xC80000)
#endif
static int bgcnt;static void bg_render(void){bgcnt++;
 int LW=W/4+2,LH=H/4+2;
 for(int gy=0;gy<LH;gy++)for(int gx=0;gx<LW;gx++){float px=(float)(gx*4),py=(float)(gy*4),fx=px/W,fy=py/H,t=clamp(((fy+.10f*(1-fx))-.3f)/.7f,0,1);
  float r=4+(bcb[0]-4)*t,g=6+(bcb[1]-6)*t,b=26+(bcb[2]-26)*t;float dx=(px-.85f*W)/(.744f*W),dy=(py-.1f*H)/(.558f*H),ga=clamp(1-sqrt_(dx*dx+dy*dy),0,1);
  r+=(bca[0]-r)*ga;g+=(bca[1]-g)*ga;b+=(bca[2]-b)*ga;float vx=(fx-.5f)/.6f,vy=(fy-.4f)/.6f,vg=1-.4f*clamp((sqrt_(vx*vx+vy*vy)-.55f)/.8f,0,1);
  LRr[gy*LW+gx]=(int)(r*vg*256);LRg[gy*LW+gx]=(int)(g*vg*256);LRb[gy*LW+gx]=(int)(b*vg*256);}
 for(int cy=0;cy<H/4;cy++)for(int yy=0;yy<4;yy++){int y=cy*4+yy;if(y>=H)break;u32*row=BG+y*W;
  for(int cx=0;cx<W/4;cx++){int i00=cy*LW+cx,i01=(cy+1)*LW+cx;int w1=yy,w0=4-yy;
   int r0=(LRr[i00]*w0+LRr[i01]*w1)/4,r1=(LRr[i00+1]*w0+LRr[i01+1]*w1)/4,g0=(LRg[i00]*w0+LRg[i01]*w1)/4,g1=(LRg[i00+1]*w0+LRg[i01+1]*w1)/4,b0=(LRb[i00]*w0+LRb[i01]*w1)/4,b1=(LRb[i00+1]*w0+LRb[i01+1]*w1)/4;
   int dr=(r1-r0)/4,dg=(g1-g0)/4,db=(b1-b0)/4;for(int xx=0;xx<4;xx++){int x=cx*4+xx;if(x<W)row[x]=((r0>>8)<<16)|((g0>>8)<<8)|(b0>>8);r0+=dr;g0+=dg;b0+=db;}}}
 {u32*sv=DST;int a0=CX0,a1=CY0,a2=CX1,a3=CY1;float sg=GA,so=OX,sy=OY,ss=SX;DST=BG;GA=1;OX=OY=0;SX=1;clipall();u32 ac=ACC[theme];
  glow(190,470,330,ac,.10f);glow(880,640,260,ac,.08f);glow(540,70,180,ac,.07f);
  for(int y=0;y<80;y++){int yy=(int)((688+y)*SC);for(int k=0;k<(SC<1?1:1);k++)span(yy,0,W,0x000000,(int)(y*y/80.0f*.5f*255/80));}DST=sv;CX0=a0;CY0=a1;CX1=a2;CY1=a3;GA=sg;OX=so;OY=sy;SX=ss;}}
static void bg_target(float*ta,float*tb){u32 a,b;
 if(state==S_BOOT){a=0x04061a;b=0x000000;}else if(state==S_GAME||state==S_LAUNCH){a=(GM[gid].h->colx);b=(GM[gid].h->coly);if(state==S_GAME){a=lerpc(a,0x04061a,.35f);b=lerpc(b,0x04061a,.45f);}}
 else if(tab==0){a=(GM[sel].h->cola);b=(GM[sel].h->colb);}else if(tab==1){a=(GM[SHGI(shsel)].h->colx);b=(GM[SHGI(shsel)].h->coly);}else{a=ACC[theme];b=0x0a1a5c;}
 ta[0]=R8(a);ta[1]=G8(a);ta[2]=B8(a);tb[0]=R8(b);tb[1]=G8(b);tb[2]=B8(b);}
static void bg_update(float dt){float ta[3],tb[3];bg_target(ta,tb);float f=fmin_(1,dt*6);int ch=bgdirty;
 for(int i=0;i<3;i++){float da=ta[i]-bca[i],db=tb[i]-bcb[i];if(fabs_(da)>.4f||fabs_(db)>.4f){bca[i]+=da*f;bcb[i]+=db*f;ch=1;}else if(da!=0||db!=0){bca[i]=ta[i];bcb[i]=tb[i];ch=1;}}
 if(ch){bg_render();bgdirty=0;}
 u32*d=BB,*s=BG;int n=W*H;
__asm__ volatile("cld;rep movsl":"+S"(s),"+D"(d),"+c"(n)::"memory");
}
/* ---- particulas de ambiente ---- */
static struct{float x,y,r,v;}pp[60];
static void amb_init(void){for(int i=0;i<60;i++){pp[i].x=rnd()*1024;pp[i].y=rnd()*768;pp[i].r=.6f+rnd()*1.8f;pp[i].v=8+rnd()*22;}}
static void amb_draw(float dt){u32 ac=ACC[theme];
 if(!qlow)for(int i=0;i<60;i++){pp[i].y-=pp[i].v*dt;if(pp[i].y<-5){pp[i].y=773;pp[i].x=rnd()*1024;}float x=fmod_(pp[i].x-sscroll.x*.04f*pp[i].r+1024*4,1024);disc(x,pp[i].y,pp[i].r,ac,.25f+pp[i].r*.1f);}}
/* ---- tarjetas ---- */
static void card(int i,float x,float yb,float w,float h,float a,int on){float y=yb-h;
 if(on)shadow(x,y+22,w,h,17,48,(GM[i].h->colx),.5f*a);
 rrect(x,y,w,h,17,lerpc((GM[i].h->colx),0xffffff,.08f),(GM[i].h->coly),a);
 {int a0=CX0,a1=CY0,a2=CX1,a3=CY1;float save=GA;GA=a;clipset(x,y,w,h);float bob=on?fsin(T*1.6f)*5:0;GM[i].g->cover(x,y+bob,w,h,T);
  if(on){float sx=x-120+fmod_(T*180,w+360);float p[8]={sx,y,sx+36,y,sx+36-h*.4f,y+h,sx-h*.4f,y+h};poly(p,4,0xffffff,0xffffff,.28f);}
  GA=save;CX0=a0;CY0=a1;CX1=a2;CY1=a3;}
 text((GM[i].h->name),x+14,yb-14,21,0xffffff,a,1,0,0);
 if(on&&zn==1)srect(x-4,y-4,w+8,h+8,20,3.4f,0xffffff,1);}
static void kbd(float*x,const char*k,const char*l){float kw=textw(k,14,1,0)+16,lw=textw(l,16,0,0);rrect(*x,720,kw,24,12,0x000000,0x000000,.0f);srect(*x,720,kw,24,12,1.6f,0xffffff,.7f);text(k,*x+kw/2,737,14,0xffffff,1,1,1,0);text(l,*x+kw+9,738,16,0xffffff,.9f,0,0,0);*x+=kw+9+lw+30;}
static void hints(void){
 struct{const char*k,*l;}it[6];int n=0;
 if(state==S_GAME){it[n].k="↑↓";it[n].l="";n=0;return;}
 if(cc){it[n].k="←→";it[n++].l="Mover";it[n].k="Intro";it[n++].l="Elegir";it[n].k="Esc";it[n++].l="Cerrar";}
 else if(hubon){it[n].k="↑↓";it[n++].l="Mover";it[n].k="Intro";it[n++].l="Elegir";it[n].k="Esc";it[n++].l="Atrás";it[n].k="H";it[n++].l="Centro";}
 else{it[n].k="←→";it[n++].l="Mover";it[n].k="Q E";it[n++].l="Pestañas";it[n].k="Intro";it[n++].l=zn==0?"Entrar":tab==0?"Abrir":tab==1?"Comprar":"Cambiar";it[n].k="Esc";it[n++].l="Atrás";it[n].k="H";it[n++].l="Centro";}
 float tot=0;for(int i=0;i<n;i++)tot+=textw(it[i].k,14,1,0)+16+9+textw(it[i].l,16,0,0)+30;float x=1024-54-tot+30;for(int i=0;i<n;i++)kbd(&x,it[i].k,it[i].l);}
static void header(void){
 float tx[3],tw_[3];float x=54;for(int i=0;i<3;i++){tw_[i]=textw(TNM[i],25.6f,i==tab,0);tx[i]=x;x+=tw_[i]+41;}
 for(int i=0;i<3;i++)text(TNM[i],tx[i],62,25.6f,0xffffff,i==tab?1:.5f,i==tab,0,0);
 spr(&stx,tx[tab],18,.016f);spr(&stw,tw_[tab],18,.016f);
 if(zn==0)shadow(stx.x,70,stw.x,3.4f,1.7f,16,ACC[theme],.8f);rrect(stx.x,70,stw.x,3.4f,1.7f,zn==0?ACC[theme]:0xffffff,zn==0?ACC[theme]:0xffffff,1);
 rrect(758,36,128,30,15,0xffffff,0xffffff,.1f);disc(776,51,5,0x8a90ad,1);text("Teclado",792,57,16,0xffffff,.9f,0,0,0);
 text(clk,934,57,20,0xffffff,.9f,0,2,0);disc(1000,51,17,lerpc(ACC[theme],0xffffff,.1f),1);text("P",1000,58,19,0x04061a,1,1,1,0);}
static void tab_games(float ofs,float al){
 float pitch=12.5f*EM;float save=GA;GA=al;OX=ofs;
 for(int pass=0;pass<2;pass++)for(int i=0;i<NG;i++){if((i==sel)!=pass)continue;float s=scs[i].x,w=11*EM*s,h=14.5f*EM*s;float d=i*pitch-sscroll.x,ex=clamp(d/pitch,0,1)*2*EM;if(d<-pitch*1.5f)continue;card(i,54+d+ex,444,w,h,sca[i],i==sel);}
 float t0=infot;
 #define EA(k) easeo((t0-(k)*.07f)/.55f)
 {float a=EA(0);text((GM[sel].h->name),54,540+(1-a)*22,54.6f,0xffffff,a,1,0,0);}
 {float a=EA(1);char b[80];int n=0;const char*g=(GM[sel].h->genre);while(*g)b[n++]=*g++;b[n++]=' ';b[n++]=0xC2;b[n++]=0xB7;b[n++]=' ';char t[8];int hv=(GM[sel].h->hours),m=0;if(hv>=10){t[m++]='0'+hv/10;}t[m++]='0'+hv%10;for(int q=0;q<m;q++)b[n++]=t[q];const char*u=" h jugadas";while(*u)b[n++]=*u++;if(hi[sel]){const char*r="  ·  Récord ";while(*r)b[n++]=*r++;int v=hi[sel],dd[8],k=0;do{dd[k++]=v%10;v/=10;}while(v);while(k)b[n++]='0'+dd[--k];}b[n]=0;text(b,54,576+(1-a)*22,21,0xffffff,a*.85f,0,0,0);}
 {float a=EA(2);text((GM[sel].h->desc),54,607+(1-a)*22,18.7f,0xffffff,a*.7f,0,0,0);}
 {float a=EA(3);char b[24]="Trofeos ";int n=8,v=(GM[sel].h->trophy);if(v>=10)b[n++]='0'+v/10;b[n++]='0'+v%10;b[n++]='%';b[n]=0;text(b,54,642+(1-a)*22,17,0xffffff,a*.9f,0,0,0);rrect(160,632,180,8,4,0xffffff,0xffffff,.22f*a);rrect(160,632,180*(GM[sel].h->trophy)/100,8,4,ACC[theme],ACC[theme],a);}
 {float a=EA(4);float pu=fmod_(T/2.2f,1);float y=662+(1-a)*22;if(zn==1)srect(54-pu*10,y-pu*10,150+pu*20,44+pu*20,22+pu*10,2,0xffffff,.28f*(1-pu)*a);rrect(54,y,150,44,22,0xffffff,0xffffff,a*(zn==1?1:.7f));text("Jugar",129,y+29,22,0x0b1330,a,1,1,0);}
 OX=0;GA=save;}
static void tab_shop(float ofs,float al){float save=GA;GA=al;OX=ofs;
 for(int i=0;i<3;i++){int on=zn==1&&i==shsel;float w=288,h=290,x=54+i*(w+25.5f),y=170-(on?10:0);float a=on?1:.62f;int g=SHGI(i);
  if(on)shadow(x,y+18,w,h,17,40,(GM[g].h->colx),.5f);rrect(x,y,w,h,17,(GM[g].h->colx),(GM[g].h->coly),a);
  {int a0=CX0,a1=CY0,a2=CX1,a3=CY1;float s2=GA;GA=a*al;clipset(x,y,w,h-80);GM[g].g->cover(x,y,w,h-80,T);GA=s2;CX0=a0;CY0=a1;CX1=a2;CY1=a3;}
  text(SHN[i],x+22,y+h-86,27,0xffffff,a,1,0,0);text(SHT[i],x+22,y+h-58,18,0xffffff,a*.85f,0,0,0);text(SHP[i],x+22,y+h-22,22,0xffffff,a,1,0,0);
  if(on)srect(x-4,y-4,w+8,h+8,20,3.4f,0xffffff,1);}
 OX=0;GA=save;}
static void tab_set(float ofs,float al){float save=GA;GA=al;OX=ofs;static const char*L[5]={"Tema","Sonido","Brillo","Salida de vídeo","Núcleo"};
 for(int i=0;i<5;i++){int on=zn==1&&i==setsel;float x=54+(on?17:0),y=150+i*66,w=750;rrect(x,y,w,56,15,on?0xffffff:0xffffff,on?0xffffff:0xffffff,on?1:.07f);
  u32 fg=on?0x0b1330:0xffffff;text(L[i],x+22,y+36,22,fg,1,on,0,0);
  if(i==0)text(THN[theme],x+w-22,y+36,18,fg,1,1,2,0);else if(i==1)text(snd?"Activado":"Desactivado",x+w-22,y+36,18,fg,1,1,2,0);
  else if(i==2){rrect(x+w-22-205,y+24,205,8,4,fg,fg,.3f);rrect(x+w-22-205,y+24,205*(briN-3)/7.0f,8,4,fg,fg,1);}
  else if(i==3)text("1024 × 768 · 32 bits",x+w-22,y+36,18,fg,1,1,2,0);else{char b[40]="PixelKernel 1.0 · ";int n=19;int v=NG;if(v>=10)b[n++]='0'+v/10;b[n++]='0'+v%10;const char*q=" juegos";while(*q)b[n++]=*q++;b[n]=0;text(b,x+w-22,y+36,18,fg,1,1,2,0);}}
 OX=0;GA=save;}
static void hub_draw(void){float h=shub.x;if(h<=.01f)return;float save=GA;
 dimall(0x03051a,.78f*clamp(h,0,1));GA=clamp(h,0,1);
 float cx=54-(1-clamp(h,0,1))*70,cy=205;shadow(cx,cy+24,272,358,20,60,(GM[sel].h->colx),.55f);rrect(cx,cy,272,358,20,lerpc((GM[sel].h->colx),0xffffff,.08f),(GM[sel].h->coly),1);
 {int a0=CX0,a1=CY0,a2=CX1,a3=CY1;clipset(cx,cy,272,358);GM[sel].g->cover(cx,cy,272,358,T);CX0=a0;CY0=a1;CX1=a2;CY1=a3;}srect(cx-4,cy-4,280,366,24,3.4f,0xffffff,1);
 float rx=380;text((GM[sel].h->name),rx,262,58,0xffffff,1,1,0,0);
 {char b[64];int n=0;const char*g=(GM[sel].h->genre);while(*g)b[n++]=*g++;const char*u=" · ";while(*u)b[n++]=*u++;int hv=(GM[sel].h->hours);if(hv>=10)b[n++]='0'+hv/10;b[n++]='0'+hv%10;u=" h jugadas";while(*u)b[n++]=*u++;b[n]=0;text(b,rx,296,21,0xffffff,.85f,0,0,0);}
 for(int i=0;i<3;i++){int on=hsel==i;float x=rx+(on?14:0),y=330+i*62;rrect(x,y,222,50,25,0xffffff,0xffffff,on?1:.12f);const char*l=i==0?"Jugar":i==1?(favs[sel]?"Favorito  ♥":"Favorito"):"Compartir";
  if(i==1&&favs[sel]){text("Favorito",x+28,y+33,22,on?0x0b1330:0xffffff,1,1,0,0);heart(x+176,y+25,16,0xff5c8a,1);}else text(l,x+28,y+33,22,on?0x0b1330:0xffffff,1,1,0,0);}
 {int g=(GM[sel].h->trophy);int n[4]={g>80,(g+10)/20,(g+5)/10,(g+2)/5},mx[4]={1,5,10,20};static const char*nm[4]={"Platino","Oro","Plata","Bronce"};static const u32 col[4]={0xcfe9ff,0xffd24a,0xd5dae6,0xd98b4a};
  float prog=easeo((stime-.45f)/1.3f);for(int k=0;k<4;k++){float x=rx+36+k*110,y=600;ring(x,y,32,5,0xffffff,.15f);arc(x,y,32,5,prog*clamp((float)n[k]/mx[k],0,1),col[k],1);char b[8];b[0]='0'+n[k]/10%10;b[1]='0'+n[k]%10;b[2]=0;text(n[k]>=10?b:b+1,x,y+9,23,0xffffff,1,1,1,0);text(nm[k],x,y+56,15,0xffffff,.75f,0,1,0);}}
 GA=save;}
static void icon(int k,float x,float y,u32 c){
 if(k==0){disc(x,y-8,8,c,1);rrect(x-14,y+3,28,15,7,c,c,1);}
 else if(k==1){float a[6]={x,y-17,x+15,y+10,x-15,y+10},b[6]={x,y+17,x+15,y-10,x-15,y-10};poly(a,3,c,c,1);poly(b,3,c,c,1);}
 else if(k==2){disc(x-6,y+9,7,c,1);seg(x+1,y+9,x+1,y-13,3,c,1);seg(x+1,y-13,x+13,y-8,4,c,1);}
 else if(k==3){rrect(x-17,y-11,34,24,6,c,c,1);rect(x-8,y-15,16,6,c,1);disc(x,y+1,7,0x101634,1);disc(x,y+1,3.5f,c,1);}
 else{ring(x,y+2,13,3.5f,c,1);seg(x,y-17,x,y+1,4,c,1);}}
static void cc_draw(void){float h=scc.x;if(h<=.01f)return;float save=GA;float c=clamp(h,0,1);dimall(0x00000a,.4f*c);GA=c;
 float w=1024-108,hh=190,x=54,y=768-34-hh+(1-h)*260;rrect(x,y,w,hh,26,0x101634,0x101634,.9f);srect(x,y,w,hh,26,1.5f,0xffffff,.18f);
 text("Centro de control",x+34,y+50,22,0xffffff,1,1,0,0);
 for(int i=0;i<5;i++){int on=i==ccj;float cx=x+34+34+i*95,cy=y+112,r=on?40:34;if(on){glow(cx,cy,r*2.2f,ACC[theme],.5f);}disc(cx,cy,r,on?0xffffff:0xffffff,on?1:.13f);if(on)ring(cx,cy,r+5,3,ACC[theme],1);icon(i,cx,cy,on?0x0b1330:0xffffff);}
 text(FXN[ccj],x+34,y+hh-18,20,0xffffff,.85f,0,0,0);GA=save;}
static void toast_draw(void){if(toastt<=0)return;float a=clamp(fmin_(toastt/.3f,(2.3f-toastt)/.25f),0,1),w=textw(tbuf,19,0,0)+54;float save=GA;GA=a;float y=106-(1-a)*20;rrect(512-w/2,y,w,42,21,0x0a0e24,0x0a0e24,.92f);srect(512-w/2,y,w,42,21,1.4f,0xffffff,.25f);text(tbuf,512,y+28,19,0xffffff,1,0,1,0);GA=save;}
/* ---- entrada ---- */
#define KL (hit(0x4B)||hit(0x1E))
#define KR (hit(0x4D)||hit(0x20))
#define KU (hit(0x48)||hit(0x11))
#define KD (hit(0x50)||hit(0x1F))
#define KE (hit(0x1C)||hit(0x39))
static void setsel_game(int v){sel=v;infot=0;}
static void adjust(int d){if(setsel==0){theme=(theme+d+3)%3;bgdirty=1;}else if(setsel==1)snd^=1;else if(setsel==2)briN=(int)clamp((float)(briN+d),3,10);else return;tone(900,40);}
static void home_input(void){
 if(cc){if(KL){ccj=(ccj+4)%5;tone(700,30);}else if(KR){ccj=(ccj+1)%5;tone(700,30);}else if(hit(0x01)||hit(0x23)||KD){cc=0;tone(400,50);}
  else if(KE){cc=0;toast(ccj==4?"Es un concepto: la consola no se apaga":ccj==0?"Amigos: próximamente":ccj==1?"Trofeos: próximamente":ccj==2?"Música: próximamente":"Capturas: próximamente");tone(900,60);}return;}
 if(hit(0x23)){cc=1;ccj=0;tone(784,80);return;}
 if(hubon){if(KU){hsel=(hsel+2)%3;tone(700,30);}else if(KD){hsel=(hsel+1)%3;tone(700,30);}else if(hit(0x01)){hubon=0;tone(400,50);}
  else if(KE){if(hsel==0){state=S_LAUNCH;stime=0;gid=sel;tone(660,100);}else if(hsel==1){favs[sel]^=1;toast(favs[sel]?"Añadido a favoritos":"Quitado de favoritos");tone(900,50);}else{toast("Compartir: próximamente");tone(900,50);}}return;}
 if(hit(0x10)||hit(0x0F)||(zn==0&&KL)){tab=(tab+(hit(0x0F)?1:2))%3;infot=0;tone(560,40);return;}
 if(hit(0x12)||(zn==0&&KR)){tab=(tab+1)%3;infot=0;tone(560,40);return;}
 if(zn==0){if(KD||KE){zn=1;tone(700,40);}return;}
 if(tab==0){if(KR&&sel<NG-1){setsel_game(sel+1);tone(700,30);}if(KL&&sel>0){setsel_game(sel-1);tone(700,30);}if(KU||hit(0x01)){zn=0;tone(400,40);}if(KE){hubon=1;hsel=0;stime=0;tone(784,80);}}
 else if(tab==1){if(KR&&shsel<2){shsel++;tone(700,30);}if(KL&&shsel>0){shsel--;tone(700,30);}if(KU||hit(0x01)){zn=0;tone(400,40);}if(KE){char b[64]="Añadido a la biblioteca: ";int n=0;while(b[n])n++;const char*q=SHN[shsel];while(*q)b[n++]=*q++;b[n]=0;toast(b);tone(900,60);}}
 else{if(KU){if(setsel==0)zn=0;else setsel--;tone(700,30);}if(KD&&setsel<4){setsel++;tone(700,30);}if(hit(0x01)){zn=0;tone(400,40);}if(KL)adjust(-1);if(KR)adjust(1);if(KE&&(setsel==0||setsel==1))adjust(1);}}
static void home_anim(float dt){
 spr(&sscroll,sel*12.5f*EM,12,dt);for(int i=0;i<NG;i++){spr(&scs[i],i==sel?1.18f:1,16,dt);sca[i]+=((i==sel?1:.5f)-sca[i])*fmin_(1,dt*10);}
 for(int i=0;i<3;i++)spr(&svo[i],i==tab?0:(i<tab?-110:110),12,dt);
 spr(&shub,hubon?1:0,14,dt);spr(&scc,cc?1:0,14,dt);infot+=dt;stime+=dt;
 int h,m;rtc_hm(&h,&m);if(h!=clkh||1){clkh=h;clk[0]='0'+h/10;clk[1]='0'+h%10;clk[3]='0'+m/10;clk[4]='0'+m%10;}}
static void home_draw(float dt){
 bg_update(dt);amb_draw(dt);header();
 for(int i=0;i<3;i++){float a=clamp(1-fabs_(svo[i].x)/90,0,1);if(a<.03f)continue;if(i==0)tab_games(svo[i].x,a);else if(i==1)tab_shop(svo[i].x,a);else tab_set(svo[i].x,a);}
 hub_draw();cc_draw();hints();toast_draw();}
/* ---- arranque ---- */
static void boot_frame(float dt){
 stime+=dt;fill_black:
 {u32*p=BB;int n=W*H;__asm__ volatile("cld;rep stosl":"+D"(p),"+c"(n):"a"(0):"memory");}
 float k=stime;
 for(int b=0;b<4;b++){float f=k-b*.3f;if(f>0&&f<2.8f){float p=f/2.8f,a=p<.4f?p/.4f:(1-p)/.6f;float x0=(.18f+b*.24f)*1024+p*400;seg(x0-220,-60,x0+260,830,5,ACC[0],a*.9f);}}
 float lp=clamp(k/2.0f,0,1);float al=easeo(k/1.2f),sp=22-16*easeo(k/1.8f);
 glow(512,330,240,ACC[0],.18f*al);text("PIXEL 1",512,372,92,0xffffff,al,0,1,sp*1.5f);
 if(k>1.0f)text("PixelOS 2.0",512,428,28,0xffffff,easeo((k-1)/.8f)*.8f,0,1,3);
 rrect(412,520,200,6,3,0xffffff,0xffffff,.15f);rrect(412,520,200*clamp(k/4.4f,0,1),6,3,ACC[0],ACC[0],1);
 for(int i=0;i<nklg;i++){float t=k-.5f-i*.3f;if(t<=0)break;float a=easeo(t/.3f);text("[ OK ]",54,70+i*24,15,0x6dffb8,a,1,0,0);text(klg[i],122,70+i*24,15,0xffffff,a*.8f,0,0,0);}
 if(k>.4f&&k<.5f)tone(523,150);if(k>1.2f&&k<1.3f)tone(784,200);
 if(k>4.6f||(k>.6f&&(hit(0x1C)||hit(0x39)))){state=S_HOME;stime=0;infot=0;bgdirty=1;tone(880,100);}
}
/* ---- lanzamiento y partida ---- */
static float cdn,pz,nrf;static int nr,hiwarn;
static float gpt;static int ovp;
static void startgame(int g){gid=g;state=S_GAME;over=0;win=0;score=0;cdn=3.2f;pz=0;nr=0;ovp=0;shake=0;flash=0;zero(pt,sizeof pt);zero(ft,sizeof ft);gtm=0;
 GM[g].g->init();tone(660,100);}
static void launch_frame(float dt){
 if(hit(0x01)){state=S_HOME;tone(400,50);return;}
 stime+=dt;home_anim(dt);home_draw(dt);
 float p=clamp(stime/.9f,0,1);p=p<.5f?2*p*p:1-2*(1-p)*(1-p);float r=p*1500;float cx=.3f*W,cy=.6f*H;
 for(int y=0;y<H;y++){float dy=y-cy;if(fabs_(dy)>=r)continue;float hw=sqrt_(r*r-dy*dy);u32 c=lerpc((GM[gid].h->coly),0x04061a,(float)y/H*.9f);float gx=.0f;(void)gx;span(y,ifl(cx-hw),ice(cx+hw),c,255);}
 if(p>0.9f){float fa=clamp((stime-.8f)/.3f,0,1);glow(.3f*1024,.6f*768,520,(GM[gid].h->colx),.55f*fa);}
 float a=clamp((stime-.7f)/.4f,0,1);GA=a;text((GM[gid].h->genre),512,330,21,0xffffff,.8f,0,1,0);text((GM[gid].h->name),512,408,72,0xffffff,1,1,1,0);
 rrect(427,452,170,8,4,0xffffff,0xffffff,.2f);rrect(427,452,170*clamp((stime-.9f)/1.1f,0,1),8,4,0xffffff,0xffffff,1);GA=1;
 if(stime>2.1f)startgame(gid);}
static In getin(void){In i;i.x=(float)((now[0x4D]||now[0x20])-(now[0x4B]||now[0x1E]));i.y=(float)((now[0x50]||now[0x1F])-(now[0x48]||now[0x11]));i.a=now[0x1C]||now[0x39]||now[0x2C];return i;}
static void game_frame(float dt){
 if(dt>.05f)dt=.05f;
 if(hit(0x01)){state=S_HOME;stime=1;tone(400,50);return;}
 if(hit(0x19)&&cdn<=0&&!over)pz=!pz;
 In in=getin();gtm+=dt;
 if(!pz){
  if(cdn>0){cdn-=dt;}else if(!over){gpt=dt;GM[gid].g->step(dt,in);
   if(over){nr=score>hi[gid];if(nr)hi[gid]=score;shake=.5f;flash=.5f;tone(180,500);}}
  else if(hit(0x1C)||hit(0x39)){int g=gid;startgame(g);cdn=1.2f;return;}
  for(int i=0;i<160;i++)if(pt[i].l>0){pt[i].x+=pt[i].vx*dt;pt[i].y+=pt[i].vy*dt;float f=1-2.4f*dt;pt[i].vx*=f;pt[i].vy*=f;pt[i].l-=dt;}
  for(int i=0;i<8;i++)if(ft[i].l>0){ft[i].y-=36*dt;ft[i].l-=dt*1.1f;}
  shake=fmax_(0,shake-dt);flash=fmax_(0,flash-dt);}
 bg_update(dt);amb_draw(dt);
 /* campo */
 float fx=32,fy=84;SX=1.2f;OX=fx;OY=fy;
 shadow(0,0,800,500,17,80,(GM[gid].h->colx),.5f);rrect(0,0,800,500,14,0x04061a,(GM[gid].h->coly),1);
 clipset(0,0,800,500);
 if(shake>0){OX=fx+(rnd()-.5f)*shake*20;OY=fy+(rnd()-.5f)*shake*20;}
 GM[gid].g->draw();
 for(int i=0;i<160;i++)if(pt[i].l>0)disc(pt[i].x,pt[i].y,2.4f,pt[i].c,clamp(pt[i].l*2,0,1));
 for(int i=0;i<8;i++)if(ft[i].l>0)text(ft[i].s,ft[i].x,ft[i].y,18,ft[i].c,clamp(ft[i].l*1.5f,0,1),1,1,0);
 OX=fx;OY=fy;
 if(!qlow)for(int i=0;i<40;i++){float a=.22f*(1-i/40.0f);rect(0,i,800,1,0,a);rect(0,499-i,800,1,0,a);rect(i,0,1,500,0,a);rect(799-i,0,1,500,0,a);}
 if(flash>0)dimall(0xffffff,flash*.7f);
 rrect(12,10,300,42,21,0x03051a,0x03051a,.5f);{char b[40]="Puntos ";int n=7,v=score,dd[10],k=0;do{dd[k++]=v%10;v/=10;}while(v);while(k)b[n++]='0'+dd[--k];b[n]=0;text(b,30,38,22,0xffffff,1,1,0,0);
  char c[24]="Récord ";n=8;v=score>hi[gid]?score:hi[gid];k=0;do{dd[k++]=v%10;v/=10;}while(v);while(k)c[n++]='0'+dd[--k];c[n]=0;text(c,300,37,16,0xffffff,.7f,0,2,0);}
 text(GM[gid].h->hint,16,488,14,0xffffff,.6f,0,0,0);
 if(cdn>0){dimall(0x03051a,.45f);text((GM[gid].h->name),400,200,32,0xffffff,1,1,1,0);int n=(int)(cdn-.2f+.999f);float f=fmod_(cdn-.2f,1);if(cdn-.2f<=0){text("¡Ya!",400,330,110,(GM[gid].h->colx),1,1,1,0);}else{char d[2]={'0'+(n>9?9:n),0};text(d,400,330,90+f*50,(GM[gid].h->colx),1,1,1,0);}}
 else if(pz){dimall(0x03051a,.6f);text("Pausa",400,250,64,0xffffff,1,1,1,0);text("P: continuar   ·   Esc: salir",400,300,22,0xffffff,.85f,0,1,0);}
 else if(over){float a=clamp(gtm*0,0,1);(void)a;dimall(0x03051a,.7f);if(nr)text("¡Nuevo récord!",400,172,28,(GM[gid].h->colx),1,1,1,0);text(win?"¡Victoria!":"Fin de la partida",400,235,50,win?(GM[gid].h->colx):0xffffff,1,1,1,0);
  char b[40]="Puntos ";int n=7,v=score,dd[10],k=0;do{dd[k++]=v%10;v/=10;}while(v);while(k)b[n++]='0'+dd[--k];const char*m="   ·   Récord ";while(*m)b[n++]=*m++;v=hi[gid];k=0;do{dd[k++]=v%10;v/=10;}while(v);while(k)b[n++]='0'+dd[--k];b[n]=0;text(b,400,282,24,0xffffff,1,0,1,0);text("Intro: reintentar   ·   Esc: salir",400,332,22,0xffffff,.85f,0,1,0);}
 SX=1;OX=0;OY=0;clipall();}
/* ---- bucle principal ---- */
static void os_init(void){sys_boot();SC=H/768.0f;clipall();for(int i=0;i<16;i++){scs[i].x=1;sca[i]=.5f;}scs[0].x=1.18f;sca[0]=1;stx.x=54;stw.x=100;svo[0].x=0;svo[1].x=110;svo[2].x=110;amb_init();state=S_BOOT;bgdirty=1;float ta[3],tb[3];bg_target(ta,tb);for(int i=0;i<3;i++){bca[i]=ta[i];bcb[i]=tb[i];}}
static void os_frame(float dt){
 poll_keys();for(int i=0;i<128;i++){prv[i]=now[i];now[i]=keys[i];}
 kstage=state==S_BOOT?"animación de arranque":state==S_HOME?"menú principal":state==S_LAUNCH?"lanzando un juego":"partida";kdetail=state==S_GAME?GM[gid].h->name:0;
 T+=dt;if(tonet>0){tonet-=dt;if(tonet<=0)spk_off();}if(toastt>0)toastt-=dt;
 if(state==S_BOOT)boot_frame(dt);
 else if(state==S_HOME){if(NG==0){bg_update(dt);amb_draw(dt);header();text("No se encontraron juegos (.px / .pixel)",512,370,30,0xffffff,1,1,1,0);text("Añade archivos .px o .pixel a la carpeta /GAMES del CD",512,415,20,0xffffff,.8f,0,1,0);}else{home_input();home_anim(dt);home_draw(dt);}}
 else if(state==S_LAUNCH)launch_frame(dt);
 else game_frame(dt);}
#ifdef TEST32
#define KHALT return
static void present(void){}
#else
#define KHALT for(;;)__asm__ volatile("hlt")
static void present(void);
#endif
static void hex32(char*b,u32 v){for(int i=0;i<8;i++){int d=(v>>(28-4*i))&15;b[i]=d<10?'0'+d:'a'+d-10;}b[8]=0;}
static int cat(char*d,int n,const char*s){while(*s&&n<70)d[n++]=*s++;d[n]=0;return n;}
static int cath(char*d,int n,u32 v,int digits){for(int i=digits-1;i>=0;i--){int x=(v>>(4*i))&15;if(n<70)d[n++]=x<10?'0'+x:'a'+x-10;}d[n]=0;return n;}
static void kscreen(const char*title,const char*l1,const char*l2,const char*l3,const char*l4,const char*l5,const char*l6){
 if(W<=0||H<=0)KHALT;
 SC=H/768.0f;OX=OY=0;SX=1;GA=1;clipall();for(int y=0;y<H;y++)span(y,0,W,lerpc(0x3a0a14,0x14040a,(float)y/H)&0xFFFFFF,255);
 text(title,64,150,46,0xffffff,1,1,0,0);const char*L[6]={l1,l2,l3,l4,l5,l6};float y=215;
 for(int i=0;i<6;i++)if(L[i]){text(L[i],64,y,i==0?28:21,i==0?0xffb3b3:0xffffff,i==0?1:.85f,i==0,0,0);y+=i==0?44:36;}
 text("Anota estas líneas (o haz una foto) para diagnosticar el fallo.",64,y+30,19,0xffffff,.6f,0,0,0);
 present();KHALT;}
static void kfatal(const char*a,const char*b){kscreen("PixelKernel: no se puede continuar",a,b,0,0,0,0);}
void kexc(u32*f){
 static const char*nm[17]={"División por cero","Depuración","Interrupción no enmascarable","Punto de interrupción","Desbordamiento","Límite excedido","Instrucción no válida","Dispositivo no disponible","Doble fallo","Segmento del coprocesador","TSS no válido","Segmento ausente","Fallo de pila","Protección general","Fallo de página","Reservado","Error de coma flotante"};
 u32 n=f[0],err=f[1],eip=f[2],cs=f[3],efl=f[4];char l1[76],l2[76],l3[76],l4[76],l5[76];int k=0;
 k=cat(l1,0,"Excepción #");if(n>=10)l1[k++]='0'+n/10;l1[k++]='0'+n%10;l1[k]=0;k=cat(l1,k," · ");cat(l1,k,n<17?nm[n]:"Desconocida");
 k=cat(l2,0,"EIP 0x");k=cath(l2,k,eip,8);k=cat(l2,k,"  código 0x");k=cath(l2,k,err,4);k=cat(l2,k,"  CS 0x");k=cath(l2,k,cs,4);k=cat(l2,k,"  EFLAGS 0x");cath(l2,k,efl,4);
 {u32 off=0;const char*s=ksym(eip,&off);int g=-1;for(int i=0;i<NG;i++)if(eip>=(u32)GM[i].h&&eip<(u32)GM[i].h+GM[i].h->mem_size){g=i;off=eip-(u32)GM[i].h;}
  if(g>=0){k=cat(l3,0,"En el juego ");k=cat(l3,k,GM[g].h->name);k=cat(l3,k," (archivo ");k=cat(l3,k,GM[g].file);k=cat(l3,k,"), desplazamiento 0x");cath(l3,k,off,5);}
  else if(s){k=cat(l3,0,"En la función ");k=cat(l3,k,s);k=cat(l3,k," + 0x");cath(l3,k,off,4);}else cat(l3,0,"En una dirección fuera del núcleo y de los juegos");}
 k=cat(l4,0,"Etapa: ");k=cat(l4,k,kstage);if(kdetail){k=cat(l4,k," (");k=cat(l4,k,kdetail);cat(l4,k,")");}
 k=cat(l5,0,"Bytes en EIP:");if(eip<0x1000000){for(int i=0;i<8;i++){l5[k++]=' ';k=cath(l5,k,*(volatile u8*)(eip+i),2);}l5[k]=0;}else cat(l5,k," (no legibles)");
 kscreen("PixelKernel: error irrecuperable",l1,l2,l3,l4,l5,0);}
#ifndef TEST32
static void present(void){
 u32*src=BB;u8*dst=(u8*)fbi.addr;int pitch=fbi.pitch;
 if(briN>=10){for(int y=0;y<H;y++){u32*s=src+y*W,*d=(u32*)(dst+y*pitch);int n=W;__asm__ volatile("cld;rep movsl":"+S"(s),"+D"(d),"+c"(n)::"memory");}}
 else{int m=(10+briN)*256/20;for(int y=0;y<H;y++){u32*s=src+y*W,*d=(u32*)(dst+y*pitch);for(int x=0;x<W;x++){u32 c=s[x];d[x]=((((c&0xFF00FF)*m)>>8)&0xFF00FF)|((((c&0xFF00)*m)>>8)&0xFF00);}}}}

static int mem_alias(void){volatile u32*lo=(u32*)0x500,*hi=(u32*)0x400500;u32 s=*lo;*lo=0x11223344;*hi=0xA5A5A5A5;int al=(*lo==0xA5A5A5A5);*lo=s;return al;}
static int mem_ok(u32 a){volatile u32*p=(u32*)a;u32 s=*p;*p=0x5A5AA5A5;int ok=*p==0x5A5AA5A5;*p=0xA5A55A5A;ok=ok&&*p==0xA5A55A5A;*p=s;return ok;}
static void kbc_wait(void){for(int i=0;i<100000&&(inb(0x64)&2);i++);}
extern volatile u32 px_endmark[];
void kmain(void){
 plat_init();SC=H/768.0f;clipall();
 kstage="comprobando la imagen del núcleo";if(px_endmark[0]!=0x444E4550)kfatal("El BIOS no cargó el núcleo completo (la imagen está truncada).","Prueba con otro gestor de máquinas virtuales o con QEMU.");
 kstage="comprobando A20 y memoria";
 if(mem_alias()){outb(0x92,(inb(0x92)|2)&0xFE);if(mem_alias()){kbc_wait();outb(0x64,0xD1);kbc_wait();outb(0x60,0xDF);kbc_wait();}
  if(mem_alias())kfatal("La línea A20 está desactivada: no se puede usar memoria por encima de 1 MB.","Usa una máquina con BIOS estándar (no UEFI).");}
 if(!mem_ok(0xA00000)||!mem_ok(0xE00000))kfatal("No hay suficiente memoria RAM: PixelKernel necesita al menos 16 MB.","Asigna 64 MB o más a la máquina virtual.");
 {u32*p=BB;int n=W*H;__asm__ volatile("cld;rep stosl":"+D"(p),"+c"(n):"a"(0):"memory");}
 kstage="pantalla de inicio";text("PIXEL 1",512,372,92,0xffffff,1,0,1,22);text("Iniciando PixelKernel…",512,436,24,0xffffff,.7f,0,1,0);present();
 os_init();time_init();
 for(;;){float acc=0;do{acc+=time_dt();}while(acc<1.0f/60);{static float avg=.016f;avg=avg*.8f+acc*.2f;qlow=avg>.09f?1:(avg<.045f?0:qlow);}if(acc>.25f)acc=.25f;os_frame(acc);present();}}
#endif
