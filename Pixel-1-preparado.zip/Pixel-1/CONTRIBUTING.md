# Contribuir a Pixel 1

Gracias por tu interés en Pixel 1. El proyecto está en una fase experimental, así que los cambios pequeños, explicados y reproducibles son especialmente útiles.

## Antes de enviar cambios

1. Abre una incidencia para describir el problema o la mejora.
2. Indica el hardware, distribución y versiones de las herramientas si afecta a la compilación.
3. Mantén los cambios relacionados en commits pequeños.
4. No incluyas binarios generados, archivos personales ni rutas absolutas de tu equipo.
5. Añade instrucciones de prueba y resultados observados.

## Código

- Conserva las convenciones de C y ensamblador que ya usa el proyecto.
- Documenta cambios en estructuras compartidas, KAPI o formato PXG1.
- Evita cambiar el formato de juegos sin actualizar `docs/GAME_FORMAT.md`.
- No declares soporte de hardware sin probarlo.

## Recursos externos

Incluye los avisos y licencias de cualquier recurso de terceros que añadas. No subas fuentes, imágenes, sonidos ni código ajeno sin comprobar sus permisos.
