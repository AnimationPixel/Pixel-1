/* PixelKernel 1.0 - interfaz entre el nucleo y los juegos (.px / .pixel) */
#ifndef KAPI_H
#define KAPI_H
typedef unsigned char u8;typedef unsigned short u16;typedef unsigned int u32;typedef signed char s8;
typedef struct{float x,y;int a;}In;
/* cabecera de un archivo de juego: al principio de cada .px / .pixel */
typedef struct{
 char magic[4];                 /* "PXG1" */
 u32 version,load_size,mem_size,entry,nreloc,reloc_off;
 char name[32],genre[24],desc[100],hint[100];
 u32 colx,coly,cola,colb;       /* portada (arriba->abajo) y fondo (brillo, base) */
 u16 hours,trophy,flags,pad;
}PXHead;
/* lo que el juego entrega al nucleo */
typedef struct{void(*init)(void);void(*step)(float,In);void(*draw)(void);void(*cover)(float,float,float,float,float);}PXGame;
/* servicios que el nucleo ofrece al juego */
typedef struct KAPI{
 u32 ver;
 void(*rrect)(float,float,float,float,float,u32,u32,float);
 void(*srect)(float,float,float,float,float,float,u32,float);
 void(*shadow)(float,float,float,float,float,float,u32,float);
 void(*disc)(float,float,float,u32,float);
 void(*ring)(float,float,float,float,u32,float);
 void(*glow)(float,float,float,u32,float);
 void(*seg)(float,float,float,float,float,u32,float);
 void(*poly)(const float*,int,u32,u32,float);
 void(*text)(const char*,float,float,float,u32,float,int,int,float);
 void(*bl)(int,int,u32,int);
 void(*span)(int,int,int,u32,int);
 u32(*lerpc)(u32,u32,float);
 float(*rnd)(void);
 void(*burst)(float,float,u32,int);
 void(*ftext)(const char*,float,float,u32);
 void(*tone)(int,int);
 float*sc,*ox,*oy,*sx;int*cx0,*cy0,*cx1,*cy1;
 int*score,*over,*win;
 u32*bb;int*pw;
}KAPI;
#endif
