# Estado del proyecto

Este documento separa lo que se observa en el código publicado de lo que todavía necesita validación.

## Incluido en esta publicación

- [x] Código de kernel x86 de 32 bits y ensamblador de arranque.
- [x] Definiciones KAPI y estructura `PXHead`.
- [x] Herramienta de empaquetado `mkpx.py`.
- [x] Generador de initrd `mkinitrd.py` y generador de ISO `mkiso2.py`.
- [x] Fuentes de cinco juegos y paquetes de ejemplo.

## Pendiente de validar o completar

- [ ] Incorporar o generar `font.h` en un entorno limpio con fuentes Outfit disponibles.
- [ ] Reproducir la compilación completa desde un clon limpio.
- [ ] Probar el arranque de la ISO en máquina virtual y documentar resultados.
- [ ] Probar el arranque en hardware físico compatible.
- [ ] Documentar mapa de memoria, interrupciones, controladores y límites de la KAPI.
- [ ] Revisar el aislamiento y los permisos de ejecución de los juegos.
- [ ] Definir y probar una ruta de arranque UEFI si forma parte de los objetivos.
- [ ] Diseñar y validar el port a ARM/Raspberry Pi antes de anunciar compatibilidad.

No marques una tarea como terminada hasta que exista una prueba reproducible o documentación técnica que la respalde.
