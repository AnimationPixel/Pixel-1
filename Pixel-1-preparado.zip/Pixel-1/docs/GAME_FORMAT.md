# Formato de juegos `.px` y `.pixel`

Según la implementación incluida, ambas extensiones usan el mismo formato binario. La cabecera empieza con la firma `PXG1`. La estructura de la cabecera `PXHead` está definida en `kapi.h`.

## Ciclo de vida del juego

El juego exporta las funciones de inicialización, actualización, dibujo y portada animada mediante `PX_ENTRY(...)`. La KAPI del kernel proporciona primitivas gráficas y otros servicios definidos en `kapi.h`; `pxlib.h` ofrece nombres auxiliares.

## Crear un paquete

1. Copia `games/ejemplo.c`.
2. Implementa las funciones del juego y la entrada con `PX_ENTRY(...)`.
3. Compila el objeto con la toolchain x86 de 32 bits y las opciones freestanding usadas por el proyecto.
4. Ejecuta `python3 mkpx.py juego.o out/07MIJUEGO.PX`.
5. Regenera el initrd y la ISO si quieres incluir el juego en la imagen.

Ejemplo orientativo de compilación (ajusta el nombre del archivo):

```bash
gcc -m32 -march=i686 -O2 -ffreestanding -fno-pic -fno-pie \
  -fno-stack-protector -fno-asynchronous-unwind-tables \
  -fno-builtin -mno-sse -mno-mmx -mfpmath=387 -I. \
  -c juego.c -o juego.o
python3 mkpx.py juego.o out/07MIJUEGO.PX
```

El empaquetador incluido admite las relocaciones `R_386_32` y omite `R_386_PC32`; otras clases provocan un error. Respeta el formato de nombres 8.3 indicado por `FORMATO_PX.txt` si vas a usar el flujo de empaquetado actual.

Para detalles de campos, consulta también `FORMATO_PX.txt` y los comentarios de `kapi.h`. Esta documentación describe el código presente y puede cambiar junto con el formato.
