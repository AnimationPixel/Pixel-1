# Arquitectura actual

## Resumen

Pixel 1 es un sistema experimental con kernel propio. El código fuente incluido utiliza C y ensamblador x86, compilación freestanding y enlazado de 32 bits (`elf_i386`).

## Arranque

`boot32.S` contiene el punto de entrada de arranque. `link32.ld` define el enlazado del kernel. El flujo documentado genera `pxkernel.bin` y lo convierte en una ISO mediante `mkiso2.py`.

## Kernel y API

El kernel se construye concatenando `part1.c`, `kcore.c` y `part3.c` en `kernel.c`, tal como indica `build.sh`. `kapi.h` define estructuras y servicios expuestos a los juegos; `pxlib.h` contiene utilidades de conveniencia.

## Juegos

Los paquetes `.px` y `.pixel` llevan la firma `PXG1`. `mkpx.py` enlaza un objeto de 32 bits, extrae las relocaciones admitidas y añade la información de empaquetado. `mkinitrd.py` agrupa los paquetes presentes en `out/` en un contenedor `PXFS`.

## Límites conocidos de esta publicación

- El código proporcionado es x86 de 32 bits; no demuestra soporte ARM/Raspberry Pi.
- El flujo de arranque documentado es BIOS; no se debe anunciar como UEFI nativo sin implementar y probar esa ruta.
- El archivo original no incluía `font.h` ni las fuentes Outfit, por lo que la generación del atlas es un paso previo obligatorio.
- La presencia de un script de prueba no sustituye una validación de arranque en hardware o en una máquina virtual.
