# Compilar Pixel 1

## Plataforma

El código incluido está preparado para x86 de 32 bits. El arranque usa `boot32.S` y el enlazado `elf_i386`; no es una compilación ARM.

## Dependencias

- GCC con soporte para generar código de 32 bits (`-m32`).
- Binutils: `ld`, `objcopy`, `nm` y `readelf`.
- Python 3.
- Pillow, NumPy y SciPy para generar el atlas SDF.
- Dos archivos de fuente Outfit: `Outfit-Regular.ttf` y `Outfit-Bold.ttf`.

En Fedora, los nombres exactos de los paquetes pueden variar según la versión. Instala GCC, binutils, Python y los paquetes Python equivalentes a Pillow, NumPy y SciPy. Para compilar ejecutables de 32 bits, también puede hacer falta el soporte multilib de GCC.

## Preparar las fuentes

Coloca los archivos `Outfit-Regular.ttf` y `Outfit-Bold.ttf` en `assets/fonts/`. Revisa primero sus términos de licencia y conserva el archivo de licencia/avisos correspondiente. No se incluyen en este repositorio.

Después ejecuta:

```bash
python3 genfont.py
```

Esto genera `font.h`, que necesita el kernel.

## Construir

Desde la raíz del repositorio:

```bash
chmod +x build.sh
./build.sh
```

El script compila los cinco juegos, genera el initrd, compila el kernel y crea `pixel1-os.iso`. Si falla, conserva el registro completo del error, la distribución, la versión de GCC y la arquitectura del equipo.

## Prueba

`BUILD.txt` describe una prueba adicional con `test32.c`. No la confundas con una prueba de arranque en hardware real. La validación de una ISO debe hacerse por separado en una máquina virtual o equipo de pruebas.
