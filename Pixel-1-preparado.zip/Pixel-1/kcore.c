/* ================= NUCLEO: servicios para juegos, archivos y cargador .px ================= */
void*memcpy(void*d,const void*s,u32 n){u8*a=d;const u8*b=s;while(n--)*a++=*b++;return d;}
void*memset(void*d,int c,u32 n){u8*a=d;while(n--)*a++=(u8)c;return d;}
static void zero(void*p,int n){u8*b=p;while(n--)*b++=0;}
static int kstrlen(const char*s){int n=0;while(s[n])n++;return n;}
static int kstrcmp(const char*a,const char*b){while(*a&&*a==*b){a++;b++;}return (u8)*a-(u8)*b;}
#include "symtab.h"
static const char*kstage="inicio",*kdetail;
static const char*ksym(u32 a,u32*off){int b=-1;for(int i=0;i<NSYM;i++)if(SYM[i].a<=a&&(b<0||SYM[i].a>SYM[b].a))b=i;if(b<0)return 0;*off=a-SYM[b].a;return SYM[b].n;}
static int over,win,score;static float shake,flash;
typedef struct{float x,y,vx,vy,l;u32 c;}PT;static PT pt[160];static int pti;
static void burst(float x,float y,u32 c,int n){while(n--){PT*p=&pt[pti++%160];float a=rnd()*6.283f,v=60+rnd()*260;p->x=x;p->y=y;p->vx=fcos(a)*v;p->vy=fsin(a)*v;p->l=.4f+rnd()*.5f;p->c=c;}}
typedef struct{char s[28];float x,y,l;u32 c;}FT;static FT ft[8];
static void ftext(const char*s,float x,float y,u32 c){for(int i=0;i<8;i++)if(ft[i].l<=0){int k=0;while(s[k]&&k<26){ft[i].s[k]=s[k];k++;}ft[i].s[k]=0;ft[i].x=x;ft[i].y=y;ft[i].l=1;ft[i].c=c;return;}}
static void tone(int hz,int ms);
static float k_tx(float x){return TX(x);}
static KAPI kapi;
static void kapi_init(void){
 kapi.ver=1;kapi.rrect=rrect;kapi.srect=srect;kapi.shadow=shadow;kapi.disc=disc;kapi.ring=ring;kapi.glow=glow;kapi.seg=seg;kapi.poly=poly;kapi.text=text;kapi.bl=bl;kapi.span=span;kapi.lerpc=lerpc;
 kapi.rnd=rnd;kapi.burst=burst;kapi.ftext=ftext;kapi.tone=tone;kapi.sc=&SC;kapi.ox=&OX;kapi.oy=&OY;kapi.sx=&SX;kapi.cx0=&CX0;kapi.cy0=&CY0;kapi.cx1=&CX1;kapi.cy1=&CY1;kapi.score=&score;kapi.over=&over;kapi.win=&win;kapi.bb=BB;kapi.pw=&W;}
/* ---- registro del arranque ---- */
static char klg[12][72];static int nklg;
static void klog(const char*a,const char*b){if(nklg>=12)return;int i=0;while(a&&*a&&i<68)klg[nklg][i++]=*a++;while(b&&*b&&i<70)klg[nklg][i++]=*b++;klg[nklg][i]=0;nklg++;}
static void klogn(const char*a,int v,const char*b){char t[16];int n=0,d[10],k=0;do{d[k++]=v%10;v/=10;}while(v);while(k)t[n++]='0'+d[--k];t[n]=0;char buf[72];int i=0;while(a&&*a&&i<50)buf[i++]=*a++;for(int j=0;t[j];j++)buf[i++]=t[j];while(b&&*b&&i<70)buf[i++]=*b++;buf[i]=0;klog(buf,0);}
/* ---- sistema de archivos: ISO9660 en memoria + initrd PXFS ---- */
typedef struct{char name[40];const u8*data;u32 size;int src;}KF;static KF kf[48];static int nkf;
static u32 le32(const u8*p){return p[0]|(p[1]<<8)|(p[2]<<16)|((u32)p[3]<<24);}
static int up(int c){return c>='a'&&c<='z'?c-32:c;}
static int ieq(const char*a,const char*b,int n){while(n--){if(up((u8)*a++)!=up((u8)*b++))return 0;}return 1;}
static int has_ext(const char*n,int l,const char*e){int el=0;while(e[el])el++;return l>el&&n[l-el-1]=='.'&&ieq(n+l-el,e,el);}
static int is_game_name(const char*n,int l){return has_ext(n,l,"PX")||has_ext(n,l,"PIXEL");}
static void kf_add(const char*nm,int nl,const u8*d,u32 sz,int src){
 if(nkf>=48||nl<=0||nl>38)return;for(int i=0;i<nkf;i++)if(kstrlen(kf[i].name)==nl&&ieq(kf[i].name,nm,nl))return;
 for(int i=0;i<nl;i++)kf[nkf].name[i]=up((u8)nm[i]);kf[nkf].name[nl]=0;kf[nkf].data=d;kf[nkf].size=sz;kf[nkf].src=src;nkf++;}
static int iso_scan(void){
 if(!iso_ok||iso_sectors<20)return 0;const u8*b=MEM_ISO,*pvd=b+16*2048;u32 lim=iso_sectors*2048;
 if(!(pvd[0]==1&&pvd[1]=='C'&&pvd[2]=='D'&&pvd[3]=='0'&&pvd[4]=='0'&&pvd[5]=='1'))return 0;
 u32 rl=le32(pvd+156+2),rs=le32(pvd+156+10),gl=0,gs=0;int cnt=0;
 if((u64)rl*2048+rs>lim)return 0;
 for(u32 off=0;off<rs;){const u8*r=b+rl*2048+off;if(!r[0]){off=(off/2048+1)*2048;continue;}if(r[32]==5&&(r[25]&2)&&ieq((const char*)r+33,"GAMES",5)){gl=le32(r+2);gs=le32(r+10);}off+=r[0];}
 if(!gl||(u64)gl*2048+gs>lim)return 0;
 for(u32 off=0;off<gs;){const u8*r=b+gl*2048+off;if(!r[0]){off=(off/2048+1)*2048;continue;}int nl=r[32];const char*nm=(const char*)r+33;
  if(!(r[25]&2)&&nl>2){int l=nl;for(int i=0;i<nl;i++)if(nm[i]==';'){l=i;break;}
   u32 fl=le32(r+2),fs=le32(r+10);if(is_game_name(nm,l)&&(u64)fl*2048+fs<=lim){kf_add(nm,l,b+fl*2048,fs,1);cnt++;}}
  off+=r[0];}
 return cnt;}
extern const u8 _binary_initrd_bin_start[],_binary_initrd_bin_end[];
static int initrd_scan(void){const u8*b=_binary_initrd_bin_start;u32 n=(u32)(_binary_initrd_bin_end-_binary_initrd_bin_start),cnt=0;
 if(n<8||b[0]!='P'||b[1]!='X'||b[2]!='F'||b[3]!='S')return 0;u32 c=le32(b+4);
 for(u32 i=0;i<c&&8+(i+1)*40<=n;i++){const u8*e=b+8+i*40;int l=0;while(l<32&&e[l])l++;u32 off=le32(e+32),sz=le32(e+36);if(off+sz<=n&&is_game_name((const char*)e,l)){kf_add((const char*)e,l,b+off,sz,2);cnt++;}}
 return cnt;}
/* ---- cargador de juegos .px / .pixel ---- */
typedef struct{const PXHead*h;PXGame*g;char file[40];}Game;static Game GM[16];static int NG;
static u8*pxmem;
static int px_load(const KF*f){
 const u8*d=f->data;u32 sz=f->size;if(NG>=16||sz<sizeof(PXHead))return -1;const PXHead*h=(const PXHead*)d;
 if(!(h->magic[0]=='P'&&h->magic[1]=='X'&&h->magic[2]=='G'&&h->magic[3]=='1')||h->version!=1)return -2;
 if(h->load_size<sizeof(PXHead)||h->load_size>sz||h->mem_size<h->load_size||h->mem_size>0x80000)return -3;
 if((u64)h->reloc_off+4*(u64)h->nreloc>sz||h->nreloc>20000)return -4;
 u8*base=(u8*)(((u32)pxmem+15)&~15u);u8*dst=base;
 for(u32 i=0;i<h->load_size;i++)dst[i]=d[i];for(u32 i=h->load_size;i<h->mem_size;i++)dst[i]=0;
 for(u32 i=0;i<h->nreloc;i++){u32 o=le32(d+h->reloc_off+4*i);if(o+4>h->load_size)return -5;*(u32*)(dst+o)+=(u32)base;}
 pxmem=base+h->mem_size;
 PXHead*lh=(PXHead*)base;PXGame*(*e)(KAPI*)=(PXGame*(*)(KAPI*))lh->entry;if(lh->entry<(u32)base||lh->entry>=(u32)base+h->load_size)return -6;
 GM[NG].h=lh;GM[NG].g=e(&kapi);{int i=0;while(f->name[i]&&i<39){GM[NG].file[i]=f->name[i];i++;}GM[NG].file[i]=0;}NG++;return 0;}
static void sys_boot(void){
 kapi_init();klog("PixelKernel 1.0  ·  arranque en modo protegido de 32 bits",0);
 {char b[48]="Pantalla VBE ";int n=13,v=W,d[6],k=0;do{d[k++]=v%10;v/=10;}while(v);while(k)b[n++]='0'+d[--k];b[n++]='x';v=H;do{d[k++]=v%10;v/=10;}while(v);while(k)b[n++]='0'+d[--k];const char*q=" · 32 bits";while(*q)b[n++]=*q++;b[n]=0;klog(b,0);}
 klog("Teclado PS/2, temporizador PIT y altavoz del PC",0);
 kstage="leyendo el CD (ISO9660)";int ni=iso_scan();kstage="leyendo el disco de arranque";int nr=initrd_scan();
 if(ni)klogn("Sistema de archivos ISO9660 (CD): ",ni," juegos en /GAMES");else klog("ISO9660: no se pudo leer el CD, se usa el disco de arranque",0);
 klogn("Disco de arranque (PXFS): ",nr," juegos incluidos");
 /* ordenar por nombre */
 for(int i=1;i<nkf;i++){KF t=kf[i];int j=i-1;while(j>=0&&kstrcmp(kf[j].name,t.name)>0){kf[j+1]=kf[j];j--;}kf[j+1]=t;}
 kstage="cargando juegos .px / .pixel";pxmem=MEM_GAMES;int bad=0;for(int i=0;i<nkf;i++){kdetail=kf[i].name;if(px_load(&kf[i])<0)bad++;}kdetail=0;
 klogn("Juegos cargados (.px / .pixel): ",NG,bad?" · con errores":"");klog("Sistema listo",0);}
