/* biblioteca para escribir juegos .px de PixelKernel */
#include "kapi.h"
static KAPI*K;
PXGame*px_entry(KAPI*k);
#define rrect K->rrect
#define srect K->srect
#define shadow K->shadow
#define disc K->disc
#define ring K->ring
#define glow K->glow
#define seg K->seg
#define poly K->poly
#define text K->text
#define bl K->bl
#define span K->span
#define lerpc K->lerpc
#define rnd K->rnd
#define burst K->burst
#define ftext K->ftext
#define tone K->tone
#define SC (*K->sc)
#define OX (*K->ox)
#define OY (*K->oy)
#define SX (*K->sx)
#define CX0 (*K->cx0)
#define CY0 (*K->cy0)
#define CX1 (*K->cx1)
#define CY1 (*K->cy1)
#define score (*K->score)
#define over (*K->over)
#define win (*K->win)
#define TX(x) (((x)*SX+OX)*SC)
#define TY(y) (((y)*SX+OY)*SC)
#define TL(l) ((l)*SX*SC)
#define LIM(a,b,c) clamp(a,b,c)
static inline void pbl(int x,int y,u32 c,int a){u32*p=K->bb+y*(*K->pw)+x,d=*p;*p=((((d&0xFF00FF)*(256-a)+(c&0xFF00FF)*a)>>8)&0xFF00FF)|((((d&0xFF00)*(256-a)+(c&0xFF00)*a)>>8)&0xFF00);}
static float fabs_(float x){return x<0?-x:x;}
static float sqrt_(float x){return x>0?__builtin_sqrtf(x):0;}
static float fmin_(float a,float b){return a<b?a:b;}
static float fmax_(float a,float b){return a>b?a:b;}
static float clamp(float x,float a,float b){return x<a?a:x>b?b:x;}
static int ifl(float f){int i=(int)f;return i-(f<(float)i);}
static int ice(float f){int i=(int)f;return i+(f>(float)i);}
static float fmod_(float x,float m){return x-m*(float)ifl(x/m);}
static float fsin(float x){x-=6.2831853f*(float)ifl(x*0.15915494f+0.5f);float x2=x*x;return x*(1.0f+x2*(-0.16666667f+x2*(0.008333333f+x2*(-0.000198413f+x2*(2.7557e-6f+x2*-2.505e-8f)))));}
static float fcos(float x){return fsin(x+1.5707963f);}
static float fatan2(float y,float x){float ax=fabs_(x),ay=fabs_(y);if(ax==0&&ay==0)return 0;float a=ax>ay?ay/ax:ax/ay,s=a*a,r=((-0.0464964749f*s+0.15931422f)*s-0.327622764f)*s*a+a;if(ay>ax)r=1.57079637f-r;if(x<0)r=3.14159274f-r;return y<0?-r:r;}
static int rndi(int n){return (int)(rnd()*n)%n;}
static void zero(void*p,int n){u8*b=p;while(n--)*b++=0;}
static void rect(float x,float y,float w,float h,u32 c,float al){rrect(x,y,w,h,0,c,c,al);}
static void tri(float x,float y,float hw,float h,u32 c,float al){float p[6]={x,y,x+hw,y+h,x-hw,y+h};poly(p,3,c,c,al);}
static void heart(float cx,float cy,float s,u32 c,float al){disc(cx-s*.3f,cy-s*.2f,s*.34f,c,al);disc(cx+s*.3f,cy-s*.2f,s*.34f,c,al);float p[6]={cx-s*.62f,cy-s*.05f,cx+s*.62f,cy-s*.05f,cx,cy+s*.62f};poly(p,3,c,c,al);}
/* cada juego define: init/step/draw/cover, PXHead px_head y px_entry */
#define PX_ENTRY(init_,step_,draw_,cover_) \
 static PXGame G_={init_,step_,draw_,cover_}; \
 PXGame*px_entry(KAPI*k){K=k;return &G_;}
#define PX_HEAD __attribute__((section(".px_header"),used)) const PXHead px_head=
