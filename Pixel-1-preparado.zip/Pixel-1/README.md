# Pixel 1

<p align="center">
  <img src="assets/branding/animation-pixel-logo.png" alt="Animation Pixel" width="180">
</p>

<p align="center"><strong>Un sistema propio. Un kernel propio. Un formato de juegos propio.</strong></p>

**Pixel 1** es un proyecto experimental de sistema operativo de **Animation Pixel**, con un kernel propio para x86 de 32 bits y un formato de juegos propio (`.px` / `.pixel`).

> **Estado:** desarrollo experimental. El código y los formatos pueden cambiar. Esta publicación contiene el código fuente incluido en el paquete original; no representa por sí sola una versión estable ni una ISO reproducible.

## Características presentes en este código

- Kernel freestanding para x86 de 32 bits.
- Código de arranque BIOS y modo protegido.
- Interfaz de servicios para juegos mediante KAPI (`kapi.h`).
- Formato de ejecutable de juegos con firma `PXG1`.
- Herramientas para empaquetar juegos y generar el sistema de archivos inicial.
- Cinco juegos de ejemplo incluidos en `games/` y sus paquetes en `out/`.

## Arquitectura y compatibilidad

Esta versión del código está orientada a **PC x86 de 32 bits**. El árbol incluye `boot32.S`, enlazado `elf_i386` y herramientas que generan imágenes para ese entorno. La adaptación a ARM/Raspberry Pi no está demostrada por este código y debe tratarse como trabajo futuro, no como compatibilidad disponible.

## Estructura

```text
Pixel-1/
├── boot32.S              # Entrada de arranque x86
├── part1.c, kcore.c, part3.c
│                         # Partes del kernel
├── kapi.h, pxlib.h        # API para juegos
├── link32.ld, px.ld       # Scripts de enlazado
├── games/                # Fuentes de los juegos
├── out/                  # Paquetes .PX / .PIXEL incluidos
├── herramientas/         # Herramientas auxiliares
├── mkpx.py               # Empaquetador de juegos
├── mkinitrd.py           # Generador del initrd PXFS
├── mkiso2.py             # Generador de ISO
├── genfont.py            # Generador del atlas de fuentes
└── docs/                 # Documentación del proyecto
```

## Compilación

Consulta [`docs/BUILD.md`](docs/BUILD.md) antes de compilar. El script necesita una toolchain de 32 bits y las fuentes Outfit para generar `font.h`. Esas fuentes no se incluyen en este repositorio; revisa `assets/fonts/README.md`.

```bash
./build.sh
```

El resultado esperado del script es `pixel1-os.iso`. La compilación puede depender de versiones concretas de GCC, binutils, Python y bibliotecas. No se afirma que el proceso haya sido reproducido en todas las distribuciones.

## Crear un juego

Empieza por [`games/ejemplo.c`](games/ejemplo.c) y sigue [`docs/GAME_FORMAT.md`](docs/GAME_FORMAT.md).

## Estado del desarrollo

Consulta [`docs/STATUS.md`](docs/STATUS.md). Las funciones marcadas como pendientes no deben considerarse terminadas.

## Contribuir

Lee [`CONTRIBUTING.md`](CONTRIBUTING.md) antes de enviar cambios. Para errores de seguridad, consulta [`SECURITY.md`](SECURITY.md).

## Licencia

El proyecto se publica bajo **GNU General Public License v3.0**. Consulta [`LICENSE`](LICENSE). Los recursos de terceros, como tipografías, conservan sus propias licencias y avisos.

---

Desarrollado por **Animation Pixel**.
