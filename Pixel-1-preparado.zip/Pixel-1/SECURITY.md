# Seguridad

Pixel 1 es software experimental y no debe utilizarse para almacenar datos sensibles ni como sistema de uso diario.

Si encuentras un problema de seguridad, evita publicar detalles que faciliten su explotación. Informa al mantenedor mediante un canal privado disponible en el perfil del proyecto. No incluyas datos personales en los informes.

Hasta que exista un proceso de respuesta y versiones de seguridad, no se garantiza un plazo de corrección.
