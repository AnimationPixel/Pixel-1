#!/bin/sh
set -e
F="-m32 -march=i586 -O2 -ffreestanding -fno-pic -fno-pie -fno-stack-protector -fno-asynchronous-unwind-tables -fno-builtin -fno-tree-loop-distribute-patterns -mno-sse -mno-mmx -mfpmath=387 -fno-math-errno -Wno-multichar -Wno-misleading-indentation -Wno-unused-variable -I."
mkdir -p out
if [ ! -f font.h ]; then
  python3 genfont.py
fi
for g in 01neon:01NEON.PX 02aurora:02AURORA.PX 03kodama:03KODAMA.PIXEL 04orbita:04ORBITA.PX 05royale:05ROYALE.PIXEL; do s=${g%%:*}; f=${g##*:}; gcc $F -c games/$s.c -o games/$s.o; python3 mkpx.py games/$s.o out/$f >/dev/null; done
python3 mkinitrd.py >/dev/null; objcopy -I binary -O elf32-i386 -B i386 initrd.bin initrd.o
echo 'static const struct{u32 a;const char*n;}SYM[]={{0,"?"}};static const int NSYM=1;' > symtab.h
cat part1.c kcore.c part3.c > kernel.c
gcc -m32 -c boot32.S -o boot32.o
link(){ gcc $F -c kernel.c -o kernel.o; ld -m elf_i386 -z noexecstack -T link32.ld -o pxkernel.elf boot32.o kernel.o initrd.o 2>/dev/null; }
link; nm -n pxkernel.elf | grep -E ' [tT] ' > /tmp/a1.txt
python3 mksym.py; cat part1.c kcore.c part3.c > kernel.c; link; 
python3 mksym.py; cat part1.c kcore.c part3.c > kernel.c; link
objcopy -O binary pxkernel.elf pxkernel.bin
python3 mkiso2.py pxkernel.bin pixel1-os.iso
