#!/usr/bin/env python3
"""Genera font.h a partir de las fuentes Outfit locales."""
from pathlib import Path
import sys
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy.ndimage import distance_transform_edt as edt

ROOT = Path(__file__).resolve().parent
FONT_DIR = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else ROOT / "assets" / "fonts"
FONTS = [FONT_DIR / "Outfit-Regular.ttf", FONT_DIR / "Outfit-Bold.ttf"]
missing = [str(p) for p in FONTS if not p.is_file()]
if missing:
    sys.exit("Faltan las fuentes necesarias:\n  " + "\n  ".join(missing) + "\nConsulta assets/fonts/README.md.")
EM=36; SS=4; SP=6
CPS=list(range(32,127))+[0xE1,0xE9,0xED,0xF3,0xFA,0xFC,0xF1,0xC1,0xC9,0xCD,0xD3,0xDA,0xD1,0xBF,0xA1,0xB7,0x20AC,0xD7,0x2190,0x2191,0x2192,0x2193,0x2014,0x2026]
CPS.sort()
out=['/* generado por genfont.py: atlas SDF de Outfit (36 px, rango %d) */'%SP]
out.append('#define NGLY %d\n#define SDF_SPREAD %d\n#define SDF_EM %d'%(len(CPS),SP,EM))
out.append('static const u16 CPT[NGLY]={'+','.join(map(str,CPS))+'};')
tot=0
for wi,path in enumerate(FONTS):
    f=ImageFont.truetype(str(path),EM*SS)
    data=bytearray(); meta=[]
    for cp in CPS:
        ch=chr(cp); adv=f.getlength(ch)/SS
        ox=(SP+6)*SS; oy=int(EM*1.5*SS)
        cw=int((adv+EM)*SS)+2*ox; chh=int(EM*2.6*SS)
        im=Image.new('L',(cw,chh),0); ImageDraw.Draw(im).text((ox,oy),ch,font=f,fill=255,anchor='ls')
        m=np.array(im)>127
        if not m.any(): meta.append((len(data),0,0,0,0,int(adv*16))); continue
        ys,xs=np.where(m); x0,x1,y0,y1=xs.min(),xs.max(),ys.min(),ys.max()
        left=int(np.floor(x0/SS))-SP; right=int(np.ceil((x1+1)/SS))+SP; top=int(np.floor(y0/SS))-SP; bot=int(np.ceil((y1+1)/SS))+SP
        pad=(SP+3)*SS; mp=np.pad(m,pad)
        din=edt(mp); dout=edt(~mp); sdf=(din-dout)/SS
        w=right-left; h=bot-top
        ii=(np.arange(h)+top)*SS+SS//2+pad; jj=(np.arange(w)+left)*SS+SS//2+pad
        s=sdf[np.ix_(np.clip(ii,0,sdf.shape[0]-1),np.clip(jj,0,sdf.shape[1]-1))]
        v=np.clip(128+s*(127.0/SP),0,255).astype(np.uint8)
        meta.append((len(data),w,h,left-ox//SS,oy//SS-top,int(round(adv*16)))); data+=v.tobytes()
    tot+=len(data)
    out.append('static const u8 SDF%d[%d]={'%(wi,len(data))+','.join(map(str,data))+'};')
    out.append('static const GLY GL%d[NGLY]={'%wi+','.join('{%d,%d,%d,%d,%d,%d}'%t for t in meta)+'};')
(ROOT/'font.h').write_text('\n'.join(out)+'\n',encoding='utf-8')
print('glifos',len(CPS),'bytes SDF total',tot)
