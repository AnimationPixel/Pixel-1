#define TEST32
#include "kernel.c"
static int sc3(int n,int a,int b,int c){int r;__asm__ volatile("int $0x80":"=a"(r):"a"(n),"b"(a),"c"(b),"d"(c):"memory");return r;}
static void ws(const char*s){int n=0;while(s[n])n++;sc3(4,1,(int)s,n);}
static void wn(int v){char b[16];int n=0,d[12],k=0;if(v<0){b[n++]='-';v=-v;}do{d[k++]=v%10;v/=10;}while(v);while(k)b[n++]='0'+d[--k];b[n++]=' ';b[n]=0;ws(b);}
static void dump(const char*name){int fd=sc3(5,(int)name,0x241,0644);static u8 hdr[32];int n=0;hdr[n++]='P';hdr[n++]='6';hdr[n++]='\n';hdr[n++]='1';hdr[n++]='0';hdr[n++]='2';hdr[n++]='4';hdr[n++]=' ';hdr[n++]='7';hdr[n++]='6';hdr[n++]='8';hdr[n++]='\n';hdr[n++]='2';hdr[n++]='5';hdr[n++]='5';hdr[n++]='\n';sc3(4,fd,(int)hdr,n);
 static u8 row[1024*3];for(int y=0;y<768;y++){for(int x=0;x<1024;x++){u32 c=BB[y*1024+x];row[x*3]=c>>16;row[x*3+1]=c>>8;row[x*3+2]=c;}sc3(4,fd,(int)row,sizeof row);}sc3(6,fd,0,0);}
static void run(int n){for(int i=0;i<n;i++)os_frame(1.0f/60);}
static void tap(int sc){keys[sc]=1;run(2);keys[sc]=0;run(2);}
#define ENT 0x1C
#define LEFT 0x4B
#define RIGHT 0x4D
#define UP 0x48
#define DOWN 0x50
static int slurp(const char*p,u8*dst,int max){int fd=sc3(5,(int)p,0,0);if(fd<0)return -1;int t=0,n;while((n=sc3(3,fd,(int)(dst+t),max-t))>0)t+=n;sc3(6,fd,0,0);return t;}
void _start(void){
 int useiso=0;const char*isop=0;
 /* argv: usar variable de entorno simple: ISO por defecto test.iso si existe y se pasa 'iso' */
 int* sp;__asm__ volatile("lea 4(%%ebp),%0":"=r"(sp));(void)sp;
 isop="PIXEL.ISO";int n=slurp(isop,ISOMEM,sizeof ISOMEM);if(n>0){iso_ok=1;iso_sectors=n/2048;useiso=1;}
 sc3(125,(int)GAMEMEM,sizeof GAMEMEM,7);plat_init();os_init();
 ws("modo: ");ws(useiso?"CD (ISO9660) + initrd\n":"solo initrd\n");
 for(int i=0;i<nklg;i++){ws("  ");ws(klg[i]);ws("\n");}
 ws("juegos cargados: ");wn(NG);ws("\n");for(int i=0;i<NG;i++){ws("  ");ws(GM[i].file);ws(" -> ");ws(GM[i].h->name);ws(" (");ws(GM[i].h->genre);ws(")\n");}
 if(NG!=5){ws("FALLO: se esperaban 5 juegos\n");sc3(1,1,0,0);}
 run(40);dump("b_boot1.ppm");run(130);dump("b_boot2.ppm");run(120);
 if(state!=S_HOME){ws("FALLO: no paso a HOME\n");sc3(1,2,0,0);}
 run(60);ws("bg_render hasta ahora: ");wn(bgcnt);{int b0=bgcnt;run(120);ws(" ; en 120 fotogramas estables: ");wn(bgcnt-b0);ws("\n");}dump("b_home0.ppm");tap(RIGHT);tap(RIGHT);run(50);dump("b_home2.ppm");tap(ENT);run(70);dump("b_hub.ppm");tap(ENT);run(100);
 if(state!=S_LAUNCH&&state!=S_GAME){ws("FALLO: no lanzo\n");sc3(1,3,0,0);}
 run(100);run(60);dump("b_cd.ppm");
 for(int g=0;g<5;g++){
  if(state!=S_HOME){for(int k=0;k<4&&state!=S_HOME;k++){tap(0x01);run(10);}} 
  while(hubon){tap(0x01);run(10);}while(tab!=0)tap(0x10);if(zn==0)tap(DOWN);
  for(int k=0;k<6;k++)tap(LEFT);for(int k=0;k<g;k++)tap(RIGHT);
  tap(ENT);run(40);tap(ENT);run(160);
  if(state!=S_GAME||gid!=g){ws("FALLO: juego no arranco ");wn(g);ws("\n");sc3(1,4,0,0);}
  run(250);int overs=0;
  for(int f=0;f<1800;f++){
   if(f%20==0){keys[LEFT]=rnd()<.33f;keys[RIGHT]=rnd()<.33f;keys[UP]=rnd()<.33f;keys[DOWN]=rnd()<.33f;keys[ENT]=rnd()<.8f;}
   os_frame(1.0f/60);
   if(f==150){char nm[16]="b_play0.ppm";nm[6]='0'+g;dump(nm);}
   if(over){overs++;if(overs==1){run(40);char nm[16]="b_over0.ppm";nm[6]='0'+g;dump(nm);}keys[ENT]=0;run(3);keys[ENT]=1;run(3);keys[ENT]=0;if(overs>2)break;}
  }
  for(int i=0;i<128;i++)keys[i]=0;
  ws("juego ");wn(g);ws(GM[g].h->name);ws(": ok, partidas ");wn(overs);ws(" record ");wn(hi[g]);ws("\n");
 }
 {u32 fr[5]={13,0x1c,(u32)GM[2].h+0x120,8,0x10046};kexc(fr);dump("b_panic.ppm");kfatal("La línea A20 está desactivada: no se puede usar memoria por encima de 1 MB.","Usa una máquina con BIOS estándar (no UEFI).");dump("b_fatal.ppm");}
 ws("TODO OK\n");sc3(1,0,0,0);}
