# Fuentes Outfit

`genfont.py` necesita estos dos archivos en esta carpeta:

- `Outfit-Regular.ttf`
- `Outfit-Bold.ttf`

No se incluyen en este repositorio. Descárgalos únicamente de una fuente oficial y conserva junto a ellos el archivo de licencia OFL y los avisos requeridos por su distribución. Comprueba las condiciones vigentes antes de redistribuirlos.
