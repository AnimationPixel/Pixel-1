/* Aurora Siege - juego para PixelKernel (.px) */
#include "pxlib.h"
static struct{float sx,vx,cd,iv,pw,tm;int hp,kills,wave;struct{float x,y,vx;int a;}bu[24];struct{float x,y;int a;}eb[16];struct{float x,y,p,f,hp;int t,a;}en[20];struct{float x,y;int a;}dr[6];struct{float x,y,s;}st[50];}A1;
static void as_hurt(void){if(A1.iv>0)return;A1.hp--;A1.iv=1.5f;burst(A1.sx,455,0x19d3c5,24);tone(160,250);if(A1.hp<=0)over=1;}
static void as_init(void){zero(&A1,sizeof A1);A1.sx=400;A1.hp=3;A1.wave=1;for(int k=0;k<50;k++){A1.st[k].x=rnd()*800;A1.st[k].y=rnd()*500;A1.st[k].s=.3f+rnd()*1.2f;}}
static void as_bul(float x,float y,float vx){for(int k=0;k<24;k++)if(!A1.bu[k].a){A1.bu[k].a=1;A1.bu[k].x=x;A1.bu[k].y=y;A1.bu[k].vx=vx;return;}}
static void as_step(float dt,In i){
 A1.tm+=dt;A1.cd-=dt;A1.iv-=dt;A1.pw-=dt;A1.wave=1+A1.kills/12;A1.vx+=(i.x*560-A1.vx)*fmin_(1,8*dt);A1.sx=LIM(A1.sx+A1.vx*dt,30,770);
 if(i.a&&A1.cd<=0){A1.cd=A1.pw>0?.14f:.24f;as_bul(A1.sx,430,0);if(A1.pw>0){as_bul(A1.sx-10,436,-120);as_bul(A1.sx+10,436,120);}tone(700,40);}
 if(rnd()<dt*(.9f+A1.wave*.35f))for(int k=0;k<20;k++)if(!A1.en[k].a){int t=rnd()<fmin_(.4f,.1f+A1.wave*.05f);A1.en[k].a=1;A1.en[k].t=t;A1.en[k].hp=t?3:1;A1.en[k].x=40+rnd()*720;A1.en[k].y=-20;A1.en[k].p=rnd()*6;A1.en[k].f=1+rnd()*2;break;}
 for(int k=0;k<24;k++)if(A1.bu[k].a){A1.bu[k].y-=640*dt;A1.bu[k].x+=A1.bu[k].vx*dt;if(A1.bu[k].y<-10)A1.bu[k].a=0;}
 for(int k=0;k<20;k++)if(A1.en[k].a){int t=A1.en[k].t;A1.en[k].y+=(t?45:70+A1.wave*4)*dt;A1.en[k].p+=dt*(t?1.2f:3);A1.en[k].x=LIM(A1.en[k].x+fsin(A1.en[k].p)*(t?30:70)*dt,20,780);
  if(t){A1.en[k].f-=dt;if(A1.en[k].f<=0&&A1.en[k].y>0){A1.en[k].f=1.6f;for(int q=0;q<16;q++)if(!A1.eb[q].a){A1.eb[q].a=1;A1.eb[q].x=A1.en[k].x;A1.eb[q].y=A1.en[k].y+14;break;}}}}
 for(int k=0;k<16;k++)if(A1.eb[k].a){A1.eb[k].y+=260*dt;if(fabs_(A1.eb[k].x-A1.sx)<18&&A1.eb[k].y>432&&A1.eb[k].y<478){as_hurt();A1.eb[k].a=0;}else if(A1.eb[k].y>520)A1.eb[k].a=0;}
 for(int e=0;e<20;e++)if(A1.en[e].a)for(int b=0;b<24;b++)if(A1.bu[b].a&&fabs_(A1.en[e].x-A1.bu[b].x)<(A1.en[e].t?24:18)&&fabs_(A1.en[e].y-A1.bu[b].y)<20){A1.bu[b].a=0;
  if(--A1.en[e].hp<=0){A1.en[e].a=0;A1.kills++;int pts=A1.en[e].t?30:10;score+=pts;burst(A1.en[e].x,A1.en[e].y,A1.en[e].t?0xffb347:0xff5c8a,A1.en[e].t?24:12);ftext(A1.en[e].t?"+30":"+10",A1.en[e].x,A1.en[e].y,0xffffff);tone(300,80);
   if(rnd()<.18f)for(int d=0;d<6;d++)if(!A1.dr[d].a){A1.dr[d].a=1;A1.dr[d].x=A1.en[e].x;A1.dr[d].y=A1.en[e].y;break;}}else burst(A1.bu[b].x,A1.en[e].y,0xffffff,4);break;}
 for(int e=0;e<20;e++)if(A1.en[e].a){if(fabs_(A1.en[e].x-A1.sx)<24&&fabs_(A1.en[e].y-455)<26){A1.en[e].a=0;as_hurt();}else if(A1.en[e].y>490){A1.en[e].a=0;as_hurt();}}
 for(int d=0;d<6;d++)if(A1.dr[d].a){A1.dr[d].y+=110*dt;if(fabs_(A1.dr[d].x-A1.sx)<28&&fabs_(A1.dr[d].y-455)<30){A1.dr[d].a=0;A1.pw=8;ftext("¡Triple disparo!",A1.sx,420,0xffe36b);tone(900,150);}else if(A1.dr[d].y>520)A1.dr[d].a=0;}
}
static void as_draw(void){
 for(int k=0;k<50;k++){A1.st[k].y=fmod_(A1.st[k].y+A1.st[k].s*.3f,500);disc(A1.st[k].x,A1.st[k].y,A1.st[k].s*.9f,0xffffff,.6f);}
 for(int k=0;k<4;k++){u32 ac=k&1?0x7dffc0:0x19d3c5;float hh=TL(70);int invU=(int)(255.0f*65536/(hh*256)),invD=(int)(255.0f*65536/(hh*.3f*256));
  static u8 RL[256];static int rl_ok;if(!rl_ok){for(int i=0;i<256;i++){float d=i/255.0f,t=(1-d);RL[i]=(u8)(t*t*.30f*255);}rl_ok=1;}
  for(int px=CX0;px<CX1;px++){float vx=((px+.5f)/SC-OX)/SX,yc=TY(70+k*38+fsin(vx/90+A1.tm+k)*26);int iyc=(int)(yc*256),y0=ifl(yc-hh),y1=ice(yc+hh*.3f);if(y0<CY0)y0=CY0;if(y1>CY1)y1=CY1;
   for(int py=y0;py<y1;py++){int diff=iyc-(py<<8)-128,idx=diff>=0?(diff*invU)>>16:((-diff)*invD)>>16;if(idx>255)continue;int al=RL[idx];if(al)pbl(px,py,ac,al);}}}
 for(float X=0;X<800;X+=50)rect(X,470-(float)(((int)X*7)%40),40,60,0x0a2a44,1);
 for(int k=0;k<24;k++)if(A1.bu[k].a){glow(A1.bu[k].x,A1.bu[k].y,18,0xffffff,.6f);rrect(A1.bu[k].x-2,A1.bu[k].y-10,4,14,2,0xffffff,0xffffff,1);}
 for(int k=0;k<16;k++)if(A1.eb[k].a){glow(A1.eb[k].x,A1.eb[k].y,14,0xff4d6d,.7f);disc(A1.eb[k].x,A1.eb[k].y,5,0xff8aa0,1);}
 for(int d=0;d<6;d++)if(A1.dr[d].a){glow(A1.dr[d].x,A1.dr[d].y,30,0xffe36b,.7f);disc(A1.dr[d].x,A1.dr[d].y,11,0xffe36b,1);text("3",A1.dr[d].x,A1.dr[d].y+5,16,0x04061a,1,1,1,0);}
 for(int k=0;k<20;k++)if(A1.en[k].a){float x=A1.en[k].x,y=A1.en[k].y,r=A1.en[k].t?22:16;u32 c=A1.en[k].t?0xffb347:0xff5c8a;glow(x,y,r*2.4f,c,.35f);float p[8]={x,y-r,x+r,y,x,y+r,x-r,y};poly(p,4,lerpc(c,0xffffff,.35f),c,1);
  if(A1.en[k].t){rrect(x-14,y+r+4,28,4,2,0x03051a,0x03051a,.6f);rrect(x-14,y+r+4,28*A1.en[k].hp/3,4,2,0xffffff,0xffffff,1);}}
 if(A1.iv<=0||((int)(A1.tm*12))%2){float c=fcos(A1.vx/2400),s=fsin(A1.vx/2400),x=A1.sx,y=455;
  #define SP(px,py) x+(px)*c-(py)*s,y+(px)*s+(py)*c
  glow(x,y,55,0x19d3c5,.35f);float sh[8]={SP(0,-26),SP(18,19),SP(0,10),SP(-18,19)};poly(sh,4,0x9ff5ec,0x19d3c5,1);float fl[6]={SP(-5,12),SP(0,20+rnd()*12),SP(5,12)};poly(fl,3,0xffb347,0xffb347,.9f);}
 for(int k=0;k<A1.hp;k++)heart(776-k*30,28,16,0xff5c8a,1);
 {char b[16]="Oleada ";int w=A1.wave;char d[4];int n=0;if(w>9)d[n++]='0'+w/10;d[n++]='0'+w%10;d[n]=0;int p=7;for(int q=0;q<n;q++)b[p++]=d[q];b[p]=0;text(b,784,58,16,0xffffff,1,0,2,0);}
 if(A1.pw>0)rrect(588,68,196*fmin_(1,A1.pw/8),6,3,0xffe36b,0xffe36b,1);
}
static void cover(float x,float y,float w,float h,float t){(void)t;(void)w;(void)h;(void)x;(void)y;
 {for(int k=0;k<3;k++)for(int i=0;i<10;i++){float x0=x+w*i/10.0f,x1=x+w*(i+1)/10.0f,y0=y+h*(.25f+k*.1f)+fsin(t*1.5f+i)*h*.03f,y1=y+h*(.25f+k*.1f)+fsin(t*1.5f+(i+1))*h*.03f;seg(x0,y0,x1,y1,2.6f,k==1?0x9dffd0:0x7ffff0,.85f-k*.15f);}}
}
PX_HEAD {"PXG1",1,0,0,(u32)px_entry,0,0,"Aurora Siege","Acción","Defiende la última ciudad bajo la aurora boreal.","Flechas: mover  ·  Intro: disparar  ·  P: pausa  ·  Esc: salir",0x19d3c5,0x0b3b6f,0x19d3c5,0x06284f,18,35,0,0};
PX_ENTRY(as_init,as_step,as_draw,cover)
