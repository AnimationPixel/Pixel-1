/* Órbita Cero - juego para PixelKernel (.px) */
#include "pxlib.h"
static struct{float x,y,vx,vy,a,fuel,nf,tm,tt,bx,by;int th,n;struct{float a,d,w,r;}as[10];struct{float x,y,l;}tr[40];}O1;
static void or_ast(int i){O1.as[i].a=rnd()*6.283f;O1.as[i].d=105+rnd()*150;O1.as[i].w=(rnd()<.5f?1:-1)*(.35f+rnd()*.5f);O1.as[i].r=10+rnd()*13;}
static void or_bea(void){float a=rnd()*6.283f,d=90+rnd()*160;O1.bx=400+fcos(a)*d;O1.by=250+fsin(a)*d;}
static void or_init(void){zero(&O1,sizeof O1);O1.x=400;O1.y=90;O1.vx=148;O1.fuel=100;O1.n=5;for(int i=0;i<5;i++)or_ast(i);or_bea();}
static void or_step(float dt,In i){
 O1.tm+=dt;O1.a+=i.x*3.4f*dt;O1.th=(i.a||i.y<-.5f)&&O1.fuel>0;
 if(O1.th){O1.vx+=fcos(O1.a)*260*dt;O1.vy+=fsin(O1.a)*260*dt;O1.fuel=fmax_(0,O1.fuel-13*dt);}
 float dx=400-O1.x,dy=250-O1.y,d=fmax_(30,sqrt_(dx*dx+dy*dy)),g=3.5e6f/(d*d);O1.vx+=dx/d*g*dt;O1.vy+=dy/d*g*dt;O1.vx*=1-.25f*dt;O1.vy*=1-.25f*dt;
 O1.x=fmod_(O1.x+O1.vx*dt,800);O1.y=fmod_(O1.y+O1.vy*dt,500);
 O1.tt-=dt;if(O1.tt<=0){O1.tt=.03f;for(int k=0;k<40;k++)if(O1.tr[k].l<=0){O1.tr[k].x=O1.x;O1.tr[k].y=O1.y;O1.tr[k].l=.8f;break;}}for(int k=0;k<40;k++)O1.tr[k].l-=dt;
 for(int k=0;k<O1.n;k++){O1.as[k].a+=O1.as[k].w*dt;float ax=400+fcos(O1.as[k].a)*O1.as[k].d,ay=250+fsin(O1.as[k].a)*O1.as[k].d;if(O1.tm>1.5f&&(ax-O1.x)*(ax-O1.x)+(ay-O1.y)*(ay-O1.y)<(O1.as[k].r+9)*(O1.as[k].r+9)&&!over){over=1;burst(O1.x,O1.y,0xffffff,30);}}
 if((O1.bx-O1.x)*(O1.bx-O1.x)+(O1.by-O1.y)*(O1.by-O1.y)<30*30){burst(O1.bx,O1.by,0x5cf2ff,18);score+=25;O1.fuel=fmin_(100,O1.fuel+30);ftext("+25 · combustible",O1.bx,O1.by,0x5cf2ff);tone(900,120);or_bea();if(O1.n<10&&score%50==0){or_ast(O1.n);O1.n++;}}
 O1.nf=O1.fuel<=0?O1.nf+dt:0;if((d<42||O1.nf>6)&&!over){over=1;burst(O1.x,O1.y,d<42?0xffb347:0xffffff,30);}
}
static void or_draw(void){
 for(int k=0;k<45;k++)disc((float)((k*53)%800),(float)((k*89)%500),(k%3)?1.2f:2,0xffe7b0,.8f);
 {static const int rr[3]={120,170,220};for(int k=0;k<3;k++)ring(400,250,rr[k],1.2f,0xffffff,.07f);}
 glow(400,250,120,0xffb347,.5f);
 disc(400,250,34,0xa8429e,1);disc(392,242,26,0xd98ab0,1);disc(386,236,16,0xffe7b0,.9f);
 ring(O1.bx,O1.by,14+fsin(O1.tm*4)*3,3,0x5cf2ff,1);glow(O1.bx,O1.by,36,0x5cf2ff,.5f);
 for(int k=0;k<O1.n;k++){float ax=400+fcos(O1.as[k].a)*O1.as[k].d,ay=250+fsin(O1.as[k].a)*O1.as[k].d;disc(ax,ay,O1.as[k].r,0x3a2a14,1);ring(ax,ay,O1.as[k].r,3,0xffb347,1);}
 for(int k=0;k<40;k++)if(O1.tr[k].l>0)disc(O1.tr[k].x,O1.tr[k].y,2,0xffffff,O1.tr[k].l*.6f);
 {float c=fcos(O1.a),s=fsin(O1.a),x=O1.x,y=O1.y;
  #define OP(px,py) x+(px)*c-(py)*s,y+(px)*s+(py)*c
  glow(x,y,40,0xffffff,.25f);float sh[6]={OP(16,0),OP(-12,10),OP(-12,-10)};poly(sh,3,0xffffff,0xd0d8ff,1);
  if(O1.th){float f[6]={OP(-12,-5),OP(-26-rnd()*8,0),OP(-12,5)};poly(f,3,0xffb347,0xffb347,.95f);}}
 rrect(588,472,196,12,6,0x03051a,0x03051a,.55f);rrect(588,472,196*O1.fuel/100,12,6,O1.fuel>25?0x5cf2ff:0xff5c8a,O1.fuel>25?0x5cf2ff:0xff5c8a,1);
 if(O1.fuel<=0)text("¡Sin combustible!",784,462,16,0xff5c8a,1,1,2,0);
}
static void cover(float x,float y,float w,float h,float t){(void)t;(void)w;(void)h;(void)x;(void)y;
 {float cx=x+w/2;ring(cx,y+.4f*h,.33f*w,2,0xffffff,.8f);ring(cx,y+.4f*h,.2f*w,2,0xffb347,.9f);disc(cx,y+.4f*h,.08f*w,0xffe7b0,1);}
}
PX_HEAD {"PXG1",1,0,0,(u32)px_entry,0,0,"Órbita Cero","Ciencia ficción","Una estación en ruinas. Una sola señal de socorro.","← →: girar  ·  Intro o ↑: propulsor  ·  P: pausa  ·  Esc: salir",0xffb347,0x6a1b9a,0xff9a3d,0x3a0f5e,5,12,0,0};
PX_ENTRY(or_init,or_step,or_draw,cover)
