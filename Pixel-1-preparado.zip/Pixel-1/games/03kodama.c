/* Kodama - juego para PixelKernel (.pixel) */
#include "pxlib.h"
static struct{float px,py,tm,pc,pl,lt,sp;struct{float x,y;int a;}o[4];struct{float x,y,w;int a;}sh[8];}K1;
static void ko_orb(int i){K1.o[i].a=1;K1.o[i].x=60+rnd()*680;K1.o[i].y=60+rnd()*380;}
static void ko_init(void){zero(&K1,sizeof K1);K1.px=400;K1.py=250;K1.lt=100;K1.sp=3;for(int i=0;i<4;i++)ko_orb(i);}
static void ko_step(float dt,In i){
 K1.tm+=dt;K1.pc-=dt;K1.pl=fmax_(0,K1.pl-dt);K1.lt=fmax_(0,K1.lt-(5+K1.tm/30)*dt);
 float m=fmax_(1,sqrt_(i.x*i.x+i.y*i.y));K1.px=LIM(K1.px+i.x/m*230*dt,20,780);K1.py=LIM(K1.py+i.y/m*230*dt,20,480);
 if(i.a&&K1.pc<=0&&K1.lt>=15){K1.pc=.7f;K1.lt-=15;K1.pl=.45f;tone(500,250);for(int k=0;k<8;k++)if(K1.sh[k].a){float dx=K1.sh[k].x-K1.px,dy=K1.sh[k].y-K1.py;if(dx*dx+dy*dy<170*170){K1.sh[k].a=0;score+=15;ftext("+15",K1.sh[k].x,K1.sh[k].y,0xb7ff7a);burst(K1.sh[k].x,K1.sh[k].y,0xb7ff7a,14);}}}
 for(int k=0;k<4;k++)if(K1.o[k].a){float dx=K1.o[k].x-K1.px,dy=K1.o[k].y-K1.py;if(dx*dx+dy*dy<28*28){score+=10;K1.lt=fmin_(100,K1.lt+20);tone(800,60);burst(K1.o[k].x,K1.o[k].y,0xb7ff7a,10);ko_orb(k);}}
 K1.sp-=dt;if(K1.sp<=0){K1.sp=fmax_(1.8f,6-K1.tm/20);for(int k=0;k<8;k++)if(!K1.sh[k].a){K1.sh[k].a=1;K1.sh[k].w=rnd()*6;int s=rndi(4);K1.sh[k].x=s==0?-20:s==1?820:rnd()*800;K1.sh[k].y=s==2?-20:s==3?520:rnd()*500;break;}}
 for(int k=0;k<8;k++)if(K1.sh[k].a){K1.sh[k].w+=dt*4;float a=fatan2(K1.py-K1.sh[k].y,K1.px-K1.sh[k].x),v=(75+K1.tm*1.2f)*dt;K1.sh[k].x+=fcos(a)*v+fsin(K1.sh[k].w)*.6f;K1.sh[k].y+=fsin(a)*v+fcos(K1.sh[k].w)*.6f;
  float dx=K1.sh[k].x-K1.px,dy=K1.sh[k].y-K1.py;if(dx*dx+dy*dy<26*26&&!over){over=1;burst(K1.px,K1.py,0xffffff,30);}}
 if(K1.lt<=0&&!over){over=1;burst(K1.px,K1.py,0xffffff,30);}
}
static u8 DLUT[257];static int dlut_ok;
static void darkness(float cx,float cy,float r,float amax){
 if(!dlut_ok){for(int i=0;i<=256;i++){float d=sqrt_((float)i/256.0f),t=clamp((d-.35f)/.65f,0,1);DLUT[i]=(u8)(t*.92f*255);}dlut_ok=1;}
 float X=TX(cx),Y=TY(cy),R=TL(r);int ix=(int)X,iy=(int)Y,Ri=(int)R,R2=Ri*Ri,aout=(int)(amax*255);if(R2<1)R2=1;int inv=(256<<16)/R2;
 for(int py=CY0;py<CY1;py++){
  if(py<iy-Ri||py>iy+Ri){span(py,CX0,CX1,0x020806,aout);continue;}
  int dy=py-iy,dy2=dy*dy,rem=R2-dy2,hw=(int)sqrt_((float)(rem>0?rem:0)),xa=ix-hw,xb=ix+hw;
  int l1=xa<CX0?CX0:(xa>CX1?CX1:xa);span(py,CX0,l1,0x020806,aout);int r0=xb+1<CX0?CX0:(xb+1>CX1?CX1:xb+1);span(py,r0,CX1,0x020806,aout);
  for(int px=l1;px<r0;px++){int dx=px-ix,idx=((dx*dx+dy2)*inv)>>16;if(idx>255)idx=255;pbl(px,py,0x020806,DLUT[idx]);}}}
static void ko_draw(void){
 for(int k=0;k<9;k++){float X=(float)((k*113+40)%800);tri(X,300-(float)((k*37)%80)-0,55,260,0x08281c,.85f);}
 for(int k=0;k<4;k++)if(K1.o[k].a){float r=9+fsin(K1.tm*5+K1.o[k].x)*2;glow(K1.o[k].x,K1.o[k].y,42,0xb7ff7a,.8f);disc(K1.o[k].x,K1.o[k].y,r,0xb7ff7a,1);disc(K1.o[k].x,K1.o[k].y,r*.35f,0xffffff,.9f);}
 for(int k=0;k<8;k++)if(K1.sh[k].a)disc(K1.sh[k].x,K1.sh[k].y,22,0x0b1210,1);
 darkness(K1.px,K1.py,70+K1.lt*1.6f,.92f);
 for(int k=0;k<8;k++)if(K1.sh[k].a){rrect(K1.sh[k].x-9,K1.sh[k].y-5,5,7,2,0xffffff,0xffffff,1);rrect(K1.sh[k].x+4,K1.sh[k].y-5,5,7,2,0xffffff,0xffffff,1);}
 if(K1.pl>0)ring(K1.px,K1.py,170*(1-K1.pl/.45f),4,0xb7ff7a,fmin_(1,K1.pl*2));
 glow(K1.px,K1.py,60,0xffffff,.5f);disc(K1.px,K1.py,16,0xffffff,1);rrect(K1.px-7,K1.py-4,4,6,2,0x1b3b2a,0x1b3b2a,1);rrect(K1.px+3,K1.py-4,4,6,2,0x1b3b2a,0x1b3b2a,1);
 rrect(588,472,196,12,6,0x03051a,0x03051a,.55f);rrect(588,472,196*K1.lt/100,12,6,K1.lt>25?0xb7ff7a:0xff5c8a,K1.lt>25?0xb7ff7a:0xff5c8a,1);
}
static void cover(float x,float y,float w,float h,float t){(void)t;(void)w;(void)h;(void)x;(void)y;
 {float cx=x+w/2;disc(cx,y+.45f*h,.27f*w,0xffffff,.95f);rrect(cx-.14f*w,y+.4f*h,.07f*w,.1f*h,3,0x1b3b2a,0x1b3b2a,1);rrect(cx+.07f*w,y+.4f*h,.07f*w,.1f*h,3,0x1b3b2a,0x1b3b2a,1);}
}
PX_HEAD {"PXG1",1,0,0,(u32)px_entry,0,0,"Kodama","Aventura","Ayuda a un espíritu del bosque a recordar su nombre.","Flechas: mover  ·  Intro: pulso de luz  ·  P: pausa  ·  Esc: salir",0x8be04e,0x0f5d3a,0x6fd16a,0x0b3d2a,63,88,0,0};
PX_ENTRY(ko_init,ko_step,ko_draw,cover)
