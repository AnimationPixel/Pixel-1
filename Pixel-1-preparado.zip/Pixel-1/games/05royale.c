/* Pixel Royale - juego para PixelKernel (.pixel) */
#include "pxlib.h"
static struct{float x,y,hp,fx,fy,cd,tm,sp,cs,zr,iv,pw,mf;int kills,lf;struct{float x,y,vx,vy,l;int a;}b[16];struct{float x,y,f,hp;int t,a;}e[16];struct{float x,y,vx,vy;int a;}m[10];struct{float x,y;int t,a;}c[4];}R1;
static void ry_init(void){zero(&R1,sizeof R1);R1.x=400;R1.y=250;R1.hp=100;R1.fx=1;R1.zr=430;R1.sp=1;R1.cs=6;R1.lf=30;}
static void ry_shot(float vx,float vy){for(int k=0;k<16;k++)if(!R1.b[k].a){R1.b[k].a=1;R1.b[k].x=R1.x;R1.b[k].y=R1.y;R1.b[k].vx=vx;R1.b[k].vy=vy;R1.b[k].l=.9f;return;}}
static void ry_step(float dt,In i){
 R1.tm+=dt;R1.cd-=dt;R1.sp-=dt;R1.cs-=dt;R1.pw-=dt;R1.iv-=dt;R1.mf-=dt;
 float l=sqrt_(i.x*i.x+i.y*i.y),m=fmax_(1,l);R1.x=LIM(R1.x+i.x/m*235*dt,12,788);R1.y=LIM(R1.y+i.y/m*235*dt,12,488);if(l>.2f){R1.fx=i.x/l;R1.fy=i.y/l;}
 if(i.a&&R1.cd<=0){R1.cd=.22f;R1.mf=.06f;float vx=R1.fx*640,vy=R1.fy*640;ry_shot(vx,vy);if(R1.pw>0){ry_shot(vx*.976f-vy*.218f,vy*.976f+vx*.218f);ry_shot(vx*.976f+vy*.218f,vy*.976f-vx*.218f);}tone(520,40);}
 if(R1.sp<=0){R1.sp=fmax_(.55f,2-R1.tm/50);float a=rnd()*6.283f,r=rnd();int t=r<.5f?0:r<.8f?2:1;for(int k=0;k<16;k++)if(!R1.e[k].a){R1.e[k].a=1;R1.e[k].t=t;R1.e[k].hp=t==1?4:t==2?2:1;R1.e[k].f=1+rnd();R1.e[k].x=400+fcos(a)*470;R1.e[k].y=250+fsin(a)*320;break;}}
 if(R1.cs<=0){R1.cs=9;for(int k=0;k<4;k++)if(!R1.c[k].a){R1.c[k].a=1;R1.c[k].t=rnd()<.5f;R1.c[k].x=80+rnd()*640;R1.c[k].y=60+rnd()*380;break;}}
 for(int k=0;k<16;k++)if(R1.b[k].a){R1.b[k].x+=R1.b[k].vx*dt;R1.b[k].y+=R1.b[k].vy*dt;R1.b[k].l-=dt;if(R1.b[k].l<=0)R1.b[k].a=0;}
 for(int k=0;k<16;k++)if(R1.e[k].a){int t=R1.e[k].t;float dx=R1.x-R1.e[k].x,dy=R1.y-R1.e[k].y,d=sqrt_(dx*dx+dy*dy)+.001f,v=t==1?55:t==0?135:80;
  if(t==2){if(d>230){R1.e[k].x+=dx/d*v*dt;R1.e[k].y+=dy/d*v*dt;}else if(d<170){R1.e[k].x-=dx/d*v*dt;R1.e[k].y-=dy/d*v*dt;}R1.e[k].f-=dt;if(R1.e[k].f<=0){R1.e[k].f=1.5f;for(int q=0;q<10;q++)if(!R1.m[q].a){R1.m[q].a=1;R1.m[q].x=R1.e[k].x;R1.m[q].y=R1.e[k].y;R1.m[q].vx=dx/d*280;R1.m[q].vy=dy/d*280;break;}}}
  else{R1.e[k].x+=dx/d*v*dt;R1.e[k].y+=dy/d*v*dt;if(d<24){R1.hp-=(t==1?45:25)*dt;R1.iv=.1f;}}
  for(int b=0;b<16;b++)if(R1.b[b].a&&(R1.e[k].x-R1.b[b].x)*(R1.e[k].x-R1.b[b].x)+(R1.e[k].y-R1.b[b].y)*(R1.e[k].y-R1.b[b].y)<18*18){R1.b[b].a=0;if(--R1.e[k].hp<=0){R1.e[k].a=0;R1.kills++;int p=t==1?100:t==2?60:40;score+=p;burst(R1.e[k].x,R1.e[k].y,0xff4d6d,18);ftext(t==1?"+100":t==2?"+60":"+40",R1.e[k].x,R1.e[k].y,0xffffff);tone(260,100);}else burst(R1.b[b].x,R1.b[b].y,0xffe36b,3);break;}}
 for(int k=0;k<10;k++)if(R1.m[k].a){R1.m[k].x+=R1.m[k].vx*dt;R1.m[k].y+=R1.m[k].vy*dt;float dx=R1.m[k].x-R1.x,dy=R1.m[k].y-R1.y;if(dx*dx+dy*dy<16*16){R1.m[k].a=0;R1.hp-=12;R1.iv=.15f;tone(200,100);}else if(R1.m[k].x<-20||R1.m[k].x>820||R1.m[k].y<-20||R1.m[k].y>520)R1.m[k].a=0;}
 for(int k=0;k<4;k++)if(R1.c[k].a){float dx=R1.c[k].x-R1.x,dy=R1.c[k].y-R1.y;if(dx*dx+dy*dy<28*28){R1.c[k].a=0;if(R1.c[k].t){R1.pw=10;ftext("¡Disparo triple!",R1.c[k].x,R1.c[k].y,0xffe36b);}else{R1.hp=fmin_(100,R1.hp+35);ftext("+Salud",R1.c[k].x,R1.c[k].y,0x5dffa8);}tone(900,150);}}
 R1.zr=fmax_(110,430-R1.tm*3.2f);{float dx=R1.x-400,dy=R1.y-250;if(dx*dx+dy*dy>R1.zr*R1.zr)R1.hp-=12*dt;}
 {int lf=30-R1.kills-(int)(R1.tm/3.4f);R1.lf=lf<1?1:lf;}
 if(!over){if(R1.lf<=1){win=1;score+=500;over=1;burst(R1.x,R1.y,0xffe36b,40);}else if(R1.hp<=0){over=1;burst(R1.x,R1.y,0x5aa9ff,30);}}
}
static void ry_draw(void){
 for(int X=0;X<800;X+=100)for(int Y=0;Y<500;Y+=100)if((X+Y)%200==0)rect(X,Y,100,100,0xffffff,.04f);
 rect(120,90,90,60,0xffffff,.07f);rect(560,330,120,70,0xffffff,.07f);rect(620,70,60,90,0xffffff,.07f);rect(150,350,80,80,0xffffff,.07f);
 { /* zona: rojo fuera del circulo */
  float X=TX(400),Y=TY(250),R=TL(R1.zr);for(int py=CY0;py<CY1;py++){float dy=py+.5f-Y;if(fabs_(dy)>=R){span(py,CX0,CX1,0xff3c5a,72);continue;}float hw=sqrt_(R*R-dy*dy);span(py,CX0,ifl(X-hw),0xff3c5a,72);span(py,ice(X+hw),CX1,0xff3c5a,72);}
  ring(400,250,R1.zr,3,0xff3c5a,1);}
 for(int k=0;k<4;k++)if(R1.c[k].a){float x=R1.c[k].x,y=R1.c[k].y;u32 c=R1.c[k].t?0xffe36b:0x5dffa8;glow(x,y,34,c,.5f);rrect(x-12,y-12,24,24,5,c,c,1);if(R1.c[k].t)text("3",x,y+6,17,0x04061a,1,1,1,0);else{rect(x-2,y-7,4,14,0x04061a,1);rect(x-7,y-2,14,4,0x04061a,1);}}
 for(int k=0;k<16;k++)if(R1.e[k].a){float x=R1.e[k].x,y=R1.e[k].y;int t=R1.e[k].t;u32 c=t==1?0xb3123b:t==2?0xff9a3d:0xff4d6d;float r=t==1?22:t==2?15:12;glow(x,y,r*2.2f,c,.4f);disc(x,y,r,c,1);disc(x-r*.25f,y-r*.25f,r*.5f,lerpc(c,0xffffff,.35f),.6f);if(t==1){rrect(x-16,y-30,32,4,2,0x03051a,0x03051a,.6f);rrect(x-16,y-30,32*R1.e[k].hp/4,4,2,0xffffff,0xffffff,1);}}
 for(int k=0;k<10;k++)if(R1.m[k].a){glow(R1.m[k].x,R1.m[k].y,14,0xff8aa0,.7f);disc(R1.m[k].x,R1.m[k].y,4,0xff9aaa,1);}
 for(int k=0;k<16;k++)if(R1.b[k].a){glow(R1.b[k].x,R1.b[k].y,14,0xffe36b,.7f);disc(R1.b[k].x,R1.b[k].y,4,0xffe36b,1);}
 {float x=R1.x,y=R1.y;glow(x,y,48,0x5aa9ff,.4f);seg(x,y,x+R1.fx*(R1.mf>0?34:26),y+R1.fy*(R1.mf>0?34:26),4,0xffffff,1);disc(x,y,16,R1.iv>0?0xffffff:0x5aa9ff,1);disc(x-4,y-4,7,0xaad0ff,.6f);}
 rrect(588,472,196,12,6,0x03051a,0x03051a,.55f);rrect(588,472,196*fmax_(0,R1.hp)/100,12,6,R1.hp>35?0x5dffa8:0xff5c8a,R1.hp>35?0x5dffa8:0xff5c8a,1);
 {char b[40]="Quedan ";int n=7,v=R1.lf;if(v>=10)b[n++]='0'+v/10;b[n++]='0'+v%10;b[n++]=' ';b[n++]=0xC2;b[n++]=0xB7;b[n++]=' ';b[n++]='B';b[n++]='a';b[n++]='j';b[n++]='a';b[n++]='s';b[n++]=' ';v=R1.kills;if(v>=10)b[n++]='0'+v/10;b[n++]='0'+v%10;b[n]=0;text(b,784,34,18,0xffffff,1,1,2,0);}
 if(R1.pw>0)text("Triple",784,58,16,0xffe36b,1,1,2,0);
}
static void cover(float x,float y,float w,float h,float t){(void)t;(void)w;(void)h;(void)x;(void)y;
 {for(int i=1;i<8;i++){rect(x+w*i/8,y,1,h,0xffffff,.16f);rect(x,y+h*i/8,w,1,0xffffff,.16f);}disc(x+.65f*w,y+.35f*h,.1f*w,0xffffff,.95f);}
}
PX_HEAD {"PXG1",1,0,0,(u32)px_entry,0,0,"Pixel Royale","Batalla","Treinta jugadores, un mapa que se encoge.","Flechas: mover y apuntar  ·  Intro: disparar  ·  P: pausa  ·  Esc: salir",0x5aa9ff,0x1a2a7a,0x3b6cff,0x0a1a5c,97,54,0,0};
PX_ENTRY(ry_init,ry_step,ry_draw,cover)
