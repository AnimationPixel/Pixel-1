/* Neon Drift - juego para PixelKernel (.px) */
#include "pxlib.h"
static struct{float car,vx,tm,off,nit,v,sacc,tcd;int bo;struct{float x,y,w,sw;u32 c;int p,a;}ob[10];struct{float x,y;int a;}cn[6];struct{float x,y,l;}tr[48];}N0;
static const u32 OCL[4]={0xffe36b,0xff8a3d,0x9d7bff,0x4dffb5};
static void nd_init(void){zero(&N0,sizeof N0);N0.car=400;N0.nit=100;N0.v=300;}
static void nd_step(float dt,In i){
 N0.tm+=dt;N0.bo=i.a&&N0.nit>0;N0.nit=LIM(N0.nit+(N0.bo?-45:12)*dt,0,100);
 N0.v+=(300+N0.tm*7+(N0.bo?200:0)-N0.v)*fmin_(1,4*dt);N0.vx+=(i.x*620-N0.vx)*fmin_(1,5*dt);N0.car=LIM(N0.car+N0.vx*dt,175,625);N0.off=fmod_(N0.off+N0.v*dt,80);
 N0.sacc+=N0.v*dt/12;while(N0.sacc>=1){score++;N0.sacc-=1;}
 if(rnd()<dt*(1.1f+N0.tm/45))for(int k=0;k<10;k++)if(!N0.ob[k].a){N0.ob[k].a=1;N0.ob[k].w=rnd()<.2f?64:44;N0.ob[k].x=180+rnd()*440;N0.ob[k].y=-70;N0.ob[k].c=OCL[rndi(4)];N0.ob[k].sw=rnd()<.25f?(rnd()<.5f?-50:50):0;N0.ob[k].p=0;break;}
 if(rnd()<dt*.8f)for(int k=0;k<6;k++)if(!N0.cn[k].a){N0.cn[k].a=1;N0.cn[k].x=190+rnd()*420;N0.cn[k].y=-20;break;}
 for(int k=0;k<10;k++)if(N0.ob[k].a){float*y=&N0.ob[k].y;*y+=(N0.v-120)*dt;N0.ob[k].x=LIM(N0.ob[k].x+N0.ob[k].sw*dt,175,625);
  if(!N0.ob[k].p&&*y>480){N0.ob[k].p=1;if(fabs_(N0.ob[k].x-N0.car)<N0.ob[k].w/2+52){score+=15;N0.nit=fmin_(100,N0.nit+10);ftext("¡Cerca! +15",N0.car,420,0x5cf2ff);tone(1000,60);}}
  if(*y>560)N0.ob[k].a=0;
  if(fabs_(N0.ob[k].x-N0.car)<N0.ob[k].w/2+20&&fabs_(*y-440)<56&&!over){over=1;burst(N0.car,440,0x5cf2ff,40);}}
 for(int k=0;k<6;k++)if(N0.cn[k].a){N0.cn[k].y+=N0.v*dt;if(fabs_(N0.cn[k].x-N0.car)<34&&fabs_(N0.cn[k].y-440)<34){N0.cn[k].a=0;score+=20;N0.nit=fmin_(100,N0.nit+25);tone(1200,70);burst(N0.cn[k].x,N0.cn[k].y,0xffe36b,8);}else if(N0.cn[k].y>540)N0.cn[k].a=0;}
 N0.tcd-=dt;if(N0.tcd<=0){N0.tcd=.02f;for(int k=0;k<48;k++)if(N0.tr[k].l<=0){N0.tr[k].x=N0.car;N0.tr[k].y=476;N0.tr[k].l=.5f;break;}}
 for(int k=0;k<48;k++)if(N0.tr[k].l>0){N0.tr[k].y+=N0.v*dt;N0.tr[k].l-=dt;}
}
static void nd_draw(void){
 for(int k=0;k<13;k++){float h=60+(float)((k*53)%90);rect(k*70-fmod_(N0.off*.1f,70),380-h,50,h+120,0xff3d8b,.12f);}
 rect(150,0,500,500,0x120f2e,1);shadow(144,0,6,500,0,26,0xff3d8b,.5f);shadow(650,0,6,500,0,26,0xff3d8b,.5f);rect(144,0,6,500,0xff3d8b,1);rect(650,0,6,500,0xff3d8b,1);
 for(float y=-80+N0.off;y<500;y+=80){rect(296,y,6,40,0xffffff,.45f);rect(498,y,6,40,0xffffff,.45f);}
 if(N0.v>420)for(int k=0;k<10;k++){float X=160+(float)((k*131)%480),Y=fmod_(N0.off*3+k*97,500);seg(X,Y,X,Y+40+N0.v/20,2,0xffffff,.25f);}
 for(int k=0;k<6;k++)if(N0.cn[k].a){glow(N0.cn[k].x,N0.cn[k].y,24,0xffe36b,.8f);disc(N0.cn[k].x,N0.cn[k].y,10,0xffe36b,1);}
 for(int k=0;k<10;k++)if(N0.ob[k].a){float x=N0.ob[k].x,y=N0.ob[k].y,w=N0.ob[k].w;rrect(x-w/2,y-34,w,68,6,N0.ob[k].c,lerpc(N0.ob[k].c,0x000000,.35f),1);rrect(x-w/2+5,y-18,w-10,14,3,0x04061a,0x04061a,.6f);disc(x-w/2+8,y+28,3.5f,0xffffff,1);disc(x+w/2-8,y+28,3.5f,0xffffff,1);}
 for(int k=0;k<48;k++)if(N0.tr[k].l>0){rect(N0.tr[k].x-18,N0.tr[k].y,4,10,0xff3d8b,N0.tr[k].l*1.6f);rect(N0.tr[k].x+14,N0.tr[k].y,4,10,0xff3d8b,N0.tr[k].l*1.6f);}
 {float a=N0.vx/2200,c=fcos(a),s=fsin(a),cx=N0.car,cy=440;
  #define RP(px,py) cx+(px)*c-(py)*s,cy+(px)*s+(py)*c
  float body[8]={RP(-22,-36),RP(22,-36),RP(22,36),RP(-22,36)};glow(cx,cy,60,0x5cf2ff,.35f);poly(body,4,0x8cf6ff,0x2fb4d8,1);
  float win_[8]={RP(-14,-22),RP(14,-22),RP(14,-6),RP(-14,-6)};poly(win_,4,0x04061a,0x04061a,.8f);
  if(N0.bo){float f[6]={RP(-10,36),RP(0,60+rnd()*14),RP(10,36)};poly(f,3,0xffb347,0xffb347,.9f);}}
 rrect(588,468,196,22,11,0x03051a,0x03051a,.55f);rrect(592,472,188*N0.nit/100,14,7,N0.nit>20?0x5cf2ff:0xff5c8a,N0.nit>20?0x5cf2ff:0xff5c8a,1);
}
static void cover(float x,float y,float w,float h,float t){(void)t;(void)w;(void)h;(void)x;(void)y;
 {float cx=x+w/2;(void)cx;disc(x+.7f*w,y+.3f*h,.14f*w,0xffe36b,1);for(int k=0;k<3;k++)rrect(x+.1f*w,y+(.52f+k*.07f)*h,.8f*w,2+k,1.5f,0xff3d8b,0xff3d8b,.55f);for(int k=0;k<5;k++)seg(x+.1f*w+k*.2f*w,y+h*.9f,x+.25f*w+k*.12f*w,y+h*.6f,2,0xffffff,.18f);}
}
PX_HEAD {"PXG1",1,0,0,(u32)px_entry,0,0,"Neon Drift","Carreras","Derrapa por autopistas de neón a 400 km/h.","Flechas: mover  ·  Intro: nitro  ·  P: pausa  ·  Esc: salir",0xff3d8b,0x3b1c8c,0xff3d8b,0x2a0a5e,41,72,0,0};
PX_ENTRY(nd_init,nd_step,nd_draw,cover)
