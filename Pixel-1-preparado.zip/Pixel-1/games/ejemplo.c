/* Plantilla: el juego mas pequeno posible para PixelKernel (.px / .pixel)
   Mueve el cuadrado con las flechas y recoge los puntos. */
#include "pxlib.h"
static float px_,py_,dx_,dy_,t_;
static void init(void){px_=400;py_=250;dx_=rnd()*700+50;dy_=rnd()*400+50;t_=0;}
static void step(float dt,In i){
 t_+=dt;px_=LIM(px_+i.x*320*dt,20,780);py_=LIM(py_+i.y*320*dt,20,480);
 float a=px_-dx_,b=py_-dy_;if(a*a+b*b<30*30){score+=10;burst(dx_,dy_,0xffe36b,12);tone(900,60);dx_=rnd()*700+50;dy_=rnd()*400+50;}
 if(t_>30&&!over){over=1;}}
static void draw(void){
 glow(dx_,dy_,40,0xffe36b,.7f);disc(dx_,dy_,10,0xffe36b,1);
 rrect(px_-16,py_-16,32,32,8,0xffffff,0x9fd6ff,1);
 text("Plantilla: 30 segundos para puntuar",400,60,22,0xffffff,.8f,0,1,0);}
static void cover(float x,float y,float w,float h,float t){
 disc(x+.5f*w,y+.4f*h,.18f*w+fsin(t*3)*3,0xffe36b,1);rrect(x+.3f*w,y+.62f*h,.4f*w,.1f*h,6,0xffffff,0xffffff,.9f);}
PX_HEAD {"PXG1",1,0,0,(u32)px_entry,0,0,"Plantilla","Ejemplo","Un juego de 30 líneas para aprender el formato .px.","Flechas: mover  ·  P: pausa  ·  Esc: salir",0xffc66d,0x6a3a1a,0xffc66d,0x3a1a0a,1,0,0,0};
PX_ENTRY(init,step,draw,cover)
